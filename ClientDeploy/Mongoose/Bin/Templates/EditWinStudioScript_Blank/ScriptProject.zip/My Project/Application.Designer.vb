﻿'***************************************************************************************
' Application.Designer.vb
'
' History:
' 08/04/20 - jcc - RS 9039 - Web designer - local script editing
'***************************************************************************************


Option Strict On
Option Explicit On

