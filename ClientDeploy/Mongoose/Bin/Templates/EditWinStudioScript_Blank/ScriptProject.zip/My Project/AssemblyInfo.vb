﻿'***************************************************************************************
' AssebmlyInfo.vb
'
' History:
' 08/04/20 - jcc - RS 9039 - Web designer - local script editing
'***************************************************************************************

Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("EditWinStudioScript")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("Infor Global Solutions Technology GmbH")> 
<Assembly: AssemblyProduct("EditWinStudioScript")> 
<Assembly: AssemblyCopyright("Copyright © 2007 Infor Global Solutions Technology GmbH")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("cc9c0fe5-6f3c-4a48-8628-3c8217bc7acc")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
