IF NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'FormMetricsHeightType' AND ss.name = N'dbo')
CREATE TYPE [dbo].[FormMetricsHeightType] FROM [nvarchar](50) NULL
GO
