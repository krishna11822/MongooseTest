IF NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'DocumentNameType' AND ss.name = N'dbo')
CREATE TYPE [dbo].[DocumentNameType] FROM [nvarchar](120) NULL
GO
