IF NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'BODTemplateVersionType' AND ss.name = N'dbo')
CREATE TYPE [dbo].[BODTemplateVersionType] FROM [nvarchar](12) NULL
GO
