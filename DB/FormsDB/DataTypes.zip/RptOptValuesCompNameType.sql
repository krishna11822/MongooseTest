IF NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'RptOptValuesCompNameType' AND ss.name = N'dbo')
CREATE TYPE [dbo].[RptOptValuesCompNameType] FROM [nvarchar](50) NOT NULL
GO
