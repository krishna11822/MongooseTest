IF NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'ABIdType' AND ss.name = N'dbo')
CREATE TYPE [dbo].[ABIdType] FROM [nvarchar](64) NULL
GO
