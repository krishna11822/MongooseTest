IF NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'EventVotingMarginType' AND ss.name = N'dbo')
CREATE TYPE [dbo].[EventVotingMarginType] FROM [decimal](5, 2) NULL
GO
