IF NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'CountryPackOptionType' AND ss.name = N'dbo')
CREATE TYPE [dbo].[CountryPackOptionType] FROM [nchar](1) NULL
GO
