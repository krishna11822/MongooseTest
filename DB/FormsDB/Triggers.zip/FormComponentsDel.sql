SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/* $Header: FormsDB\Triggers\FormComponentsDel.sql 10.1.0.1 03/30/2018 14:28:32 */

/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2018 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/

/* $Archive: /Tools/SQLScripts/FormsDB/Triggers/FormComponentsDel.sql $
 *
 * $NoKeywords: $
*/
IF OBJECT_ID('dbo.FormComponentsDel') IS NOT NULL
    DROP TRIGGER dbo.FormComponentsDel
GO

CREATE TRIGGER [dbo].[FormComponentsDel] ON [dbo].[FormComponents]
INSTEAD OF DELETE
AS
DELETE fc01
FROM FormComponents01 AS fc01
INNER JOIN deleted AS dd ON
  dd.FormID = fc01.FormID
AND dd.Name = fc01.Name
AND dd.DeviceID = fc01.DeviceID

DELETE fc02
FROM FormComponents02 AS fc02
INNER JOIN deleted AS dd ON
  dd.FormID = fc02.FormID
AND dd.Name = fc02.Name
AND dd.DeviceID = fc02.DeviceID

RETURN

GO

