SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('dbo.HelpIDs_ITrig') IS NOT NULL
   DROP TRIGGER dbo.HelpIDs_ITrig
GO
/****** Object:  Trigger dbo.HelpIDs_ITrig    Script Date: 1/29/99 12:42:37 PM ******/
CREATE TRIGGER HelpIDs_ITrig ON dbo.HelpIDs FOR INSERT AS

/*
 * PREVENT NULL VALUES IN 'FormName'
 */

IF (SELECT Count(*) FROM inserted WHERE FormName IS NULL) > 0
    BEGIN
        RAISERROR ('Field ''FormName'' cannot contain a null value.', 16, 1)
        ROLLBACK TRANSACTION
    END


UPDATE HelpIDs
SET RecordDate = getdate()
FROM inserted AS ii
WHERE ii.FormName = HelpIDs.FormName
AND       ISNULL(ii.ComponentName, NCHAR(1) ) = ISNULL(HelpIDs.ComponentName, NCHAR(1) )

/*
ELSE
 * PREVENT NULL VALUES IN 'ComponentName'
forget this for now
IF (SELECT Count(*) FROM inserted WHERE ComponentName IS NULL) > 0
    BEGIN
        RAISERROR ('Field ''ComponentName'' cannot contain a null value.', 16, 1)
        ROLLBACK TRANSACTION
    END
 */










GO
