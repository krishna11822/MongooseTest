SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/* $Header: FormsDB\Triggers\FormComponentsIns.sql 10.1.0.1 03/30/2018 14:28:32 */

/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2018 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/

/* $Archive: /Tools/SQLScripts/FormsDB/Triggers/FormComponentsIns.sql $
 *
 * $NoKeywords: $
*/
IF OBJECT_ID('dbo.FormComponentsIns') IS NOT NULL
    DROP TRIGGER dbo.FormComponentsIns
GO

CREATE TRIGGER [dbo].[FormComponentsIns] ON [dbo].[FormComponents]
INSTEAD OF INSERT
AS
INSERT INTO FormComponents01 (
  FormID
, Name
, TabOrder
, Type
, TopPos
, LeftPos
, Height
, ListHeight
, Width
, Caption
, Validators
, ContainerName
, ContainerSequence
, DataSource
, Binding
, EventToGenerate
, SelectionEventToGenerate
, LoseFocusEventToGenerate
, GainFocusEventToGenerate
, RadioButtonSelectedValue
, ComboListSource
, Flags
, DefaultData
, ReadOnly
, Hidden
, BitmapFileName
, HelpString
, HelpFileName
, HelpContextID
, DeviceID
) SELECT
  FormID
, Name
, TabOrder
, Type
, TopPos
, LeftPos
, Height
, ListHeight
, Width
, Caption
, Validators
, ContainerName
, ContainerSequence
, DataSource
, Binding
, EventToGenerate
, SelectionEventToGenerate
, LoseFocusEventToGenerate
, GainFocusEventToGenerate
, RadioButtonSelectedValue
, ComboListSource
, Flags
, DefaultData
, ReadOnly
, Hidden
, BitmapFileName
, HelpString
, HelpFileName
, HelpContextID
, ISNULL(DeviceID,-1)
FROM inserted

INSERT INTO FormComponents02 (
  FormID
, Name
, TabOrder
, Format
, FindFromSpec
, MaintainFromSpec
, MaxCharacters
, DefaultFrom
, MenuName
, DataType
, ActiveXControlName
, PropertyClassName
, Post301DataType
, Post301Format
, Description
, EffectiveCaption
, DeviceID
, LayoutAttributes
) SELECT
  FormID
, Name
, TabOrder
, Format
, FindFromSpec
, MaintainFromSpec
, MaxCharacters
, DefaultFrom
, MenuName
, DataType
, ActiveXControlName
, PropertyClassName
, Post301DataType
, Post301Format
, Description
, EffectiveCaption
, ISNULL(DeviceID,-1)
, LayoutAttributes
FROM inserted

RETURN


GO

