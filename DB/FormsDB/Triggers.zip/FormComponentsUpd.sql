SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/* $Header: FormsDB\Triggers\FormComponentsUpd.sql 10.1.0.1 03/30/2018 14:28:32 */

/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2018 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/

/* $Archive: /Tools/SQLScripts/FormsDB/Triggers/FormComponentsUpd.sql $
 *
 * $NoKeywords: $
*/
IF OBJECT_ID('dbo.FormComponentsUpd') IS NOT NULL
    DROP TRIGGER dbo.FormComponentsUpd
GO

CREATE TRIGGER [dbo].[FormComponentsUpd] ON [dbo].[FormComponents]
INSTEAD OF UPDATE
AS
UPDATE FormComponents01
SET TabOrder = ii.TabOrder
, Type = ii.Type
, TopPos = ii.TopPos
, LeftPos = ii.LeftPos
, Height = ii.Height
, ListHeight = ii.ListHeight
, Width = ii.Width
, Caption = ii.Caption
, Validators = ii.Validators
, ContainerName = ii.ContainerName
, ContainerSequence = ii.ContainerSequence
, DataSource = ii.DataSource
, Binding = ii.Binding
, EventToGenerate = ii.EventToGenerate
, SelectionEventToGenerate = ii.SelectionEventToGenerate
, LoseFocusEventToGenerate = ii.LoseFocusEventToGenerate
, GainFocusEventToGenerate = ii.GainFocusEventToGenerate
, RadioButtonSelectedValue = ii.RadioButtonSelectedValue
, ComboListSource = ii.ComboListSource
, Flags = ii.Flags
, DefaultData = ii.DefaultData
, ReadOnly = ii.ReadOnly
, Hidden = ii.Hidden
, BitmapFileName = ii.BitmapFileName
, HelpString = ii.HelpString
, HelpFileName = ii.HelpFileName
, HelpContextID = ii.HelpContextID
, DeviceID= ii.DeviceID
FROM FormComponents01 AS fc1
INNER JOIN inserted AS ii ON
  ii.FormID = fc1.FormID
AND ii.Name = fc1.Name
AND ii.DeviceID = fc1.DeviceID

UPDATE FormComponents02
SET TabOrder = ii.TabOrder
, Format = ii.Format
, FindFromSpec = ii.FindFromSpec
, MaintainFromSpec = ii.MaintainFromSpec
, MaxCharacters = ii.MaxCharacters
, DefaultFrom = ii.DefaultFrom
, MenuName = ii.MenuName
, DataType = ii.DataType
, ActiveXControlName = ii.ActiveXControlName
, PropertyClassName = ii.PropertyClassName
, Post301DataType = ii.Post301DataType
, Post301Format = ii.Post301Format
, Description = ii.Description
, EffectiveCaption = ii.EffectiveCaption
, DeviceID= ii.DeviceID
, LayoutAttributes = ii.LayoutAttributes
FROM FormComponents02 AS fc2
INNER JOIN inserted AS ii ON
  ii.FormID = fc2.FormID
AND ii.Name = fc2.Name
AND ii.DeviceID = fc2.DeviceID
RETURN


GO

