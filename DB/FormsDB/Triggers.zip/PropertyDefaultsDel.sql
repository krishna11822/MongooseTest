SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/* $Header: FormsDB\Triggers\PropertyDefaultsDel.sql 10.1.0.1 03/30/2018 14:28:32 */

/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2018 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/

/* $Archive: /Tools/SQLScripts/FormsDB/Triggers/PropertyDefaultsDel.sql $
 *
 * $NoKeywords: $
*/
IF OBJECT_ID('dbo.PropertyDefaultsDel') IS NOT NULL
    DROP TRIGGER dbo.PropertyDefaultsDel
GO

CREATE TRIGGER dbo.PropertyDefaultsDel ON PropertyDefaults
INSTEAD OF DELETE
AS

DELETE pd
FROM PropertyDefaults01 AS pd
INNER JOIN deleted AS dd ON
  dd.PropertyName = pd.PropertyName
AND dd.IsPropertyClassExtension = pd.IsPropertyClassExtension
AND dd.ScopeType = pd.ScopeType
AND dd.ScopeName = pd.ScopeName

DELETE pd
FROM PropertyDefaults02 AS pd
INNER JOIN deleted AS dd ON
  dd.PropertyName = pd.PropertyName
AND dd.IsPropertyClassExtension = pd.IsPropertyClassExtension
AND dd.ScopeType = pd.ScopeType
AND dd.ScopeName = pd.ScopeName

RETURN

GO

