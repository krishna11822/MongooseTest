SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('dbo.HelpIDs_UTrig') IS NOT NULL
   DROP TRIGGER dbo.HelpIDs_UTrig
GO

/****** Object:  Trigger dbo.HelpIDs_UTrig    Script Date: 1/29/99 12:42:37 PM ******/
CREATE  TRIGGER HelpIDs_UTrig ON dbo.HelpIDs FOR UPDATE AS

/*
 * PREVENT NULL VALUES IN 'FormName'
 */
IF (SELECT Count(*) FROM inserted WHERE FormName IS NULL) > 0
    BEGIN
        RAISERROR ('Field ''FormName'' cannot contain a null value.', 16, 1)
        ROLLBACK TRANSACTION
    END


/**********************************************************************************************************************/
DECLARE @ContextID INT
, @FileType AS NVARCHAR(50)
, @SubDirectory AS NVARCHAR(50)
, @ContextString AS NVARCHAR(255)
, @RowPointer AS NVARCHAR(50)
, @ComponentName AS NVARCHAR(50)
, @FormName AS NVARCHAR(50)

SET @ContextID = NULL


-- see if there is a ContextID specified
SELECT  @ContextID = dd.ContextID,
                   @RowPointer = dd.RowPointer,
                   @ComponentName = dd.ComponentName,
                   @FormName = dd.FormName
FROM HelpIds AS hpi
JOIN inserted AS ii ON (ii.FormName = hpi.FormName ) and 
                        ( ISNULL( ii.ComponentName, NCHAR(1) ) = ISNULL( hpi.ComponentName , NCHAR(1) ) )
JOIN deleted AS dd ON (dd.FormName = ii.FormName ) and 
                       ( ISNULL( dd.ComponentName, NCHAR(1) )  = ISNULL( ii.ComponentName, NCHAR(1) )  )

   SELECT  @FileType = ii.FileType
                    ,  @SubDirectory = ii.SubDirectory
                     , @ContextString = ii.ContextString
    FROM HelpIds AS hpi
    JOIN inserted AS ii ON (ii.FormName = hpi.FormName ) and 
                                       ( ISNULL(ii.ComponentName, NCHAR(1)) = ISNULL(hpi.ComponentName, NCHAR(1)))
    JOIN deleted AS dd ON (dd.FormName = ii.FormName)  and 
                                      ( ISNULL( dd.ComponentName, NCHAR(1) )  = ISNULL( ii.ComponentName, NCHAR(1) )  )

-- if not try with FileType, SubDirectory, ContextString combination
IF @ContextID IS NULL AND   @FileType IS NOT NULL AND     @SubDirectory IS NOT NULL  AND
     @ContextString IS NOT NULL

BEGIN

   IF @ContextID IS NULL
        SELECT  @ContextID = hpi.ContextID
           FROM HelpIDs AS hpi
        WHERE hpi.FileType = @FileType and 
                         hpi.SubDirectory = @SubDirectory and
                         hpi.ContextString = @ContextString and
                         hpi.RowPointer <> @RowPointer

   -- if it is a brand new create a new ContextID
   IF @ContextID IS NULL 
        SELECT @ContextID = MAX(ContextID)  + 1 FROM HelpIDs  WHERE ContextID IS NOT NULL
END
/**********************************************************************************************************************/

UPDATE HelpIDs
SET RecordDate = getdate()
FROM inserted AS ii
WHERE ii.FormName = HelpIDs.FormName
AND       ii.ComponentName = HelpIDs.ComponentName


-- If any column EXCEPT LockedBy changes, then we update the RecordDate column
UPDATE hpi
SET RecordDate = CASE 
                    WHEN 
                       ISNULL(dd.FormName,CHAR(1)) = ISNULL(ii.FormName,CHAR(1)) AND
                       ISNULL(dd.ComponentName,CHAR(1)) = ISNULL(ii.ComponentName,CHAR(1)) AND
                       ISNULL(dd.DataBinding,CHAR(1)) = ISNULL(ii.DataBinding,CHAR(1)) AND
                       ISNULL(dd.FormCaption,CHAR(1)) = ISNULL(ii.FormCaption,CHAR(1)) AND
                       ISNULL(dd.ComponentLabel,CHAR(1)) = ISNULL(ii.ComponentLabel,CHAR(1)) AND
                       ISNULL(dd.ContextString,CHAR(1)) = ISNULL(ii.ContextString,CHAR(1)) AND
                       ISNULL(dd.ContextId,-1) = ISNULL(ii.ContextId,-1) AND
                       ISNULL(dd.HelpFile,CHAR(1)) = ISNULL(ii.HelpFile,CHAR(1)) AND
                       ISNULL(dd.FileType,CHAR(1)) = ISNULL(ii.FileType,CHAR(1)) AND
                       ISNULL(dd.SubDirectory,CHAR(1)) = ISNULL(ii.SubDirectory,CHAR(1))
                    THEN dd.RecordDate
                    ELSE GETDATE()
                 END
/***********************************************************************************************************************/
  ,  ContextID = CASE WHEN
                    ii.ContextID IS NULL THEN @ContextID
                    ELSE ii.ContextID
                 END                          
/************************************************************************************************************************/
FROM HelpIds AS hpi
JOIN inserted AS ii ON (ii.FormName = hpi.FormName and 
                        ii.ComponentName = hpi.ComponentName)
JOIN deleted AS dd ON (dd.FormName = ii.FormName and 
                       dd.ComponentName = ii.ComponentName)






















GO
