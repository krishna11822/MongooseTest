SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
/* $Header: FormsDB\Triggers\PropertyDefaultsIns.sql 10.1.0.1 03/30/2018 14:28:32 */

/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2018 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/

/* $Archive: /Tools/SQLScripts/FormsDB/Triggers/PropertyDefaultsIns.sql $
 *
 * $NoKeywords: $
*/
IF OBJECT_ID('dbo.PropertyDefaultsIns') IS NOT NULL
    DROP TRIGGER dbo.PropertyDefaultsIns
GO

CREATE TRIGGER dbo.PropertyDefaultsIns ON PropertyDefaults
INSTEAD OF INSERT
AS
INSERT INTO PropertyDefaults01 (
  PropertyName
, ScopeType
, ScopeName
, IsPropertyClassExtension
, Flags
, ComponentFlags
, HelpContextID
, Label
, ListSource
, FindFromForm
, FindFromProperty
, MaintainFromSpec
, Validators
, MaxCharacters
, ValidateImmediately
, ValueIsListIndex
, Description
, LockedBy
) SELECT
  PropertyName
, ScopeType
, ScopeName
, IsPropertyClassExtension
, Flags
, ComponentFlags
, HelpContextID
, Label
, ListSource
, FindFromForm
, FindFromProperty
, MaintainFromSpec
, Validators
, MaxCharacters
, ValidateImmediately
, ValueIsListIndex
, Description
, LockedBy
FROM inserted

INSERT INTO PropertyDefaults02 (
  PropertyName
, ScopeType
, ScopeName
, IsPropertyClassExtension
, Flags
, ComponentFlags
, HelpContextID
, DataType
, EventToGenerate
, SelectionEventToGenerate
, LoseFocusEventToGenerate
, GainFocusEventToGenerate
, HelpString
, HelpFileName
, MenuName
, Post301DataType
, Post301Format
) SELECT
  PropertyName
, ScopeType
, ScopeName
, IsPropertyClassExtension
, Flags
, ComponentFlags
, HelpContextID
, DataType
, EventToGenerate
, SelectionEventToGenerate
, LoseFocusEventToGenerate
, GainFocusEventToGenerate
, HelpString
, HelpFileName
, MenuName
, Post301DataType
, Post301Format
FROM inserted

RETURN

GO


