SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('dbo.UTInlineListDisplaySp') IS NOT NULL
   DROP PROCEDURE dbo.UTInlineListDisplaySp
GO

create procedure dbo.UTInlineListDisplaySp (  
   @ListSource nvarchar(4000)  
  ,@VarValue nvarchar(4000)  
)  
as  
--print 'Analyzing: ' + @ListSource  
-- Determine user displayed columns  
declare @DisplayCols nvarchar(255)  
if charindex('display(',@ListSource,1) = 0  
   set @DisplayCols = '1'  
else begin  
   set @DisplayCols = substring(@ListSource,Charindex('display(',@ListSource,1)+8,1000)  
   set @DisplayCols = substring(@DisplayCols,1,Charindex(')',@DisplayCols,1)-1)  
end  
--print 'DisplayCols: ' + @DisplayCols  
  
if @VarValue is not null  
   set @ListSource = @VarValue  
else begin  
   -- Isolate the List  
   set @ListSource = substring(@ListSource,charindex('inline entries(',@ListSource,1)+15,1000)  
   set @ListSource = substring(@ListSource,1,charindex(')',@ListSource,1)-1)  
end  
--print ' ListSource: ' + @ListSource  
/*  
Temp Table #temp_UTTest_Strings created in UT Scripts  
declare @Strings table (  
   name nvarchar(255)  
   )  
*/  
  
declare  
   @NumRows int  
  ,@RC int  
  ,@Row nvarchar(255)  
  ,@NumColumns int  
  ,@CC int  
  ,@DC int  
  ,@Col nvarchar(255)  
  
-- get each row in the list  
set @NumRows = dbo.NumEntries(@ListSource,',')  
set @RC = 1  
while @RC <= @NumRows  
begin  
   set @Row = dbo.Entry(@RC,@ListSource,',')  
  
   -- get each displayed column  
   set @NumColumns = dbo.NumEntries(@DisplayCols,',')  
   set @CC = 1  
   while @CC <= @NumColumns  
   begin  
      set @DC = dbo.Entry(@CC,@DisplayCols,',')  
      set @Col = dbo.Entry(@DC,@Row,'\')  
      insert into #temp_UTTest_Strings select @Col  
--      print '   ' + @Col  
      set @CC = @CC + 1  
   end  
  
   set @RC = @RC + 1  
end  
  
--select * from #temp_UTTest_Strings  
  
  


GO
