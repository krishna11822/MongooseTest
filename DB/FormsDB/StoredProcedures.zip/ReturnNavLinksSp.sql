SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
IF OBJECT_ID('dbo.ReturnNavLinksSp') IS NOT NULL
   DROP PROCEDURE dbo.ReturnNavLinksSp
GO
/****** Object:  Stored Procedure dbo.ReturnNavLinksSp    Script Date: 1/29/99 12:42:37 PM ******/
/*
**  This routine is made to retrieve the Explorer links so that a path
** through the navigator to the forms can be found.
*/
create procedure ReturnNavLinksSp
as
declare @Level int

/*
**  The first level gets the linkages between all the forms and the menus.
** The loop then loads the menus which call those forms, and the menus which
** calls those menus, etc.
*/
select @Level = 1

create table #xxx (
  ParentId int
, ParentObject varchar (255)
, ParentType varchar (255)
, ChildObject varchar (255)
, ChildType varchar (255)
, ObjLevel int
)

insert into #xxx
select 'ParentId' = ObjectId
, 'ParentObject' = (
     case ParentFolderId
       when -1 then 'Master Explorer'
       when -2 then 'Public' end)
, 'ParentType' = 'E'
, 'ChildObject' = ObjectName
, 'ChildType' = 'E'
, 'ObjLevel' = 1
from ExplorerObjects
where ParentFolderId = -2

while 1=1
begin
  select @Level = @Level + 1

  insert into #xxx (ParentId, ParentObject
    , ParentType, ChildObject, ChildType, ObjLevel)
  select e1.ObjectId, x.ChildObject, 'E',
    (case e1.ObjectTextData when NULL then ObjectName else ObjectTextData end)
  , (case e1.ObjectTextData when NULL then 'E' else 'F' end)
  , @Level
  from #xxx x, ExplorerObjects e1
  where x.ParentId = e1.ParentFolderId
  and x.ObjLevel = @Level - 1

  if @@rowcount = 0
    break
end

select distinct ParentObject, ParentType
, ChildObject, ChildType
from #xxx
order by ParentObject, ParentType

drop table #xxx
return 0



GO
