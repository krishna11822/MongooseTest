SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


IF OBJECT_ID('dbo.UTGetAppDBParamSp') IS NOT NULL
   DROP PROCEDURE dbo.UTGetAppDBParamSp
GO
/* $Header: /Tools/SQLScripts/FormsDB/Stored Procedures/UTGetAppDBParamSp.sql 3     8/07/12 9:28a Bcummings $  */
/*
Copyright � Frontstep, Inc. 2001 - All Rights Reserved

Use, duplication, or disclosure by the Government is subject to restrictions
as set forth in subparagraph (c)(1)(ii) of the Rights in Technical Data and
Computer Software clause at DFARS 252.227-7013, and Rights in Data-General at
FAR 52.227.14, as applicable. 

Name of Contractor: Frontstep, Inc., 2800 Corporate Exchange Dr.,
Columbus, Ohio 43231.

Without a license that includes the source code, customer may not, copy, 
modify or otherwise update the code contained within this file.  Nor may the 
customer merge this code with other computer programs.  

With a license that includes the source code, customer may, for its internal 
information management and data processing purposes only, copy and modify the 
code contained within this file (but not the Limiting Devices) or merge the 
code with other computer programs.  The preparation of modified or merged works
will not enlarge the scope of permitted use and any modified or merged version
of the code or any work including any portion of the code shall remain subject
to the provisions of the separately executed license agreement.  All rights and
title to the code remain the sole property of Frontstep, Inc.

Frontstep is a trademark of Frontstep Solutions Group, Inc. All other product
names used in this code are trademarks, registered trademarks, or trade names
of their respective companies.
*/
CREATE PROCEDURE UTGetAppDBParamSp (
  @ServerName nvarchar(50) OUTPUT
, @DBName nvarchar(50) OUTPUT
, @LoginName nvarchar(50) OUTPUT
, @Password nvarchar(50) OUTPUT
)
AS

SELECT  @ServerName = Server_Name,
	@DBName = Database_Name,
	@LoginName = Login_Name,
	@Password = Pwd
FROM UTAppDBParams 

SET QUOTED_IDENTIFIER OFF 

GO
