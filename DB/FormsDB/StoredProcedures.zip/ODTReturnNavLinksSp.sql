SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('dbo.ODTReturnNavLinksSp') IS NOT NULL
   DROP PROCEDURE dbo.ODTReturnNavLinksSp
GO
/* ODT - Object Dependency Scanner
**
** This routine is made to retrieve the Explorer links so that a path
** through the navigator to the forms can be found.
*/
CREATE PROCEDURE ODTReturnNavLinksSp
  @ParentObjectName    NVARCHAR(255)
AS
DECLARE @Level TINYINT

/*
**  The first level gets the linkages between all the forms and the menus.
** The loop then loads the menus which call those forms, and the menus which
** calls those menus, etc.
*/
SELECT @Level = 1

IF @ParentObjectName = '' SELECT @ParentObjectName = NULL

CREATE TABLE #ODTObjectDependsTmp (
  ParentObjectID   INT
, ParentObjectName NVARCHAR(255)
, ParentType       CHAR(3)
, ChildObjectName  NVARCHAR(255)
, ChildType        CHAR(3)
, ObjectLevel      TINYINT
, ObjectID         INT
)

INSERT INTO #ODTObjectDependsTmp
SELECT
  ObjectId
, CASE ParentFolderId 
    WHEN -1 THEN 'Master Explorer' 
    WHEN -2 THEN 'Public'
  END
, 'EXP'
, ObjectName
, 'EXP'
, 1
, -1
FROM ExplorerObjects
WHERE ParentFolderId = -1 -- Master Explorer for Development.
AND   ObjectName LIKE ISNULL(@ParentObjectName,ObjectName)

WHILE 1=1
BEGIN
  SELECT @Level = @Level + 1

  INSERT INTO #ODTObjectDependsTmp (
    ParentObjectID
  , ParentObjectName
  , ParentType
  , ChildObjectName
  , ChildType
  , ObjectLevel
  , ObjectID
  )
  SELECT 
    exp1.ObjectId
  , tmp.ChildObjectName
  , 'EXP'
  , ISNULL (exp1.ObjectName, ObjectTextData)
  , CASE WHEN exp1.ObjectTextData IS NULL THEN 'EXP'
         ELSE 'FRM' 
    END
  , @Level
  , tmp.ParentObjectID
  FROM #ODTObjectDependsTmp tmp
       INNER JOIN ExplorerObjects exp1 ON
           tmp.ParentObjectID = exp1.ParentFolderId
       AND tmp.ObjectLevel = @Level - 1
  WHERE exp1.ObjectTextData IS NOT NULL OR exp1.ObjectName IS NOT NULL

  IF @@rowcount = 0 BREAK
END

UPDATE odt
SET ParentObjectName = s.String
FROM #ODTObjectDependsTmp AS odt
INNER JOIN Strings AS s ON
  s.Name = odt.ParentObjectName
AND s.ScopeType = 0

UPDATE odt
SET ChildObjectName = s.String
FROM #ODTObjectDependsTmp AS odt
INNER JOIN Strings AS s ON
  s.Name = odt.ChildObjectName
AND s.ScopeType = 0

DECLARE
  @BreakOut INT
DECLARE
  @Duplicates TABLE (
    ObjectName NVARCHAR(255)
)
WHILE 1=1
BEGIN
   DELETE FROM @Duplicates
   SET @BreakOut = 0
--INSERT INTO @Duplicates (ObjectName)
--SELECT odt.ChildObjectName
--FROM #ODTObjectDependsTmp AS odt
--WHERE odt.ChildType = 'EXP'
--GROUP BY odt.ChildObjectName
--HAVING COUNT(DISTINCT ObjectId) > 1
INSERT INTO @Duplicates (ObjectName)
SELECT odt.ChildObjectName
FROM #ODTObjectDependsTmp AS odt
WHERE odt.ParentType = 'EXP'
AND odt.ChildType = 'EXP'
GROUP BY odt.ChildObjectName
HAVING COUNT(*) > 1

IF @@ROWCOUNT = 0
   BREAK

--SELECT * FROM @Duplicates

UPDATE odt
SET ChildObjectName = ChildObjectName + ' (' + 
  ISNULL(s.String, eo2.ObjectName) + ')'

, ParentObjectId = eo1.ParentFolderId
FROM #ODTObjectDependsTmp AS odt
INNER JOIN ExplorerObjects AS eo1 ON
  odt.ParentObjectId = eo1.ObjectId
AND eo1.ObjectType = 'F'
INNER JOIN ExplorerObjects AS eo2 ON
  eo2.ObjectID = eo1.ParentFolderId
AND eo2.ObjectType = 'F'
LEFT OUTER JOIN Strings AS s ON
  s.Name = eo2.ObjectName
AND s.ScopeType = 0
WHERE EXISTS (
  SELECT 1
  FROM @Duplicates AS d
  WHERE d.ObjectName = odt.ChildObjectName)
--odt.ChildObjectName IN ('Activities', 'Files', 'Reports', 'Queries', 
--  'Utilitites')
IF @@ROWCOUNT = 0
   SET @BreakOut = @BreakOut + 1

UPDATE odt
SET ParentObjectName = ParentObjectName + ' (' + 
  ISNULL(s.String, eo2.ObjectName) + ')'

, ObjectId = eo1.ParentFolderId
FROM #ODTObjectDependsTmp AS odt
INNER JOIN ExplorerObjects AS eo1 ON
  odt.ObjectId = eo1.ObjectId
AND eo1.ObjectType = 'F'
INNER JOIN ExplorerObjects AS eo2 ON
  eo2.ObjectID = eo1.ParentFolderId
AND eo2.ObjectType = 'F'
LEFT OUTER JOIN Strings AS s ON
  s.Name = eo2.ObjectName
AND s.ScopeType = 0
WHERE EXISTS (
  SELECT 1
  FROM @Duplicates AS d
  WHERE d.ObjectName = odt.ParentObjectName)
--WHERE odt.ParentObjectName IN ('Activities', 'Files', 'Reports', 'Queries', 
--  'Utilitites')
IF @@ROWCOUNT = 0
   SET @BreakOut = @BreakOut + 1

IF @BreakOut = 2
   BREAK

END

SELECT DISTINCT
  odt.ParentObjectName
, odt.ParentType
, odt.ChildObjectName
, odt.ChildType
FROM #ODTObjectDependsTmp AS odt
ORDER BY ParentObjectName, ParentType

DROP TABLE #ODTObjectDependsTmp
RETURN 0

GO
