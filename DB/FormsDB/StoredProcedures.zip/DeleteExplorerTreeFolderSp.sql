SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('dbo.DeleteExplorerTreeFolderSp') IS NOT NULL
   DROP PROCEDURE dbo.DeleteExplorerTreeFolderSp
GO

/****** Object:  Stored Procedure dbo.DeleteExplorerTreeFolderSp    Script Date: 1/9/2003 12:42:37 PM ******/
/*
**  This routine is made to remove a parent folder and all its sub-folders
**  from the Master Explorer
*/
CREATE PROCEDURE DeleteExplorerTreeFolderSp (
    @Parent		nvarchar(255)	   = NULL
)
as

DECLARE @ParentLvl_1 INT
DECLARE @ParentLvl_2 INT
DECLARE @ParentLvl_3 INT
DECLARE @ParentLvl_4 INT
DECLARE @ParentLvl_5 INT

-- Find the ParentLvl_1
SELECT @ParentLvl_1 = ObjectId from ExplorerObjects where ParentFolderId = -1 AND 
   ObjectName = @Parent AND ObjectType = 'F'

--------------------------------------------------------------
-- Check for level 2 subfolders
--------------------------------------------------------------
WHILE (SELECT COUNT(*) 
       FROM ExplorerObjects 
       WHERE ParentFolderId = @ParentLvl_1 AND ObjectType = 'F') > 0
BEGIN
   SELECT @ParentLvl_2 = (SELECT TOP 1(ObjectId) 
                          FROM ExplorerObjects
                          WHERE ParentFolderId = @ParentLvl_1 
                                AND ObjectType = 'F') 
   FROM ExplorerObjects 

   --------------------------------------------------------------
   -- Check for level 3 subfolders
   --------------------------------------------------------------
   WHILE (SELECT COUNT(*) 
          FROM ExplorerObjects 
          WHERE ParentFolderId = @ParentLvl_2 AND ObjectType = 'F') > 0
   BEGIN
      SELECT @ParentLvl_3 = (SELECT TOP 1(ObjectId) 
                             FROM ExplorerObjects
                             WHERE ParentFolderId = @ParentLvl_2
                                   AND ObjectType = 'F') 
      FROM ExplorerObjects 

      --------------------------------------------------------------
      -- Check for level 4 subfolders
      --------------------------------------------------------------
      WHILE (SELECT COUNT(*) 
             FROM ExplorerObjects 
             WHERE ParentFolderId = @ParentLvl_3 AND ObjectType = 'F') > 0
      BEGIN
         SELECT @ParentLvl_4 = (SELECT TOP 1(ObjectId) 
                                FROM ExplorerObjects
                                WHERE ParentFolderId = @ParentLvl_3
                                      AND ObjectType = 'F') 
         FROM ExplorerObjects 

         --------------------------------------------------------------
         -- Check for level 5 subfolders
         --------------------------------------------------------------
         WHILE (SELECT COUNT(*) 
                FROM ExplorerObjects 
                WHERE ParentFolderId = @ParentLvl_4 AND ObjectType = 'F') > 0
         BEGIN
            SELECT @ParentLvl_5 = (SELECT TOP 1(ObjectId) 
                                   FROM ExplorerObjects
                                   WHERE ParentFolderId = @ParentLvl_4
                                         AND ObjectType = 'F') 
            FROM ExplorerObjects 

              -- Delete items from subfolder level 5
              DELETE ExplorerObjects where ParentFolderId = @ParentLvl_5 AND ObjectType <> 'F'
              -- Delete subfolder level 5
              DELETE ExplorerObjects where ObjectId = @ParentLvl_5
         END

           -- Delete items from subfolder level 4
           DELETE ExplorerObjects where ParentFolderId = @ParentLvl_4 AND ObjectType <> 'F'
           -- Delete subfolder level 4
           DELETE ExplorerObjects where ObjectId = @ParentLvl_4

      END

        -- Delete items from subfolder level 3
        DELETE ExplorerObjects where ParentFolderId = @ParentLvl_3 AND ObjectType <> 'F'
        -- Delete subfolder level 3
        DELETE ExplorerObjects where ObjectId = @ParentLvl_3

   END

     -- Delete items from subfolder level 2
     DELETE ExplorerObjects where ParentFolderId = @ParentLvl_2 AND ObjectType <> 'F'
     -- Delete subfolder level 2
     DELETE ExplorerObjects where ObjectId = @ParentLvl_2

END

-- Delete items from top level folder
DELETE ExplorerObjects where ParentFolderId = @ParentLvl_1 AND ObjectType <> 'F'

-- Delete top level folder 
DELETE ExplorerObjects where ObjectId = @ParentLvl_1 


GO
