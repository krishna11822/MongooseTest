SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('dbo.FindMethod2SubSp') IS NOT NULL
   DROP PROCEDURE dbo.FindMethod2SubSp
GO

CREATE procedure FindMethod2SubSp (
  @TokenID    int
, @FormID     int
, @MethodName varchar (255)
, @Type       varchar (255)
)
as
declare
  @Severity       int
, @PropertyName   varchar (255)
, @PropListSource varchar (255)
, @PropValidator  varchar (255)
, @StartParse     varchar (255)
, @EndParse       varchar (255)

select @StartParse = '%[^a-zA-Z_]'
select @EndParse = '[^a-zA-Z_]%'
/*
**  List the form components which use the method directly.
*/
insert into UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select @TokenID, fc.FormID, 'LIST SOURCE', fc.Name
from FormComponents fc
where lower ('.' + fc.ComboListSource + '.') like 
   lower (@StartParse + @MethodName + @EndParse)
and fc.FormID = isnull (@FormID, fc.FormID)

insert into UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select @TokenID, fc.FormID, 'VALIDATOR', fc.Name
from FormComponents fc
where lower ('.' + fc.Validators + '.') 
  like lower (@StartParse + @MethodName + @EndParse)
and fc.FormID = isnull (@FormID, fc.FormID)

insert into UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select @TokenID, fc.FormID, 'DATA CHANGE EVENT', fc.Name
from FormComponents fc
where lower ('.' + fc.SelectionEventToGenerate + '.') 
  like lower (@StartParse + @MethodName + @EndParse)
and fc.FormID = isnull (@FormID, fc.FormID)

insert into UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select @TokenID, fc.FormID, 'PRIMARY EVENT', fc.Name
from FormComponents fc
where lower ('.' + fc.EventToGenerate + '.') 
  like lower (@StartParse + @MethodName + @EndParse)
and fc.FormID = isnull (@FormID, fc.FormID)

insert into UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select @TokenID, fc.FormID, 'GAIN FOCUS EVENT', fc.Name
from FormComponents fc
where lower ('.' + fc.GainFocusEventToGenerate + '.') 
  like lower (@StartParse + @MethodName + @EndParse)
and fc.FormID = isnull (@FormID, fc.FormID)

insert into UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select @TokenID, fc.FormID, 'LOSE FOCUS EVENT', fc.Name
from FormComponents fc
where lower ('.' + fc.LoseFocusEventToGenerate + '.') 
  like lower (@StartParse + @MethodName + @EndParse)
and fc.FormID = isnull (@FormID, fc.FormID)
/*
**  List the forms that have an event handler which uses the method.
*/

insert into UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select @TokenID, feh.FormID, 'EVENT HANDLER', feh.EventName + ' ('
 + convert (varchar, Sequence) + ')'
from FormEventHandlers feh
where lower ('.' + feh.Response + 
  ISNULL (feh.Response2, ' ') + ISNULL (feh.Response3, ' ') + '.') 
  like lower (@StartParse + @MethodName + @EndParse)
and feh.FormID = isnull (@FormID, feh.FormID)


/*
**  Loop through the property defaults which use the method and display the
** form components which use each property default.
*/
declare FmPropDefsCrs2 cursor for
select PropertyName, ListSource, Validators
from PropertyDefaults
where lower ('.' + ListSource + '.') like 
  lower (@StartParse + @MethodName + @EndParse)
  or lower ('.' + Validators + '.') like 
  lower (@StartParse + @MethodName + @EndParse)
open FmPropDefsCrs2
while (1=1)
begin
    fetch FmPropDefsCrs2 into @PropertyName, @PropListSource, @PropValidator
    if @@FETCH_STATUS = -2
        continue
    if @@FETCH_STATUS = -1
        break
    insert into UsesFound (
      TokenID
    , FormID
    , SourceType
    , SourceName
    )
    select @TokenID, fc.FormID, 
       'COMPONENT CLASS', fc.Name
    from FormComponents fc
    where lower (fc.DefaultFrom + '.') like 
      lower (@PropertyName + @EndParse)
    and fc.FormID = isnull (@FormID, fc.FormID)
end
close FmPropDefsCrs2
deallocate FmPropDefsCrs2

insert into UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select distinct @TokenID, f.id, 'ActiveXSCRIPT', ScriptName
from ActiveXScriptLines
inner join Forms f ON
  f.ID = ISNULL(@FormID, f.ID)
where ScriptName = f.Name
and lower ('.' + CodeLine + '.')
   like lower (@StartParse + @MethodName + @EndParse)

insert into UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select distinct @TokenID, NULL, 'SCRIPT', ScriptName
from ScriptLines
where lower ('.' + CodeLine + '.')
   like lower (@StartParse + @MethodName + @EndParse)

return 0



GO
