SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('dbo.ImportStrings') IS NOT NULL
   DROP PROCEDURE dbo.ImportStrings
GO
/*
  This procedure reads strings from a table called "TempStringsImport", with two
  columns, varchar(large), called "English" and "Foreign", joining against the
  English strings table "Strings", assumed to be in the same database.

  It writes to a strings table called ForeignStrings.

  If it encounters the same string more than once, it creates a new entry, with <n><stringname>,
  where n = the number of occurrences so far for this string's English value
*/

CREATE PROCEDURE ImportStrings

AS

DECLARE
  @Severity    INT
, @Source     nVARCHAR(4000)
, @Target     nVARCHAR(4000)
, @Name        nVARCHAR(50)
, @NumExisting INT
, @NewName     nVARCHAR(50)

SET @Severity = 0

DECLARE TempImportCrs CURSOR LOCAL STATIC
FOR
  SELECT s.Name, f.Target, f.Source
  FROM Strings s
  INNER JOIN TempStringsImport f ON s.String = f.Source

OPEN TempImportCrs
WHILE @Severity = 0
BEGIN
  FETCH TempImportCrs INTO
     @Name
   , @Target
   , @Source

  IF @@FETCH_STATUS = -1
    BREAK

  SET @NumExisting = 0
  SELECT @NumExisting = Count(Name)
  FROM ForeignStrings
  WHERE Name = @Name

  IF @NumExisting > 0
    SET @NewName = CAST((@NumExisting+1) as VARCHAR(20)) + @Name
  ELSE
    SET @NewName = @Name

  INSERT INTO ForeignStrings (Name, ScopeType, ScopeName, String)
  VALUES( @NewName, 0, '[NULL]', @Target)

END
CLOSE TempImportCrs
DEALLOCATE TempImportCrs

RETURN @Severity



GO
