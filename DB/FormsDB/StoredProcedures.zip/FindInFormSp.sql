SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('dbo.FindInFormSp') IS NOT NULL
   DROP PROCEDURE dbo.FindInFormSp
GO

/*
**  Given an identifier name, this routine outputs the names of the forms and 
** fields which use this identifier string.  Captions are not searched.
*/
create procedure FindInFormSp (
  @Identifier     nvarchar (255)
, @FormName       nvarchar (255) = NULL
)
as
declare
  @ValidatorName varchar (8000)
, @StartParse    varchar (8000)
, @EndParse      varchar (8000)
, @TokenID       int
, @FormID        int
, @SearchString  varchar (8000)

CREATE TABLE #UsesFound (
	TokenID int NULL,
	FormID int NULL,
	SourceType nvarchar(20)  collate database_default NULL,
	SourceName nvarchar(100)  collate database_default NULL)

if @FormName is not null
begin
    select @FormID = ID
    from Forms
    where Name = @FormName
    if @@rowcount = 0
    begin
        select 'No such form found.'
        return 0
    end
end

select @TokenID = convert ( int, rand () * 1000000000 )

select @StartParse = '%[^a-z_]'
select @EndParse = '[^a-z_]%'
SELECT @SearchString = lower (@StartParse + @Identifier + @EndParse)

insert into #UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select @TokenID, f.ID, 'FORM DATA SOURCE', f.Name
from Forms f
where lower (' ' + f.PrimaryDataSource + ' ') like 
  @SearchString
and f.ID = isnull (@FormID, f.ID)

insert into #UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select @TokenID, fc.FormID, 'FIELD DATA SOURCE', fc.Name
from FormComponents fc
where lower (' ' + fc.DataSource + ' ') like 
  @SearchString
and fc.FormID = isnull (@FormID, fc.FormID)

insert into #UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select @TokenID, fc.FormID, 'LIST SOURCE', fc.Name
from FormComponents fc
where lower ('.' + fc.ComboListSource + '.') like 
   @SearchString
and fc.FormID = isnull (@FormID, fc.FormID)

insert into #UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select @TokenID, fc.FormID, 'VALIDATOR', fc.Name
from FormComponents fc
where lower ('.' + fc.Validators + '.') 
  like @SearchString
and fc.FormID = isnull (@FormID, fc.FormID)

insert into #UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select @TokenID, fc.FormID, 'COMPONENT EVENT', fc.Name
from FormComponents fc
where fc.FormID = isnull (@FormID, fc.FormID)
AND 
  lower ('.' + fc.SelectionEventToGenerate + '.'
 + fc.EventToGenerate + '.'
+ fc.GainFocusEventToGenerate + '.'
+ fc.LoseFocusEventToGenerate + '.')
  like @SearchString
/*
  lower ('.' + fc.SelectionEventToGenerate + '.') 
  like @SearchString
OR  ('.' + fc.EventToGenerate + '.') 
  like @SearchString
OR  ('.' + fc.GainFocusEventToGenerate + '.') 
  like @SearchString
OR  ('.' + fc.LoseFocusEventToGenerate + '.') 
  like @SearchString
)
insert into #UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select @TokenID, fc.FormID, 'DATA CHANGE EVENT', fc.Name
from FormComponents fc
where lower ('.' + fc.SelectionEventToGenerate + '.') 
  like @SearchString
and fc.FormID = isnull (@FormID, fc.FormID)

insert into #UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select @TokenID, fc.FormID, 'PRIMARY EVENT', fc.Name
from FormComponents fc
where lower ('.' + fc.EventToGenerate + '.') 
  like @SearchString
and fc.FormID = isnull (@FormID, fc.FormID)

insert into #UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select @TokenID, fc.FormID, 'GAIN FOCUS EVENT', fc.Name
from FormComponents fc
where lower ('.' + fc.GainFocusEventToGenerate + '.') 
  like @SearchString
and fc.FormID = isnull (@FormID, fc.FormID)

insert into #UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select @TokenID, fc.FormID, 'LOSE FOCUS EVENT', fc.Name
from FormComponents fc
where lower ('.' + fc.LoseFocusEventToGenerate + '.') 
  like @SearchString
and fc.FormID = isnull (@FormID, fc.FormID)
*/
/*
**  List the forms that have an event handler which uses the method.
*/
insert into #UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select @TokenID, feh.FormID, 'EVENT HANDLER', feh.EventName + ' ('
 + convert (varchar, Sequence) + ')'
from FormEventHandlers feh
where lower ('.' + feh.Response + 
  ISNULL (feh.Response2, ' ') + ISNULL (feh.Response3, ' ') + '.') 
  like @SearchString
and feh.FormID = isnull (@FormID, feh.FormID)

    insert into #UsesFound (
      TokenID
    , FormID
    , SourceType
    , SourceName
    )
    select @TokenID, fc.FormID, 
       'PROPERTY DEFAULT', fc.Name
    from FormComponents fc
    where lower (fc.DefaultFrom + '.') like 
      @SearchString
    and fc.FormID = isnull (@FormID, fc.FormID)


insert into #UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select distinct @TokenID, NULL, 'SCRIPT', ScriptName
from ScriptLines
where lower ('.' + CodeLine + '.')
   like @SearchString


insert into #UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select @TokenID, NULL, 'FILTER PROPERTY', FilterName + '.' +  PropertyName
from FilterPropertyAttributes
where lower (' ' + ListSource + ' ') like 
      @SearchString
and lower (FilterName) like 
  lower (isnull (@FormName, FilterName) + '%')

/*
**  List the forms that have a variable which uses the method.
*/
insert into #UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select @TokenID, v.FormID, 'VARIABLE', v.Name
from Variables v
where ' ' + lower (v.Value +
  ISNULL (v.Value2, ' ') + ISNULL (v.Value3, ' ')) like 
  @SearchString
and v.FormID = isnull (@FormID, v.FormID)

select 
  'Form Name'   = f.Name
, 'Source Type' = uf.SourceType
, 'Source Name' = uf.SourceName
from #UsesFound uf
left outer join Forms as f on
  f.ID = uf.FormID
where uf.TokenID = @TokenID
order by 1, 2, 3

delete #UsesFound
where TokenID = @TokenID

return @@rowcount

GO
