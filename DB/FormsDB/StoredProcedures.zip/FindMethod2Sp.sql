SET ANSI_NULLS OFF
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('dbo.FindMethod2Sp') IS NOT NULL
   DROP PROCEDURE dbo.FindMethod2Sp
GO

/*
**  Given a method name, this routine outputs the names of the forms and 
** fields which use this method for an lov or a validator.  The procedure
** then loops through the PropertyDefaults which use this method and selects
** the information for the fields which use the default.  The same info is
** listed for the fields using a property default, because it the methods
** used can be overridden even if a default is selected.
*/
create procedure FindMethod2Sp (
  @MethodName     varchar (255)
, @FormName       varchar (255) = NULL
)
as
declare
  @ValidatorName varchar (255)
, @StartParse    varchar (255)
, @EndParse      varchar (255)
, @TokenID       int
, @FormID        int

if @FormName is not null
begin
    select @FormID = ID
    from Forms
    where Name = @FormName
    if @@rowcount = 0
    begin
        select 'No such form found.'
        return 0
    end
end

select @TokenID = convert ( int, rand () * 1000000000 )

select @StartParse = '%[^a-zA-Z_]'
select @EndParse = '[^a-zA-Z_]%'

insert into UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select @TokenID, f.ID, 'FORM DATA SOURCE', f.Name
from Forms f
where lower (' ' + f.PrimaryDataSource + ' ') like 
  lower (@StartParse + @MethodName + @EndParse)
and f.ID = isnull (@FormID, f.ID)

insert into UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select @TokenID, fc.FormID, 'FIELD DATA SOURCE', fc.Name
from FormComponents fc
where lower (' ' + fc.DataSource + ' ') like 
  lower (@StartParse + @MethodName + @EndParse)
and fc.FormID = isnull (@FormID, fc.FormID)

insert into UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select @TokenID, NULL, 'FILTER PROPERTY', FilterName + '.' +  PropertyName
from FilterPropertyAttributes
where lower (' ' + ListSource + ' ') like 
      lower (@StartParse + @MethodName + @EndParse)
and lower (FilterName) like 
  lower (isnull (@FormName, FilterName) + '%')

  exec FindMethod2SubSp @TokenID, @FormID, @MethodName, NULL
declare FindMethod2SpCrs cursor for
select v.Name
from Validators v
where lower (' ' + v.Parms + 
  ISNULL (v.Parms2, ' ') + ISNULL (v.Parms3, ' ')  + ' ')
   like lower (@StartParse + @MethodName + @EndParse)
and v.Name != @MethodName

open FindMethod2SpCrs
while (1=1)
begin
    fetch FindMethod2SpCrs into @ValidatorName
    if @@FETCH_STATUS = -1
        break
    if @@FETCH_STATUS = -2
        continue
    exec FindMethod2SubSp @TokenID, @FormID, @ValidatorName, 'VALIDATOR'
end
close FindMethod2SpCrs
deallocate FindMethod2SpCrs

/*
**  List the forms that have a variable which uses the method.
*/
insert into UsesFound (
  TokenID
, FormID
, SourceType
, SourceName
)
select @TokenID, v.FormID, 'VARIABLE', v.Name
from Variables v
where ' ' + lower (v.Value +
  ISNULL (v.Value2, ' ') + ISNULL (v.Value3, ' ')) like 
  lower (@StartParse + @MethodName + @EndParse)
and v.FormID = isnull (@FormID, v.FormID)

select 
  'Form Name'   = f.Name
, 'Source Type' = uf.SourceType
, 'Source Name' = uf.SourceName
from UsesFound uf
left outer join Forms as f on
  f.ID = uf.FormID
where uf.TokenID = @TokenID
order by 1, 2, 3

delete UsesFound
where TokenID = @TokenID

return @@rowcount

GO
