SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('dbo.JIsChildOf') IS NOT NULL
   DROP FUNCTION dbo.JIsChildOf
GO
-- Run this against the Forms db
CREATE FUNCTION JIsChildOf( @ObjectID INT, @ParentFolderID INT )
RETURNS INT
AS
BEGIN
   DECLARE 
     @IsChild INT
   , @ObjectParentID INT

   SET @IsChild = 0
   SET @ObjectParentID = NULL

   SELECT @ObjectParentID = ParentFolderId
   FROM ExplorerObjects
   WHERE ObjectId = @ObjectID

   IF @ObjectParentID = @ParentFolderID
      SET @IsChild = 1
   ELSE IF NOT @ObjectParentID IS NULL
      SELECT @IsChild = dbo.IsChildOf( @ObjectParentID, @ParentFolderID )

   RETURN @IsChild      
END

GO
