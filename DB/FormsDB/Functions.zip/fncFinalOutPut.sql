SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('dbo.fncFinalOutPut') IS NOT NULL
   DROP FUNCTION dbo.fncFinalOutPut
GO

Create Function fncFinalOutPut()
Returns @finalOutPut Table(
	PName VarChar(100),
	Des VarChar(100))
As
Begin
Declare @Pname VarChar(100),
	@ListSource VarChar(1024),
	@Value VarChar(100),
	@DataSeqNo int,
	@DataValue VarChar(10),
	@DisplayValue VarChar(100),
	@blnChk Bit,
	@VarValue NVarChar(4000),
	@VarName VarChar(100)

-- Declare @finalOutPut Table(
-- 	PName VarChar(100),
-- 	Des VarChar(100))
Declare MyCursor Cursor For 
SELECT PropertyName,ListSource FROM PropertyDefaults01 
WHERE ListSource LIKE 'INLINE ENTRIES(%' and IsPropertyClassExtension=1
Open MyCursor
Fetch Next From MyCursor Into @PName,@ListSource
While (@@Fetch_Status=0)
Begin
	Set @BlnChk=1
	
-- IF Variable Store In Line List Parameters
	If CharIndex('INLINE ENTRIES(V(',@ListSource) > 0 		
	Begin
		--After Word 'INLINE ENTRIES(V('
		Set @VarName=SubString(@ListSource,18,CharIndex(')',@ListSource)-18)	
		Select @VarValue = IsNull(Value,'') + LTRIM(IsNull(Value2,'')) + LTRIM(IsNull(Value3,'')) From Variables Where Name =@VarName 
		if @VarValue = '' 
		Begin
			Set @blnChk=0 
			Goto table_Loop
		End
		Set @ListSource=Replace(@ListSource,'V(' + @VarName + ')',@VarValue)
	End			

--	If ListSource not Contain VALUE(1)  To distinguish between Value {Store in database} &  {Display}
	If IsNumeric(Replace(Right(RTrim(@ListSource),2),')',''))=0	
	Begin
		Set @blnChk=0 
	   Goto table_Loop
	End	

	--Get DataBase Storage Value Sequence that store as {Value(1 or 2)} in ListSource
	Set @DataSeqNo=Replace(Right(RTrim(@ListSource),2),')','')		
	--Store only ListSoruce (after Word [INLINE LISTSOURCE])
	Set @ListSource=SubString(@ListSource,16,CharIndex(')',@ListSource)-16)	
	
        
  
        Declare @TmpTable Table (Value VarChar(100)) 
	Declare @Pos int,@SourceString VarChar(1024)
        
        set @SourceString = @ListSource
	While (1=1)
	Begin
		Set @Pos=CharIndex(',',@SourceString)
		if (@Pos=0)
		begin
			Insert @TmpTable Values(SubString(@SourceString,1,len(LTrim(RTrim(@SourceString)))))
			break
		end
		Insert @TmpTable Values(SubString(@SourceString,1,@Pos-1))	
		Set @SourceString=LTrim(Stuff(@SourceString,1,@Pos,''))	
	End

	Declare MyCursor1 Cursor For Select * From dbo.fncBreakString(',',@ListSource)
	Open MyCursor1
	Fetch Next From MyCursor1 Into @Value	
	
	While (@@Fetch_Status=0)
	Begin
		
		if CharIndex('\',@Value) > 0		--     V\sVoucher=V
		Begin
			Select @DataValue = Case @DataSeqNo When 1 Then SubString(@Value,1,CharIndex('\',@Value)-1) 
			Else SubString(@Value,CharIndex('\',@Value)+1,Len(@Value)) End
		
			Select @DisplayValue =  Case @DataSeqNo When 1 Then SubString(@Value,CharIndex('\',@Value)+1,Len(@Value))
			Else SubString(@Value,1,CharIndex('\',@Value)-1) End
		End
		
		Select @blnChk = Case When @DisplayValue Like 's' + @PName + '=' + @DataValue Then 1 Else 0 End
		if @blnChk=0 
		Begin
			Close MyCursor1
			Deallocate MyCursor1
			Goto table_Loop
		End	
		
		Fetch Next From MyCursor1 Into @Value
	End
	Close MyCursor1
	Deallocate MyCursor1
	Set @ListSource=''

table_loop:			--Exception Put into the Temprory Table
	if @blnChk=0 
      Insert Into @FinalOutPut Values(@PName,'Warning-> In Line List Source of Property Class not in Format')						

	Fetch Next From MyCursor Into @PName,@ListSource
End
Close MyCursor
Deallocate MyCursor
Return
End

GO
