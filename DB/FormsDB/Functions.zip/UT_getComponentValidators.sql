SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('dbo.UT_getComponentValidators') IS NOT NULL
   DROP FUNCTION dbo.UT_getComponentValidators
GO
/*
This function returns all the validators of a component as CSV's

-- SetPropertyFromProperty(ObjectName2,ObjectName1),FormNameValid(P(ObjectName1),ObjectDescriptionEdit,V(ObjectTypeV))
*/
--DROP FUNCTION dbo.UT_getComponentValidators
CREATE FUNCTION dbo.UT_getComponentValidators(
  @FormID          INT
, @Component      NVARCHAR(50)
--, @CSVValidatorsAll   NVARCHAR(4000) output
)
RETURNS NVARCHAR(4000)
AS
BEGIN
   DECLARE
     @Paren               INT
   , @Period              INT
   , @Period2             INT
   , @ValLength             INT
   , @Validators          NVARCHAR(501)
   , @CCValidators          NVARCHAR(501)
   , @PCEValidators          NVARCHAR(501) 
   , @CSVValidators          NVARCHAR(501)
   , @CSVValidatorsAll          NVARCHAR(501)
   
   SELECT @Validators = validators
   FROM FormComponents
   WHERE FORMID = @FormID
   and Name = @Component

   if @Validators is null
    begin
      -- CC Validator
      SELECT @Validators = PD.validators
      FROM FormComponents FC,PropertyDefaults PD
      WHERE FORMID = @FormID
      and FC.Name = @Component
      and FC.DefaultFrom is not null
      and CHARINDEX('(',FC.DefaultFrom) > 1
      and PD.PropertyName = SUBSTRING(FC.DefaultFrom,1,CHARINDEX('(',FC.DefaultFrom)-1)
      and PD.IsPropertyClassExtension = 0
    end 

   if @Validators is null
    begin
      -- PCE Validator
      SELECT @Validators = PD.validators
      FROM FormComponents FC,PropertyDefaults PD
      WHERE FORMID = @FormID
      and FC.Name = @Component
      and FC.PropertyClassName is not null
      and PD.PropertyName = FC.PropertyClassName 
      and PD.IsPropertyClassExtension = 1
    end    
   SET @CSVValidators = @Validators
   IF @CSVValidators IS NOT NULL
   BEGIN
      IF CHARINDEX('),', @CSVValidators)> 0
      BEGIN
-- SetPropertyFromProperty(ObjectName2,ObjectName1),FormNameValid(P(ObjectName1),ObjectDescriptionEdit,V(ObjectTypeV)) 
        While (CHARINDEX('(', @CSVValidators)> 0 or CHARINDEX(')', @CSVValidators)> 0)
         BEGIN
           SET @ValLength = LEN(@CSVValidators)
           SET @Paren = 0
           SET @Period = 0
           SET @Period2 = 0
           SET @Paren = CHARINDEX('(', @CSVValidators)
           SET @Period = CHARINDEX(')', @CSVValidators)
           SET @Period2 = CHARINDEX('(', @CSVValidators,@Paren + 1 )
           --print '*****'
           --print CONVERT(nvarchar,@Paren) + '*' + CONVERT(nvarchar,@Period) + '*' + CONVERT(nvarchar,@Period2)
           --print  'All the Validators in the Begin: ' + isnull(@CSVValidatorsAll,'')
           --print  'The Validators in the Begin: ' + isnull(@CSVValidators,'')
           --print '*****' 
           IF (@Period2 > @Period) AND  @Period2 <> 0
            BEGIN
              --RETURN 
              SET  @CSVValidatorsAll = ISNULL(@CSVValidatorsAll,'') + SUBSTRING(@CSVValidators,1,@Paren-1)+ ','
              SET  @CSVValidators = RIGHT(@CSVValidators,@ValLength - @Period-1)
              --print  'One Validatoer: ' + isnull(@CSVValidatorsAll,'')
              --print  'All Validators: ' + @CSVValidators
            END
           ELSE
            BEGIN
              IF @Period2 = 0
                BEGIN
                   SET @CSVValidators = SUBSTRING(@CSVValidators,1,@Paren -1)
                   SET  @CSVValidatorsAll = ISNULL(@CSVValidatorsAll,'') + ISNULL(@CSVValidators,'') + ','
                   --print '@Period2 = 0 '
                   --print @CSVValidators
                   --print @CSVValidatorsAll 
                   --print '@Period2 = 0 End '
                END
              ELSE   
                BEGIN
                  --print  LEFT(@CSVValidators,@Period2 - 1) + '!!!!!!!!!' +  RIGHT(@CSVValidators,@ValLength - @Period)
                  SET @CSVValidators = LEFT(@CSVValidators,@Period2 - 1)+ RIGHT(@CSVValidators,@ValLength - @Period)
                  --print  'Removed () '+ @CSVValidators
                END
            END  
         END -- END While
        --RETURN @CSVValidatorsAll
      END
      Else
      BEGIN -- Comma not present
        IF CHARINDEX('(', @CSVValidators)> 0        
         BEGIN
           SET @Paren = CHARINDEX('(', @CSVValidators)
           SET @CSVValidators = SUBSTRING(@CSVValidators,1,@Paren - 1)
           --ETURN @CSVValidators    
           SET @CSVValidatorsAll = @CSVValidators
         END
        ELSE
         BEGIN            
          --RETURN @CSVValidators     
          SET @CSVValidatorsAll = @CSVValidators
         END 
      END  
      
   END
--RETURN @CSVValidators
--SET @CSVValidatorsAll = @CSVValidators
--Print 'Right @ end ' + @CSVValidatorsAll

IF (CHARINDEX(',', REVERSE(@CSVValidatorsAll)) = 1)
 BEGIN
   SET @CSVValidatorsAll = LEFT(@CSVValidatorsAll,LEN(@CSVValidatorsAll) -1)
 END
--Print 'Right @ end removed , ' + @CSVValidatorsAll
RETURN @CSVValidatorsAll
END


GO
