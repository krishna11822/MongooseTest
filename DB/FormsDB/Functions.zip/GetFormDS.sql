SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('dbo.GetFormDS') IS NOT NULL
   DROP FUNCTION dbo.GetFormDS
GO

-- Given a FormId, return the primary collection name
CREATE Function [dbo].[GetFormDS] (
   @fid as int
   )
RETURNS NVARCHAR(80) --CollectionNameType
AS
BEGIN
RETURN (
   select 
      case 
         when charindex('V(fds_DataSource)',f.primarydatasource) > 0 
         then 
            case 
               when charindex('.',v.value,charindex('SL.',v.value)+len('Sl.')) > 0
               then substring(v.value,charindex( '.', v.value)+1, ( charindex('.',v.value,charindex('SL.',v.value)+len('SL.')) - charindex( '.', v.value,0)))
               else substring(v.value,charindex( '.', v.value)+1, (charindex('(',v.value,charindex('SL.',v.value)+len('SL.')) - charindex( '.', v.value,0)) -1)
            end 
         else
            case 
               when charindex('(',substring(f.primarydatasource,charindex('SL.',f.primarydatasource)+LEN('SL.'), len(f.primarydatasource))) > 0 
               then substring( 
                      substring(f.primarydatasource,charindex('SL.',f.primarydatasource)+LEN('SL.'), len(f.primarydatasource)),
                      0,
                      charindex('(',substring(f.primarydatasource,charindex('SL.',f.primarydatasource)+LEN('SL.'), len(f.primarydatasource)))
                    )
               else substring(f.primarydatasource,charindex('SL.',f.primarydatasource)+LEN('SL.'), len(f.primarydatasource))
            end
      end
   from forms f 
   LEFT OUTER JOIN variables v ON v.formid = f.id and v.name = 'fds_DataSource'
   WHERE f.scopetype = 0
      and f.id = @fid
)
end

GO
