SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('dbo.GetCCorPCElength') IS NOT NULL
   DROP FUNCTION dbo.GetCCorPCElength
GO
CREATE FUNCTION GetCCorPCElength
(
@propertyname NVARCHAR(50),
@isPCE SMALLINT
)
RETURNS NVARCHAR(10) --Post301Type
AS
BEGIN
RETURN
(SELECT (case when
                charindex('LENGTH',post301datatype) > 0 then
                substring 
                (post301datatype, charindex('LENGTH(',post301datatype)+LEN('LENGTH('),
                        ( 
                        charindex(')',post301datatype,charindex('LENGTH(',post301datatype)) 
                        - 
                        ( charindex('LENGTH(',post301datatype)+LEN('LENGTH('))
                        ) 
                ) 
                else
                substring 
                (post301datatype, charindex('DATATYPE(',post301datatype)+LEN('DATATYPE('),
                        ( 
                        charindex(')',post301datatype,charindex('DATATYPE(',post301datatype)) 
                        - 
                        ( charindex('DATATYPE(',post301datatype)+LEN('DATATYPE('))
                        ) 
                ) 
                end)
        from propertydefaults02 where propertyname like @propertyname
        and ispropertyclassextension = @isPCE 
        and scopetype = 0 
                                --OPTION (KEEPFIXED PLAN)
)
END

GO
