SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('dbo.UT_getRoundTripCount') IS NOT NULL
   DROP FUNCTION dbo.UT_getRoundTripCount
GO
CREATE FUNCTION dbo.UT_getRoundTripCount(
  @FormID          INT
, @EventName      NVARCHAR(501)
)
RETURNS INT
AS
BEGIN
   DECLARE
     @ResponseType        INT
   , @RoundTripCount      INT
   , @Response            NVARCHAR(501)
   , @SQLString           NVARCHAR(500)



declare event_cur cursor local static for
select responsetype,response 
from FormEventHandlers
where formid =  @FormId
and
eventname = @EventName
and
(responsetype = 0 or responsetype = 21)
order by responsetype

SET @RoundTripCount = 0
if @EventName is not null
begin
open event_cur
while 1 = 1
begin
   fetch event_cur into @ResponseType,@Response
    if @@fetch_status <> 0 break
    if @ResponseType = 0
       SET @RoundTripCount = @RoundTripCount + 1
    if @ResponseType = 21
      IF CHARINDEX('(', @Response)> 0
       BEGIN
        SET @Response = SUBSTRING(@Response,1,CHARINDEX('(', @Response)-1) 
       END
       SET @RoundTripCount = @RoundTripCount + dbo.UT_getRoundTripCount(@FormID,@Response)
       
end
close event_cur
deallocate event_cur
end

RETURN @RoundTripCount

END


GO
