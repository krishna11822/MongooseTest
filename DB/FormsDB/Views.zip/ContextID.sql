SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('dbo.ContextID') IS NOT NULL
   DROP VIEW dbo.ContextID
GO

CREATE VIEW dbo.ContextID
AS
SELECT DISTINCT ContextId, FileType, Subdirectory, ContextString
FROM  dbo.HelpIDs
WHERE (ContextId IS NOT NULL)

GO
