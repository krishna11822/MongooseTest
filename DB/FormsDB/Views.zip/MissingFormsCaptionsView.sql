SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('dbo.MissingFormsCaptionsView') IS NOT NULL
   DROP VIEW dbo.MissingFormsCaptionsView
GO

CREATE VIEW MissingFormsCaptionsView (Caption, FormName, FieldName) AS
select f.Caption, f.Name AS FormName, 'FORM CAPTION' AS FieldName
from Forms as f
where not exists (select 1
from Strings as s
where s.Name = f.Caption)
and f.Caption is not null
UNION
select fc.Caption, f.Name as FormName, fc.Name AS FieldName
from FormComponents as fc
inner join Forms as f on
  f.id = fc.FormID
where not exists (select 1
from Strings as s
where s.Name = fc.Caption)
and fc.Caption is not null
and fc.Caption not like 'C(%'



GO
