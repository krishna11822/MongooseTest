SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('dbo.FormComponents') IS NOT NULL
   DROP VIEW dbo.FormComponents
GO

-- Inserting existing data into new FormComponents tables; due to the data record 
-- length limitation on SQL Server (8,060 bytes/record), we had to split this table 
-- into two (FormComponents01/FormComponents02)
CREATE VIEW [dbo].[FormComponents]
AS
SELECT   [dbo].[FormComponents01].*, [dbo].[FormComponents02].Format AS Format, 
               [dbo].[FormComponents02].FindFromSpec AS FindFromSpec, 
               [dbo].[FormComponents02].MaintainFromSpec AS MaintainFromSpec, 
               [dbo].[FormComponents02].MaxCharacters AS MaxCharacters, 
               [dbo].[FormComponents02].DefaultFrom AS DefaultFrom, 
               [dbo].[FormComponents02].MenuName AS MenuName, 
               [dbo].[FormComponents02].DataType AS DataType, 
               [dbo].[FormComponents02].ActiveXControlName AS ActiveXControlName, 
               [dbo].[FormComponents02].PropertyClassName AS PropertyClassName, 
               [dbo].[FormComponents02].Post301DataType AS Post301DataType, 
               [dbo].[FormComponents02].Post301Format AS Post301Format, 
               [dbo].[FormComponents02].Description AS Description, 
               [dbo].[FormComponents02].EffectiveCaption AS EffectiveCaption,
               [dbo].[FormComponents02].LayoutAttributes AS LayoutAttributes
FROM      [dbo].FormComponents01 INNER JOIN
               [dbo].[FormComponents02] ON 
               [dbo].[FormComponents01].FormID = [dbo].[FormComponents02].FormID AND
               [dbo].[FormComponents01].Name = [dbo].[FormComponents02].Name AND
               [dbo].[FormComponents01].DeviceID = [dbo].[FormComponents02].DeviceID
GO
