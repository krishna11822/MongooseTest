SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('dbo.PropertyDefaults') IS NOT NULL
   DROP VIEW dbo.PropertyDefaults
GO
-- Inserting existing data into new PropertyDefaults tables; due to the data record 
-- length limitation on SQL Server (8,060 bytes/record), we had to split this table 
-- into two (PropertyDefaults01/PropertyDefaults02)
CREATE VIEW [dbo].[PropertyDefaults]
AS
SELECT   [dbo].[PropertyDefaults01].*, [dbo].[PropertyDefaults02].DataType AS DataType, 
               [dbo].[PropertyDefaults02].EventToGenerate AS EventToGenerate, 
               [dbo].[PropertyDefaults02].SelectionEventToGenerate AS SelectionEventToGenerate,
               [dbo].[PropertyDefaults02].LoseFocusEventToGenerate AS LoseFocusEventToGenerate,
               [dbo].[PropertyDefaults02].GainFocusEventToGenerate AS GainFocusEventToGenerate,
               [dbo].[PropertyDefaults02].HelpString AS HelpString, 
               [dbo].[PropertyDefaults02].HelpFileName AS HelpFileName, 
               [dbo].[PropertyDefaults02].MenuName AS MenuName, 
               [dbo].[PropertyDefaults02].Post301DataType AS Post301DataType, 
               [dbo].[PropertyDefaults02].Post301Format AS Post301Format
FROM      [dbo].[PropertyDefaults01] INNER JOIN
               [dbo].[PropertyDefaults02] ON 
               [dbo].[PropertyDefaults01].PropertyName = [dbo].[PropertyDefaults02].PropertyName AND
               [dbo].[PropertyDefaults01].ScopeType = [dbo].[PropertyDefaults02].ScopeType AND 
               [dbo].[PropertyDefaults01].ScopeName = [dbo].[PropertyDefaults02].ScopeName AND 
               [dbo].[PropertyDefaults01].IsPropertyClassExtension = [dbo].[PropertyDefaults02].IsPropertyClassExtension

GO
