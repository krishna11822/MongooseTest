IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DigitsInProgressFormat]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[DigitsInProgressFormat]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION dbo.DigitsInProgressFormat (
  @ProgressFormat nvarchar(40)
) RETURNS tinyint
AS
BEGIN
   DECLARE @Digits tinyint
   SET @Digits = 0

   DECLARE @i smallint
   SET @i = 1
   WHILE @i <= len(@ProgressFormat)
   BEGIN
      IF CHARINDEX(SUBSTRING(@ProgressFormat, @i, 1), 'z9>*') > 0
         SET @Digits = @Digits + 1

      SET @i = @i + 1
   END
   RETURN @Digits
END

GO
