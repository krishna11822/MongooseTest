IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Pluralize]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[Pluralize]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Returns the plural version of @Word
CREATE FUNCTION dbo.Pluralize (
  @Word sysname
) RETURNS sysname
AS
BEGIN
   RETURN
   CASE
      WHEN @Word LIKE '%s' THEN @Word
      WHEN @Word LIKE '%y' THEN SUBSTRING(@Word, 1, LEN(@Word) - 1) + 'ies'
      ELSE @Word + 's'
   END
END

GO
