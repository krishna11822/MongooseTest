IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[NewProjectName]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[NewProjectName]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Determines the Unitecture Project name (PROJECT.NAME) corresponding to a SL7 IDO name (Collections.CollectionName).
CREATE FUNCTION dbo.NewProjectName (
  @CollectionName sysname
) RETURNS sysname
AS
BEGIN
   DECLARE @Result sysname
   SELECT @Result = ServerName FROM ObjCollections
      WHERE CollectionName = @CollectionName
      AND DevelopmentFlag = 0

   RETURN @Result
END

GO
