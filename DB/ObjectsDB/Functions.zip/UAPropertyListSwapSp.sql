IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UAPropertyListSwapSp]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[UAPropertyListSwapSp]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--  Some Property names I am swapping as they come over because they didn't
-- make sense in 
CREATE FUNCTION dbo.UAPropertyListSwapSp (
  @PropertyName SYSNAME
) RETURNS SYSNAME
AS
BEGIN
   RETURN CASE WHEN @PropertyName IS NULL THEN 'FIXIT'
      WHEN @Propertyname = 'ApsInt' THEN 'MpxInt'
      WHEN @PropertyName = 'ApsSmallInt' THEN 'MpxShortInt'
      WHEN @PropertyName = 'RowPointer' THEN 'MpxGuid'
      ELSE @PropertyName
   END
END

GO
