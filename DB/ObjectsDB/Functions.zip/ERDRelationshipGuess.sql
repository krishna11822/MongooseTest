IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ERDRelationshipGuess]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[ERDRelationshipGuess]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION dbo.ERDRelationshipGuess (
  @OwnerTable sysname
, @OwnerKey sysname
, @MemberType as tinyint
, @MemberTable sysname
, @MemberKey sysname
)
RETURNS nvarchar(4000) AS
BEGIN
   DECLARE @Extends sysname, @Contains sysname, @RefersTo sysname,
      @ExtendedBy sysname, @ContainedBy sysname, @ReferredToBy sysname
   SET @Extends = 'Extends'
   SET @Contains = 'Contains'
   SET @RefersTo = 'Refers To'
   SET @ExtendedBy = 'Extended By'
   SET @ContainedBy = 'Contained By'
   SET @ReferredToBy = 'Referred To By'

RETURN
   case @MemberType
      when 3 then
         case
            when @MemberTable in ('custaddr', 'vendaddr')
               then @Extends
            when @MemberTable < @OwnerTable
               then @Extends
            else @ExtendedBy
         end
      when 1 then @Contains
      when 2 then @RefersTo
      when 4 then @ContainedBy
      when 5 then @ReferredToBy
      -- "New" relationships in SL7.04 (& 7.03?)  For columns/tables added after we generated ERD data:
      else 
      case
         -- Common relationships:
         when @MemberTable = 'chart' and @MemberKey = 'acct' then @RefersTo
         when @MemberTable = 'LanguageIDs' and @MemberKey = 'LanguageCode' then @RefersTo
         when @MemberTable = 'shipcode' and @MemberKey = 'transport' then @RefersTo   -- Issue 83011
         when @MemberTable = 'country' and @MemberKey = 'ssd_ec_code' then @RefersTo  -- Issue 83014
         when @OwnerTable = 'coitem' and @MemberTable = 'job' then @ReferredToBy
         --when @MemberTable = '' and @MemberKey = '' then @RefersTo
         --when @MemberTable = '' and @MemberKey = '' then @RefersTo
         --when @MemberTable = '' and @MemberKey = '' then @RefersTo
         --when @MemberTable = '' and @MemberKey = '' then @RefersTo
         --when @MemberKey = 'RowPointer' and @OwnerKey like '%RowPointer' then @RefersTo
         -- Member keys are primary:
         when 1 = dbo.IsInList(dbo.PrimaryIndexKeyString(@MemberTable), @MemberKey) then
            case dbo.IsInList(dbo.PrimaryIndexKeyString(@OwnerTable), @OwnerKey)
            -- Owner keys are also primary = must be a Parent/Child:
            when 1
            then /* Composition */
            case
               -- Owner has more primary keys = Owner is the child
               when dbo.NumEntries(dbo.PrimaryIndexKeyString(@MemberTable), ',')
                  < dbo.NumEntries(dbo.PrimaryIndexKeyString(@OwnerTable), ',')
                  then @ContainedBy
               -- Member has more primary keys = Owner is the parent
               when dbo.NumEntries(dbo.PrimaryIndexKeyString(@MemberTable), ',')
                  > dbo.NumEntries(dbo.PrimaryIndexKeyString(@OwnerTable), ',')
                  then @Contains
               -- All *parms Extend parms, alphabetically
               when @MemberTable = 'parms' then @Extends
               when @MemberKey = 'parm_key' then
                  case when @MemberTable < @OwnerTable then @Extends else @ExtendedBy end
               -- UserNames is the base
               when @MemberTable = 'UserNames' and @MemberKey = 'UserId'
                  then @Extends
               -- Unknown!
               else null
            end
            else @RefersTo
            end
         -- Unknown!
         else NULL --'Refers'
      end
   end
END

GO
