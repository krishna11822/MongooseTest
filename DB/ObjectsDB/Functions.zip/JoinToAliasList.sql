IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[JoinToAliasList]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[JoinToAliasList]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Returns the unique comma-separated list of table-aliases prefixing key-columns
-- on the other side of the equals-signs from those prefixed by the @TableAlias
-- within the @JoinClause.  Ignores "EXISTS()" clauses and other non-equality conjoinees.
-- Treats unqualified left-hand columns as being prefixed by the @TableAlias.
CREATE FUNCTION dbo.JoinToAliasList (
  @JoinClause nvarchar(4000)
, @TableAlias sysname
)
RETURNS nvarchar(4000) AS
BEGIN
   /* Debug:
   DECLARE @JoinClause nvarchar(4000), @TableAlias sysname
   SET @TableAlias = 'Trx' SET @JoinClause = 'Trx.site_ref = Sgrp.site and Trx.active = 1 and Trx.type = ''V'''
   SET @TableAlias = 'jobroute' SET @JoinClause = 'jobroute.suffix = job.suffix AND jobroute.job = job.job and job.job = item.job and job.suffix = 0'
    */

   DECLARE @Result nvarchar(4000)

   DECLARE @Keys int
   SET @Keys = dbo.NumEntries(@JoinClause, ' and ')
   /* Debug:
   PRINT @Keys
    */
   DECLARE @i int
   SET @i = 1
   WHILE @i <= @Keys
   BEGIN
      IF @Result IS NULL
         SET @Result = ''
      DECLARE @KeyClause nvarchar(4000)
      SET @KeyClause = dbo.Entry(@i, @JoinClause, ' and ')
      /* Debug:
      PRINT @KeyClause
      PRINT dbo.NumEntries(@KeyClause, '=')
       */
      IF @KeyClause LIKE 'exists%'
      OR @KeyClause LIKE '(%)' BREAK
      IF dbo.NumEntries(@KeyClause, '=') <> 2 BREAK

      DECLARE @Key1 nvarchar(4000), @Key2 nvarchar(4000)
      SET @Key1 = LTRIM(RTRIM(REPLACE(REPLACE(dbo.Entry(1, @KeyClause, '='), '(', ' '), ')', ' ')))
      SET @Key2 = LTRIM(RTRIM(REPLACE(REPLACE(dbo.Entry(2, @KeyClause, '='), '(', ' '), ')', ' ')))
      /* Debug:
      PRINT @Key1
      PRINT @Key2
       */

      DECLARE @JoinToKey nvarchar(4000)
      -- If First Key consists of a Column without "table."
      IF CHARINDEX('.', @Key1) = 0 AND CHARINDEX(SUBSTRING(@Key1, 1, 1), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ') > 0
         -- Prepend the Table Alias followed by a period:
         SET @Key1 = @TableAlias + '.' + @Key1

      -- If Column prefixed by joining table's alias:
      IF @Key1 LIKE @TableAlias + '.%'
         -- ... then we want to get the table alias from the second key:
         SET @JoinToKey = @Key2
      ELSE
      BEGIN
         -- Otherwise,
         -- If Second Key consists of a column prefixed by something other than the joining table's alias:
         IF CHARINDEX('.', @Key2) > 0 AND CHARINDEX(' ', @Key2) = 0
         AND @Key2 NOT LIKE @TableAlias + '.%'
         BEGIN
            -- Get the table alias from the second key also!
            DECLARE @JoinToAlias2 sysname
            SET @JoinToAlias2 = dbo.Entry(1, @Key2, '.')
            IF dbo.IsInList(@Result, @JoinToAlias2) = 0
               SET @Result = CASE WHEN @Result IS NULL OR @Result = '' THEN '' ELSE @Result + ',' END
                  + @JoinToAlias2
         END

         -- Now get the table alias from the first key:
         SET @JoinToKey = @Key1
      END

      DECLARE @JoinToAlias sysname
      IF CHARINDEX('.', @JoinToKey) > 0 AND CHARINDEX(' ', @JoinToKey) = 0
         SET @JoinToAlias = dbo.Entry(1, @JoinToKey, '.')
      ELSE
         SET @JoinToAlias = NULL

      /* Debug:
      PRINT @JoinToKey
      PRINT @JoinToAlias
       */

      IF @JoinToAlias IS NOT NULL
      BEGIN
         IF dbo.IsInList(@Result, @JoinToAlias) = 0
            SET @Result = CASE WHEN @Result IS NULL OR @Result = '' THEN '' ELSE @Result + ',' END
               + @JoinToAlias
      END

      SET @i = @i + 1
   END
   /* Debug:
   PRINT @Result
    */
   RETURN @Result
END

GO
