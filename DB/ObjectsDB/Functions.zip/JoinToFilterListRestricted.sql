IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[JoinToFilterListRestricted]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[JoinToFilterListRestricted]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Returns the part of @JoinClause NOT corresponding to the conjoined list of equality comparisons
-- corresponding to @KeyList, or if that is NULL then to dbo.JoinToKeyList(@JoinClause, @TableAlias) and dbo.JoinToExpressionList(@JoinClause, @TableAlias).
CREATE FUNCTION dbo.JoinToFilterListRestricted (
  @JoinClause nvarchar(4000)
, @TableAlias sysname
, @KeyList nvarchar(2000) = null
)
RETURNS nvarchar(4000) AS
BEGIN
   -- Debugging:  DECLARE @JoinClause nvarchar(4000), @TableAlias sysname, @KeyList nvarchar(2000)
   -- Debugging:  SET @TableAlias = 'Trx' SET @JoinClause = 'Trx.site_ref = Sgrp.site and Trx.active = 1 and Trx.type = ''V'''
   -- Debugging:  SET @TableAlias = 'pri' SET @JoinClause = 'pri.item = itmcst.item AND (pri.curr_code = CASE WHEN EXISTS (SELECT 1 FROM Itemprice pri3 WHERE ((pri3.curr_code = adr.curr_code) AND (pri3.effect_date <= dbo.GetSiteDate(getdate()) ) ) ) THEN adr.curr_code ELSE  parm.curr_code End) and (pri.effect_date = .............................'
   -- Debugging:  SET @TableAlias = 'itm' SET @JoinClause = 'job.item = itm.item  AND (itm.job = job.job or job.type <> ''S'')'
   -- Debugging:  SET @TableAlias = 'commdue' SET @JoinClause = 'commdue.stat=''P'' AND commdue.emp_num=appmtd.vend_num AND (appmt.pay_type=''M'' OR commdue.comm_due <> commdue.comm_paid)' set @KeyList = N'inv_num'
   -- Debugging:  SET @TableAlias = 'aptrxp' SET @JoinClause = 'aptrxp.vend_num=aptrx.vend_num AND aptrxp.type=''V''' set @KeyList = N'vend_num,voucher'



   DECLARE @IgnoreKeyExpressions bit
   SET @IgnoreKeyExpressions = 1 - dbo.CanCompareKeysToExpressions()

   DECLARE @Result nvarchar(4000)

   DECLARE @Keys int
   SET @Keys = dbo.NumEntries(@JoinClause, ' and ')
   -- Debugging:  PRINT @Keys

   DECLARE @i int
   SET @i = 1
   DECLARE @KeepGoingRegardless bit
   SET @KeepGoingRegardless = 0
   WHILE @i <= @Keys
   BEGIN
      IF @Result IS NULL
         SET @Result = ''
      DECLARE @KeyClause nvarchar(4000)
      SET @KeyClause = dbo.Entry(@i, @JoinClause, ' and ')
      -- Debugging:  PRINT @KeyClause   PRINT dbo.NumEntries(@KeyClause, '=')

      IF @KeepGoingRegardless = 1
      OR @KeyClause LIKE 'exists%'
      OR @KeyClause LIKE '(%)'
      OR dbo.NumEntries(@KeyClause, '=') <> 2
      BEGIN
         SET @Result = CASE WHEN @Result IS NULL OR @Result = '' THEN '' ELSE @Result + ' AND ' END
               + LTRIM(RTRIM(@KeyClause))
         SET @i = @i + 1
         SET @KeepGoingRegardless = 1
         CONTINUE
      END

      DECLARE @Key1 nvarchar(4000), @Key2 nvarchar(4000)
      SET @Key1 = LTRIM(RTRIM(REPLACE(REPLACE(dbo.Entry(1, @KeyClause, '='), '(', ' '), ')', ' ')))
      SET @Key2 = LTRIM(RTRIM(REPLACE(REPLACE(dbo.Entry(2, @KeyClause, '='), '(', ' '), ')', ' ')))
      -- Debugging:  PRINT @Key1 PRINT @Key2

      DECLARE @ThisKey nvarchar(4000)
      DECLARE @OtherKey nvarchar(4000)
      -- Does not contain a period
      IF CHARINDEX('.', @Key1) = 0
         -- ...and begins with a letter:
         AND CHARINDEX(SUBSTRING(@Key1, 1, 1), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ') > 0
         -- ...but is not a Unicode string constant:
         AND @Key1 NOT LIKE 'N''%'
         -- (i.e., is only the unqualified column name)
         -- Prepend the Table Alias followed by a period:
         SET @Key1 = @TableAlias + '.' + @Key1

      -- Begins with the Table Alias followed by a period:
      IF @Key1 LIKE @TableAlias + '.%'
      BEGIN
         SET @ThisKey = @Key1
         SET @OtherKey = @Key2
      END
      ELSE
      BEGIN
         SET @ThisKey = @Key2
         SET @OtherKey = @Key1
      END
      -- Debugging:  print @ThisKey  print dbo.ENTRY(2, @ThisKey, N'.')  print dbo.Lookup(dbo.ENTRY(2, @ThisKey, N'.'), @KeyList, N',')

      -- 
      IF NOT (
         -- This Key is a table.column:
         CHARINDEX('.', @ThisKey) > 0 AND CHARINDEX(' ', @ThisKey) = 0
         -- and Other Key is a table.column, or we're accepting expressions:
         AND (@IgnoreKeyExpressions = 0
            OR CHARINDEX('.', @OtherKey) > 0 AND CHARINDEX(' ', @OtherKey) = 0)
         -- and we're considering all keys, or This Key is one we're considering:
         AND (@KeyList IS NULL OR dbo.Lookup(dbo.ENTRY(2, @ThisKey, N'.'), @KeyList, N',') > 0)
         )
         SET @Result = CASE WHEN @Result IS NULL OR @Result = '' THEN '' ELSE @Result + ' AND ' END
            + LTRIM(RTRIM(@KeyClause))

/*    IF @MaxKeys IS NOT NULL
      AND dbo.NumEntries(@Result, ',') >= @MaxKeys
         BREAK */

      SET @i = @i + 1
   END
   -- Debug:  PRINT @Result

   RETURN @Result
END

GO
