IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PrimaryBaseTable]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[PrimaryBaseTable]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Returns the Primary Base Table of a SL7 IDO (Collections.CollectionName).
CREATE FUNCTION dbo.PrimaryBaseTable (
  @CollectionName sysname
) RETURNS sysname
AS
BEGIN
   RETURN (
      SELECT PrimaryBaseTable.TableName
      FROM bo.Collections as IDO
      INNER JOIN bo.Tables AS PrimaryBaseTable
         ON PrimaryBaseTable.CollectionName = IDO.CollectionName AND PrimaryBaseTable.TableType = 3
      WHERE IDO.CollectionName = @CollectionName
      AND IDO.DevelopmentFlag = 0
      AND PrimaryBaseTable.DevelopmentFlag = 0
      )
END

GO
