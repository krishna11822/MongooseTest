IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SLBaseIDOName]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[SLBaseIDOName]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Returns the standard IDO name of the object based on @TableName
CREATE FUNCTION dbo.SLBaseIDOName (
  @TableName sysname
) RETURNS sysname
AS
BEGIN
   IF @TableName is null
      RETURN NULL

   RETURN
   dbo.NewIDOQualifier(dbo.DefaultProject(@TableName))
   + CASE WHEN dbo.KeepSLPrefix() = 1 THEN 'SL' ELSE '' END
   + CASE WHEN dbo.KeepPluralSuffix() = 1
      THEN dbo.Pluralize(dbo.Hungarianize(@TableName))
      ELSE dbo.Singularize(dbo.Hungarianize(@TableName))
     END
END

GO
