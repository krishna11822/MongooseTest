IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PrefixColumnOrTRIMParentheses]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[PrefixColumnOrTRIMParentheses]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- If @String is surrounded by parentheses, remove them.
-- Otherwise prefix @String as if it were a column-name.
CREATE FUNCTION dbo.PrefixColumnOrTRIMParentheses (
  @String nvarchar(4000)
   , @Prefix sysname
)
RETURNS nvarchar(4000) AS
BEGIN
   IF @String like '(%)'
      RETURN substring(@String, 2, len(@String) - 2)
   --ELSE
   RETURN @Prefix + '.' + @String
END

GO
