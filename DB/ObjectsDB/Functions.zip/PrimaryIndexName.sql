IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PrimaryIndexName]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[PrimaryIndexName]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Returns the name of the index most probably corresponding to
-- @TableName's SyteLine 6 Primary Index.
CREATE FUNCTION dbo.PrimaryIndexName (
  @TableName sysname
) RETURNS sysname
AS
BEGIN
   DECLARE @Result sysname
   DECLARE @KeyString nvarchar(4000)

   -- PK_itemwhse is backwards!  (Compared to PK_itemloc & PK_lot_loc):
   IF @TableName = N'itemwhse'
      RETURN N'IX_itemwhse_whseitem'

   -- First look for a PK_* Primary Key:
   SET @Result = N'PK_' + @TableName
   SET @KeyString = OH_App.dbo.IndexKeyString(@Result, @TableName)

   -- If RowPointer was promoted to Primary, use the demoted index:
   IF @KeyString = 'RowPointer'
   BEGIN
      SET @Result = N'IX_' + @TableName
      SET @KeyString = OH_App.dbo.IndexKeyString(@Result, @TableName)
   END

   -- If neither of those were found, try the Clustered Index:
   IF @KeyString = N''
   BEGIN
      SET @Result = (SELECT name from OH_App.dbo.sysindexes as idx
         WHERE id = OBJECT_ID('OH_App.dbo.' + @TableName)
            and indid = 1)
      SET @KeyString = OH_App.dbo.IndexKeyString(@Result, @TableName)
   END

   -- If RowPointer is Clustered (Issue 84xxx), revert to the Primary Key:
   IF @KeyString = 'RowPointer'
      SET @Result = (SELECT name from OH_App.dbo.sysobjects as idx
         WHERE parent_obj = OBJECT_ID('OH_App.dbo.' + @TableName)
            and xtype = N'PK')

   RETURN @Result
END

GO
