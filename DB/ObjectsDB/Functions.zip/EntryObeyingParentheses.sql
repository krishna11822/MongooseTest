IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EntryObeyingParentheses]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[EntryObeyingParentheses]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Returns the @Entry-th @Delim-separated element of the @List,
-- ignoring @Delim's within elements enclosed completely in parentheses,
-- or NULL if there aren't that many entries.
CREATE FUNCTION dbo.EntryObeyingParentheses (
  @Entry     INT
, @List      nvarchar(4000)
, @Delim     nvarchar(4000) = N','
)
RETURNS nvarchar(4000) AS
BEGIN
   DECLARE
     @Result nvarchar(4000)
   , @i INT

   SET @Result = NULL
   SET @i = 1

   WHILE @i < @Entry
   BEGIN
      IF CHARINDEX(@Delim, @List) = 0
         RETURN NULL
      IF SUBSTRING(@List, 1, 1) = N'('
         SET @List = SUBSTRING(@List, 2 + LEN(dbo.ParenString(SUBSTRING(@List, 2, LEN(@List)))) + 1 + dbo.TrueLEN(@Delim), LEN(@List))
      ELSE
      SET @List = SUBSTRING(@List, CHARINDEX(@Delim, @List) + dbo.TrueLEN(@Delim), LEN(@List))

      SET @i = @i + 1
   END

   IF CHARINDEX(@Delim, @List) > 0
   BEGIN
      IF SUBSTRING(@List, 1, 1) = N'('
         SET @Result = N'(' + dbo.ParenString(SUBSTRING(@List, 2, LEN(@List))) + N')'
      ELSE
      SET @Result = SUBSTRING(@List, 1, CHARINDEX(@Delim, @List) - 1)
   END
   ELSE
      SET @Result = @List

   RETURN @Result

END

GO
