IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ResolveSecondaryCollectionProperties]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[ResolveSecondaryCollectionProperties]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Substitute, in @Filter, wrapped Property Names prefixed by a Secondary Collection number, with their bound table.column or implementation.
CREATE FUNCTION dbo.ResolveSecondaryCollectionProperties (
  @FormId int,
  @Filter nvarchar(4000)
) RETURNS nvarchar(4000)
AS
BEGIN
   IF @Filter is null
      RETURN NULL
   IF @Filter not like N'%P([0-9]%'
      RETURN @Filter

   -- Debugging:  declare @FormId int, @Filter nvarchar(4000)
   -- Debugging:  set @FormId = 35157 /* EngineeringWorkbench */ set @Filter = N'jobroute.job=FP(12.Job) AND jobroute.suffix=FP(12.Suffix)'

   DECLARE @AnySubstitutions bit
   SET @AnySubstitutions = 1

   WHILE @AnySubstitutions = 1
   BEGIN
      SET @AnySubstitutions = 0
      DECLARE @NewValue nvarchar(4000)
   
      -- Since this function is called only 4 times, we don't need to super-optimize it.  :-)
      DECLARE fc cursor local static for
      SELECT CollectionNumber, CollectionName
         FROM FormCollections
         WHERE FormId = @FormId
         AND CollectionNumber > 1
         -- Unnecessary because all occurrences are wrapped:  ORDER BY CollectionNumber DESC
      OPEN fc
      WHILE 1=1
      BEGIN
         DECLARE @CollNum int, @CollectionName NVARCHAR(30)
         FETCH fc INTO @CollNum, @CollectionName
         IF @@FETCH_STATUS < 0 BREAK

         -- Debugging:  print N'Working on Secondary Collection ' + cast(@CollNum as nvarchar) + N': ' + @CollectionName

         declare Props_cursor3 cursor local static for
         SELECT PropertyName, ISNULL(PropertyValue, Tables.TableName + '.' + ColumnName) as Implementation
         FROM bo.Properties as Properties
         LEFT OUTER JOIN bo.Tables as Tables ON Tables.TableId = ColumnTableId
         WHERE Properties.CollectionName = @CollectionName
         AND Properties.DevelopmentFlag = 0
         AND ISNULL(PropertyValue, Tables.TableName + '.' + ColumnName) is not null
         -- Unnecessary because all occurrences are wrapped:  ORDER BY LEN(PropertyName) DESC, PropertyName DESC
      
         OPEN Props_cursor3
         WHILE 1=1
         BEGIN
            DECLARE @PropertyName sysname, @Implementation nvarchar(4000)
            FETCH Props_cursor3 INTO @PropertyName, @Implementation
            IF @@FETCH_STATUS < 0 BREAK
   
            -- Debugging:  print N'   Working on Property: ' + @CollectionName + N'.' + @PropertyName

            DECLARE @ObjectDot sysname
            SET @ObjectDot = cast(@CollNum as nvarchar) + N'.'

            DECLARE @case tinyint
            SET @case = 1
            WHILE @case <= 4
            BEGIN
               DECLARE @Prefix sysname, @Suffix sysname
               SET @Prefix = case @Case
                  WHEN 1 THEN N'''FP('
                  WHEN 2 THEN N'''P('
                  WHEN 3 THEN N'FP('
                  WHEN 4 THEN N'P('
                  END
               SET @Suffix = case
                  WHEN @case <= 2 THEN N')'''
                  ELSE N')'
                  END

               SET @NewValue = CaseSensitive.dbo.CSReplace(@Filter, @Prefix + @ObjectDot + @PropertyName + @Suffix, @Implementation)
               IF @NewValue <> @Filter
               BEGIN
                  SET @Filter = @NewValue
                  -- Debugging:  print N'Replacing: [' + @Prefix + @ObjectDot + @PropertyName + @Suffix + N'] with [' + @Implementation + N']'
                  -- Debugging:  print @Filter

                  IF @Filter not like N'%P([0-9]%'
                     GOTO exit_label

                  SET @AnySubstitutions = 1
               END
               SET @case = @case + 1
            END
         END
         CLOSE Props_cursor3
         DEALLOCATE Props_cursor3
      END
      CLOSE fc
      DEALLOCATE fc
   END

   exit_label:

   -- Debugging:  print @Filter

   RETURN @Filter
END

GO
