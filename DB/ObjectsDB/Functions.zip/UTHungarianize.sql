IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UTHungarianize]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[UTHungarianize]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE  FUNCTION UTHungarianize  
(  
--The string to be converted to proper case  
@Input varchar(30),  
@Prefix varchar(5) = NULL,  
@Suffix varchar(5) = NULL  
)  
--This function returns the proper case string of varchar type  
RETURNS varchar(40)  
AS  
BEGIN  
 IF @Input IS NULL   
 BEGIN  
  --Just return NULL if TableName string is NULL  
  RETURN NULL  
 END  
  
  
DECLARE @output varchar(40)  
 --Integer variable declarations  
 DECLARE @ctr int, @len int, @found_at int  
 --Constant declarations  
 DECLARE @LOWER_CASE_a int, @LOWER_CASE_z int, @Delimiter char(3), @UPPER_CASE_A int, @UPPER_CASE_Z int  
   
 --Variable/Constant initializations  
 SET @ctr = 1  
 SET @len = LEN(@input)  
 SET @output = ''  
 SET @LOWER_CASE_a = 97  
 SET @LOWER_CASE_z = 122  
 SET @Delimiter = ' ,-'  
 SET @UPPER_CASE_A = 65  
 SET @UPPER_CASE_Z = 90  
   
 WHILE @ctr <= @len  
 BEGIN  
  --This loop will take care of reccuring white spaces  
  WHILE CHARINDEX(SUBSTRING(@input,@ctr,1), @Delimiter) > 0  
  BEGIN  
   SET @output = @output + SUBSTRING(@input,@ctr,1)  
   SET @ctr = @ctr + 1  
  END  
  
  IF ASCII(SUBSTRING(@input,@ctr,1)) BETWEEN @LOWER_CASE_a AND @LOWER_CASE_z  
  BEGIN  
   --Converting the first character to upper case  
   SET @output = @output + UPPER(SUBSTRING(@input,@ctr,1))  
  END  
  ELSE  
  BEGIN  
   SET @output = @output + SUBSTRING(@input,@ctr,1)  
  END  
    
  SET @ctr = @ctr + 1  
  
  WHILE CHARINDEX(SUBSTRING(@input,@ctr,1), @Delimiter) = 0 AND (@ctr <= @len)  
  BEGIN  
   IF ASCII(SUBSTRING(@input,@ctr,1)) BETWEEN @UPPER_CASE_A AND @UPPER_CASE_Z  
   BEGIN  
    SET @output = @output + LOWER(SUBSTRING(@input,@ctr,1))  
   END  
   ELSE  
   BEGIN  
    SET @output = @output + SUBSTRING(@input,@ctr,1)  
   END  
   SET @ctr = @ctr + 1  
  END  
    
 END  
  
  
    SET @Input = @output  
      
  
While CHARINDEX('_',@Input) > 0  
    SET @Input =  STUFF(@Input,CHARINDEX('_',@Input),2,UPPER(SUBSTRING(@Input,CHARINDEX('_',@Input)+1,1)))  
  
IF CHARINDEX('##',@Input) > 0   
   SET @Input = REPLACE(@Input,'##','_')  
   
IF @Prefix IS NOT NULL   
   SET @Input =  STUFF(@Input,1,1,@Prefix + UPPER(SUBSTRING(@Input,1,1)))  
  
IF @Suffix IS NOT NULL   
   SET @Input = STUFF(@Input,Len(@Input),1,SUBSTRING(@Input,Len(@Input),1)+@Suffix)  
  
   
RETURN @Input  
END  
  
  


GO
