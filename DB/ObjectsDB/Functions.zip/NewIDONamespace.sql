IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[NewIDONamespace]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[NewIDONamespace]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Determines a Unitecture IDO qualifier (dotted segments before IDO Name) from a SL7 Project (Collections.ServerName)
CREATE FUNCTION dbo.NewIDONamespace (
  @Project sysname
) RETURNS sysname
AS
BEGIN
   DECLARE @KeepSLPrefix bit
   SET @KeepSLPrefix = dbo.KeepSLPrefix()

   RETURN
   'Mapics.Framework.'
   /*
   + CASE WHEN @Project = 'Core'
      THEN 'UA'
      ELSE 'SL'
   END
    */
END

GO
