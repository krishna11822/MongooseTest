IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[KeepPluralSuffix]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[KeepPluralSuffix]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Returns 1 if and only if Unitecture SyteLine IDOs will be plural.
CREATE FUNCTION dbo.KeepPluralSuffix () RETURNS bit
AS
BEGIN
   RETURN 0
END

GO
