IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ObjectStudioReplace]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[ObjectStudioReplace]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Recursively substitute, in @String, optionally wrapped Property Names with their bound table.column or implementation.
CREATE FUNCTION dbo.ObjectStudioReplace (
  @CollectionName sysname,
  @CollectionName0 sysname,
  @String nvarchar(4000),
  @FormID int = null
) RETURNS nvarchar(4000)
AS
BEGIN
   IF @String is null
      RETURN NULL

   -- Debugging:  declare @CollectionName sysname, @CollectionName0 sysname, @String nvarchar(4000), @FormID int
   -- Debugging:  set @CollectionName = N'SLShift000s'  set @String = N'SHIFTID <> ''DSC'''
   -- Debugging:  set @CollectionName = N'SLCoShips'  set @String = N'CoFixedRate=0 and DoNum is null and QtyShipped > QtyInvoiced AND QtyReturned=0 and (FP(DerNumSeqs) <=0 or FP(DerFirstDoSeqCoUseExchRate)=CoUseExchRate)'
   -- Debugging:  set @CollectionName = N'SLDoHdrs'  set @Wrapped = 1
   -- Debugging:  set @CollectionName = N'SLAppmtds'  set @Wrapped = 1  set @String = N'VendNum=''P(VendNum)'' AND PayType=''P(AppmtPayType)'' AND CheckNum=appmt.check_num'
   -- Debugging:  ShippingProcessingOrders  set @FormId = 34683  set @CollectionName = N'SLShipprocs'  set @CollectionName0 = N'SLShipprocs'  set @String = N'CustNum like ISNULL(FP(SLShipCos.CoCustNum),''%'') AND CustSeq like ISNULL(FP(SLShipCos.CustSeq),''%'') AND Stat=''I'''
   -- Debugging:  EmploymentEligibility  set @FormId = 33162  set @CollectionName = N'SLEmpI9s'  set @CollectionName0 = N'SLEmpI9s'  set @String = N'i9doc.listid=''P(I9doc1listid)'''


   DECLARE @Wrapped bit
   SET @Wrapped = case when @FormID is null then 0 else 1 end

   IF @Wrapped = 1
   BEGIN
      IF @String not like N'%P(%'
         -- Debugging:  begin  print N'Quick exit!  No more P('  goto exit_label  end
         RETURN @String

      DECLARE @CollNum int
      SET @CollNum = -1
      WHILE 1=1
      BEGIN
         -- On first time through, proceed using @CollectionName

         DECLARE @AnySubstitutions bit
         SET @AnySubstitutions = 1
   
         WHILE @AnySubstitutions = 1
         BEGIN
            SET @AnySubstitutions = 0
            DECLARE @NewValue nvarchar(4000)
         
            declare Props_cursor3 cursor local static for
            SELECT PropertyName, ISNULL(PropertyValue, Tables.TableName + '.' + ColumnName) as Implementation
            FROM bo.Properties as Properties
            LEFT OUTER JOIN bo.Tables as Tables ON Tables.TableId = ColumnTableId
            WHERE Properties.CollectionName = @CollectionName
            AND Properties.DevelopmentFlag = 0
            AND ISNULL(PropertyValue, Tables.TableName + '.' + ColumnName) is not null
            -- Don't need to sort since we're always wrapping in this mode:  ORDER BY LEN(PropertyName) DESC, PropertyName DESC
         
            OPEN Props_cursor3
            WHILE 1=1
            BEGIN
               DECLARE @PropertyName sysname, @Implementation nvarchar(4000)
               FETCH Props_cursor3 INTO @PropertyName, @Implementation
               IF @@FETCH_STATUS < 0 BREAK
      
               -- Debugging:  print N'   Working on Property: ' + @CollectionName + N'.' + @PropertyName
   
               DECLARE @UseCollectionPrefix bit
               IF @UseCollectionPrefix = 1
                  SET @PropertyName = @CollectionName + N'.' + @PropertyName

               DECLARE @case tinyint
               SET @case = 1
               WHILE @case <= 4
               BEGIN
                  DECLARE @Prefix sysname, @Suffix sysname
                  SET @Prefix = case @Case
                     WHEN 1 THEN N'''FP('
                     WHEN 2 THEN N'''P('
                     WHEN 3 THEN N'FP('
                     WHEN 4 THEN N'P('
                     END
                  SET @Suffix = case
                     WHEN @case <= 2 THEN N')'''
                     ELSE N')'
                     END
   
                  SET @NewValue = Replace(@String, @Prefix + @PropertyName + @Suffix, @Implementation)
                  IF @NewValue <> @String
                  BEGIN
                     SET @String = @NewValue
                     -- Debugging:  print N'Replacing: [' + @Prefix + @PropertyName + @Suffix + N'] with [' + @Implementation + N']'
                     -- Debugging:  print @String
   
                     IF @String not like N'%P(%'
                     BEGIN
                        -- Debugging:  print N'Quick exit!  No more P('
                        GOTO exit_label
                     END

                     SET @AnySubstitutions = 1
                     --GOTO next_wrapper
                  END
   
                  /* In 2 other cases (e.g. ShippingProcessingOrders.DoNumEdit) the Property is prefixed with another "IDO."
                   * (other than the Source IDO and the Form Primary IDO) !  So we'll have to handle by looping through all FormCollections (below)...
                  -- In 2 cases (e.g. ShippingProcessingLineReleases.DoNumEdit) the Property is prefixed with "IDO."
                  SET @NewValue = Replace(@String, @Prefix + @CollectionName + N'.' + @PropertyName + @Suffix, @Implementation)
                  IF @NewValue <> @String
                  BEGIN
                     SET @String = @NewValue
                     -- Debugging:  print N'Replacing: [' + @Prefix + @CollectionName + N'.' + @PropertyName + @Suffix + N'] with [' + @Implementation + N']'
                     -- Debugging:  print @String
         
                     IF @String not like N'%P(%'
                        GOTO exit_label
   
                     SET @AnySubstitutions = 1
                  END
                   */
   
                  --next_wrapper:
                  SET @case = @case + 1
               END
            END
            CLOSE Props_cursor3
            DEALLOCATE Props_cursor3
         END

         DECLARE @TryingSubCollections bit
         IF @TryingSubCollections is null
         BEGIN
            SET @CollNum = @CollNum + 1
   
            IF @CollNum = 0
            BEGIN
               DECLARE @OriginalCollectionName sysname
               SET @OriginalCollectionName = @CollectionName
   
               IF @CollectionName0 is not null AND @CollectionName0 <> @OriginalCollectionName
               BEGIN
                  -- Do it all again with the Primary Collection!
                  SET @CollectionName = @CollectionName0
                  CONTINUE
               END
               ELSE
               SET @CollNum = 1
            END
   
            -- In some cases, the Property is prefixed with another Collection name and period.
            IF @String not like N'%P([^0-9]%.%)%'
               -- Numeric Secondary Collection prefixes (e.g.  "8.Job", "12.Suffix") are handled later by dbo.ResolveSecondaryCollectionProperties().
               GOTO exit_label
   
            -- Debugging:  print N'Checking for P(IDO.Property)'
   
            WHILE 1=1
            BEGIN
               SET @CollectionName = null
               -- Debugging:  print N'Looking for Secondary Collection #' + cast(@CollNum as nvarchar)
   
               SELECT @CollectionName = CollectionName
               FROM FormCollections
               WHERE FormId = @FormId
               AND CollectionNumber = @CollNum
   
               IF @CollectionName is null
                  -- We ran out of Collections to try!
                  BREAK
      
               IF @CollectionName <> @OriginalCollectionName
               AND @CollectionName <> isnull(@CollectionName0, N'')
               BEGIN
                  -- Debugging:  print N'Found ' + @CollectionName
                  BREAK
               END
   
               SET @CollNum = @CollNum + 1
            END
   
            IF @CollectionName is null
            BEGIN
               -- We ran out of Secondary Collections to try!
               IF @UseCollectionPrefix is null
               BEGIN
                  -- Debugging:  print N'Restarting search, with IDO. Prefix...'
                  -- Do it all again, checking with the "IDO." prefixing the Property!
                  SET @CollectionName = @OriginalCollectionName
                  SET @UseCollectionPrefix = 1
                  SET @CollNum = -1
                  CONTINUE
               END

               SET @TryingSubCollections = 1
               -- Fall into the next block below.
            END

            -- ELSE Do it all again with Secondary Collection!
         END

         IF @TryingSubCollections = 1
         BEGIN
            SET @UseCollectionPrefix = 1

            DECLARE @SubCollList nvarchar(4000)
            DECLARE @SubCollNum int
            DECLARE @SubCollections int
            IF @SubCollList is null
            BEGIN
               SET @SubCollList = N''
               SELECT @SubCollList = @SubCollList
                  + case when @SubCollList = N'' then N'' else N',' end
                  + ChildCollectionName
               FROM SubCollectionJoins
               WHERE ParentCollectionName = @OriginalCollectionName

               -- Debugging:  print N'Looking for SubCollections, found: ' + @SubCollList

               SET @SubCollections = dbo.NumEntries(@SubCollList, N',')
               SET @SubCollNum = 1
            END
            ELSE
            SET @SubCollNum = @SubCollNum + 1

            IF @SubCollNum > @SubCollections
               -- We ran out of SubCollections to try!
               BREAK

            SET @CollectionName = dbo.Entry(@SubCollNum, @SubCollList, N',')

            -- Debugging:  print N'Trying SubCollection: ' + @CollectionName
            -- Do it all again with SubCollection!
         END
      END
   END
   ELSE
   BEGIN
      DECLARE @WordDelimiters nvarchar(16)
      SET @WordDelimiters = N' =+-*/(),&<>!'
   
      DECLARE @s int, @e int
      SET @s = 1
      SET @e = 1
      WHILE @s <= len(@String)
      BEGIN
         -- Jump over Word Delimiters:
         WHILE @s <= len(@String) AND charindex(substring(@String, @s, 1), @WordDelimiters) > 0
            SET @s = @s + 1
   
         -- String ended with a non-Word:
         IF @s > len(@String)
            BREAK
   
         -- Now @s marks the first character of a Word.
   
         SET @e = @s
   
         -- Jump to just before next Word Delimiter:
         WHILE @e + 1 <= len(@String) AND charindex(substring(@String, @e + 1, 1), @WordDelimiters) = 0
            SET @e = @e + 1
   
         -- Now @e marks the last character of a Word.
         --DECLARE @PropertyName sysname
         SET @PropertyName = substring(@String, @s, @e - @s + 1)
   
         -- Ignore numeric and string constants:
         IF charindex(substring(@PropertyName, 1, 1), N'0123456789.''') > 0
         -- Ignore table.column names:
         OR charindex(N'.', @PropertyName) > 0
         -- Ignore keywords:
         OR @PropertyName IN (N'AND', N'OR', N'IS', N'NOT', N'NULL', N'LIKE')
         BEGIN
            -- Jump past this Word:
            SET @s = @e + 2
            -- Debugging:  print N'Non-Word: [' + @PropertyName + N']'
            CONTINUE
         END
   
         -- Debugging:  print N'Word: [' + @PropertyName + N']'
   
         --DECLARE @Implementation nvarchar(4000)
         SET @Implementation = null
   
         -- Look for the Property's Binding or Implementation in the ObjectStudio MetaData:
         SELECT @Implementation = ltrim(rtrim(ISNULL(PropertyValue, Tables.TableName + '.' + ColumnName)))
         FROM bo.Properties as Properties
         INNER JOIN bo.Tables as Tables ON Tables.TableId = ColumnTableId
         WHERE Properties.CollectionName = @CollectionName
         AND Properties.PropertyName = @PropertyName
         AND Properties.DevelopmentFlag = 0
   
         IF @Implementation is not null
         BEGIN
            SET @String =
               case when @s = 1 then N'' else substring(@String, 1, @s - 1) end
               + @Implementation
               + substring(@String, @e + 1, len(@String))
            SET @s = @s + len(@Implementation) + 1
            -- Debugging:  print N'Replaced with [' + @Implementation + N'].'
            CONTINUE
         END
         ELSE
         BEGIN
            -- Jump past this Word:
            SET @s = @e + 2
            -- Debugging:  print N'Not replaced.'
            CONTINUE
         END
      END
   END

   exit_label:
   -- Debugging:  print @String

   RETURN @String
END

GO
