IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Singularize]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[Singularize]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Returns the singular version of @Word
CREATE FUNCTION dbo.Singularize (
  @Word sysname
) RETURNS sysname
AS
BEGIN
   RETURN
   CASE
      WHEN @Word LIKE '%ies' THEN SUBSTRING(@Word, 1, LEN(@Word) - 3) + 'y'
      WHEN @Word LIKE '%ses' THEN SUBSTRING(@Word, 1, LEN(@Word) - 2)
      WHEN @Word LIKE '%xes' THEN SUBSTRING(@Word, 1, LEN(@Word) - 2)
      WHEN @Word LIKE '%ches' THEN SUBSTRING(@Word, 1, LEN(@Word) - 2)
      WHEN @Word = 'ShadowValues' THEN SUBSTRING(@Word, 1, LEN(@Word) - 2)
      WHEN @Word LIKE '%es' THEN SUBSTRING(@Word, 1, LEN(@Word) - 1)
      WHEN @Word LIKE '%parms' THEN @Word
      WHEN @Word LIKE '%trans' THEN @Word
      WHEN @Word LIKE '%cls' THEN @Word
      WHEN @Word LIKE '%pos' THEN @Word
      WHEN @Word LIKE '%cons' THEN @Word
      WHEN @Word LIKE '%ins' THEN @Word
      WHEN @Word LIKE '%[_]ms' THEN @Word
      WHEN @Word LIKE '%bonus' THEN @Word
      WHEN @Word LIKE '%basis' THEN @Word
      WHEN @Word IN ('dcps', 'ps', 'glrptls', 'terms') THEN @Word
      WHEN @Word LIKE '%ss' THEN @Word
      WHEN @Word LIKE '%s' THEN SUBSTRING(@Word, 1, LEN(@Word) - 1)
      ELSE @Word
   END
END

GO
