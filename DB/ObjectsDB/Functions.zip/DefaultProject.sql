IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DefaultProject]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[DefaultProject]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Returns the standard IDO name of the object based on @TableName
CREATE FUNCTION dbo.DefaultProject (
  @TableName varchar(128) --sysname
) RETURNS sysname
AS
BEGIN
   -- Query Optimizing:  DECLARE @TableName varchar(128) SET @TableName = 'co'
   DECLARE @Project sysname

   -- If a special View, use View's Project:
   SELECT @Project = Project
   FROM ERDViews
   WHERE ViewName = @TableName

   -- If currently a single IDO primarily based on @TableName:
   IF @Project IS NULL
   IF 1 = (SELECT COUNT(*) FROM ObjTables as IDOtab
         WHERE IDOtab.TableName = @TableName AND IDOtab.TableType = 3)
      -- Use its Project:
      SELECT @Project = ServerName
      FROM ObjTables as IDOTab
      inner join bo.Collections as IDO on IDO.CollectionName = IDOTab.CollectionName
      WHERE IDOTab.TableName = @TableName AND IDOTab.TableType = 3

   -- Otherwise use the Project with the most IDO's primarily based on @TableName:
   IF @Project IS NULL
   SELECT TOP 1 @Project = ServerName
      FROM ObjTables as IDOTab
      inner join bo.Collections as IDO on IDO.CollectionName = IDOTab.CollectionName
      WHERE IDOTab.TableName = @TableName AND IDOTab.TableType = 3
      AND ServerName not like '%Test%'
      GROUP BY ServerName
      ORDER BY COUNT(*) DESC

   -- Otherwise use the Project with the most IDO's mentioning @TableName:
   IF @Project IS NULL
   SELECT TOP 1 @Project = ServerName
      FROM ObjTables as IDOTab
      inner join bo.Collections as IDO on IDO.CollectionName = IDOTab.CollectionName
      WHERE IDOTab.TableName = @TableName
      AND ServerName not like '%Test%'
      GROUP BY ServerName
      ORDER BY COUNT(*) DESC

   IF @Project IS NOT NULL
      RETURN @Project

   -- Otherwise ALL_CAPS @TableName's belong to APS:
   IF 1 = CaseSensitive.dbo.CSEquals(@TableName, UPPER(@TableName))
      RETURN N'APS'

   -- Otherwise MixedCase @TableName's belong to Core:
   IF 1 = CaseSensitive.dbo.CSEquals(SUBSTRING(@TableName, 1, 1), UPPER(SUBSTRING(@TableName, 1, 1)))
      RETURN N'Core'

   -- *_all are same as their master:
   IF @TableName LIKE '%[_]all'
      RETURN dbo.DefaultProject(SUBSTRING(@TableName, 1, LEN(@TableName) - 4))

   IF @TableName like 'ack%' OR @TableName like 'edi%'
      RETURN dbo.DefaultProject('edi_co')
   IF @TableName like '%pertot%' or @TableName like '%per_unit%' or @TableName like 'ledger%'
      RETURN dbo.DefaultProject('ledger')
   IF @TableName like 'apsplan'
      RETURN 'APS'
   IF @TableName like 'ap%'
      RETURN dbo.DefaultProject('aptrxp')
   IF @TableName like 'ar%'
      RETURN dbo.DefaultProject('artran')
   IF @TableName like 'cad%'
      RETURN 'Material'
   IF @TableName like 'cfg%'
      RETURN dbo.DefaultProject('cfg_main')
   IF @TableName like 'citemc' OR @TableName = 'co_xref' or @TableName = 'sale_sum'
      RETURN dbo.DefaultProject('coitem')
   IF @TableName like 'commtran'
      RETURN dbo.DefaultProject('commdue')
   IF @TableName like 'ctc_log'
      RETURN dbo.DefaultProject('proj')
   IF @TableName like 'inv%'
      RETURN dbo.DefaultProject('inv_hdr')
   IF @TableName like 'exc_mesg'
      RETURN dbo.DefaultProject('rcpts')
   IF @TableName like 'jmatlc'
      RETURN dbo.DefaultProject('jobmatl')
   IF @TableName like 'jobtcb_cls'
      RETURN dbo.DefaultProject('jobt_cls')
   IF @TableName like 'lasttran'
      RETURN dbo.DefaultProject('parms')
   IF @TableName like '%earn' or @TableName like '%scrp'
      RETURN dbo.DefaultProject('wc')
   IF @TableName like 'mcal%' or @TableName like 'tick_cal'
      RETURN dbo.DefaultProject('shift')
   IF @TableName like 'po%'
      RETURN dbo.DefaultProject('po')
   IF @TableName like 'proj%'
      RETURN dbo.DefaultProject('proj')
   IF @TableName like 'prog%'
      RETURN dbo.DefaultProject('progbill')
   IF @TableName like 'pr%'
      RETURN dbo.DefaultProject('prtrx')
   IF @TableName like 'prospect'
      RETURN dbo.DefaultProject('customer')
   IF @TableName like 'ser%'
      RETURN dbo.DefaultProject('serial')
   IF @TableName like 'site%'
      RETURN dbo.DefaultProject('site')
   IF @TableName like 'tax%'
      RETURN dbo.DefaultProject('tax_free_import')
   IF @TableName like 'trp_item'
      RETURN dbo.DefaultProject('trnitem')
   IF @TableName like 'vch%'
      RETURN dbo.DefaultProject('vch_hdr')
   IF @TableName like 'vend%'
      RETURN dbo.DefaultProject('vendor')
   IF @TableName like 'wc%'
      RETURN dbo.DefaultProject('wc')

   RETURN @Project
END

GO
