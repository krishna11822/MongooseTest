IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[KeepSLPrefix]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[KeepSLPrefix]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Returns 1 if and only if Unitecture SyteLine IDOs will (all) be prefixed by "SL".
-- A (possibly non-period-ending) qualifier will precede the IDO name [see dbo.NewIDOQualifier()].
CREATE FUNCTION dbo.KeepSLPrefix () RETURNS bit
AS
BEGIN
   RETURN 0
END

GO
