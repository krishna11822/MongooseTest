/****** Object:  UserDefinedFunction [dbo].[CanCompareKeysToExpressions]    Script Date: 12/23/2013 11:51:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CanCompareKeysToExpressions]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[CanCompareKeysToExpressions]
GO

/****** Object:  UserDefinedFunction [dbo].[CanCompareKeysToExpressions]    Script Date: 12/23/2013 11:51:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- Returns 1 if and only if Unitecture allows constraining key properties to Expressions (for Refers relationships).
CREATE FUNCTION [dbo].[CanCompareKeysToExpressions] () RETURNS bit
AS
BEGIN
RETURN 1
END

GO


