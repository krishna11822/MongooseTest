/****** Object:  UserDefinedFunction [dbo].[CaseSensitiveCompare]    Script Date: 12/23/2013 11:54:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CaseSensitiveCompare]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[CaseSensitiveCompare]
GO

/****** Object:  UserDefinedFunction [dbo].[CaseSensitiveCompare]    Script Date: 12/23/2013 11:54:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create function [dbo].[CaseSensitiveCompare](@value1 as varchar(500), @value2 as varchar(500))
returns tinyint
as
begin
declare @result tinyint
declare @index int

set @result = 0

if isnull(@value1,'x') = isnull(@value2,'x')
begin
set @index = 0
set @result = 1
while (@index < len(@value1)) and (@result = 1)
begin
if ascii(substring(@value1, @index, 1)) <> ascii(substring(@value2, @index, 1))
set @result = 0
set @index = @index + 1
end
end

return @result
end

GO


