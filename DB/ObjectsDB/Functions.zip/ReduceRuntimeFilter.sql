IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReduceRuntimeFilter]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[ReduceRuntimeFilter]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Convert the part of @Filter inside square brackets to a constant value.
CREATE FUNCTION dbo.ReduceRuntimeFilter (
  @Filter nvarchar(4000)
)
RETURNS nvarchar(4000) AS
BEGIN
   IF substring(@Filter, 1, 1) = N'['
      RETURN N'[Runtime]' + substring(@Filter, charindex(N']', @Filter) + 1, len(@Filter))
   --ELSE
   RETURN @Filter
END

GO
