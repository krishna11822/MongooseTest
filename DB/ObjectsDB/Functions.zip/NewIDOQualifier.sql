IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[NewIDOQualifier]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[NewIDOQualifier]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Determines a Unitecture IDO qualifier (possibly dotted segments before IDO Name) from a SL7 Project (Collections.ServerName)
CREATE FUNCTION dbo.NewIDOQualifier (
  @Project sysname
) RETURNS sysname
AS
BEGIN
   DECLARE @KeepSLPrefix bit
   SET @KeepSLPrefix = dbo.KeepSLPrefix()

   RETURN
   --'Mapics.' +
   CASE WHEN @Project = N'Core'
      THEN N'UA'
      ELSE CASE WHEN @KeepSLPrefix = 1 THEN N'' ELSE N'SL' END
   END
END

GO
