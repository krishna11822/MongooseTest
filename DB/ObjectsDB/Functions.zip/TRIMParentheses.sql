IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TRIMParentheses]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[TRIMParentheses]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Trims a set of parentheses that surround @String.
CREATE FUNCTION dbo.TRIMParentheses (
  @String nvarchar(4000)
)
RETURNS nvarchar(4000) AS
BEGIN
   IF @String like '(%)'
      RETURN substring(@String, 2, len(@String) - 2)
   --ELSE
   RETURN @String
END

GO
