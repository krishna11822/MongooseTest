IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[NumEntriesObeyingParentheses]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[NumEntriesObeyingParentheses]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Returns the number of @Delim-separated elements of the @List,
-- ignoring @Delim's within elements enclosed completely in parentheses.
CREATE FUNCTION dbo.NumEntriesObeyingParentheses (
  @List nvarchar(4000)
, @Delim nvarchar(100) = ','
) RETURNS INT
AS
BEGIN
   IF @List is null
      RETURN null

   DECLARE
     @Result int
   , @i INT

   SET @Result = 0
   SET @i = 1

   WHILE len(@List) > 0
   BEGIN
      SET @Result = @Result + 1

      IF CHARINDEX(@Delim, @List) = 0
         BREAK
      IF SUBSTRING(@List, 1, 1) = N'('
         SET @List = SUBSTRING(@List, 2 + LEN(dbo.ParenString(SUBSTRING(@List, 2, LEN(@List)))) + 1 + dbo.TrueLEN(@Delim), LEN(@List))
      ELSE
      SET @List = SUBSTRING(@List, CHARINDEX(@Delim, @List) + dbo.TrueLEN(@Delim), LEN(@List))
   END

   RETURN @Result
END

GO
