IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PrefixFromIDO]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[PrefixFromIDO]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Translates a SL7 IDO name (Collections.CollectionName) to a Relationship prefix (BO_KEYS.PREFIX)
CREATE FUNCTION dbo.PrefixFromIDO (
  @IDO sysname
) RETURNS sysname
AS
BEGIN
   DECLARE @HasSLPrefix bit
   SET @HasSLPrefix = CASE WHEN CHARINDEX('SL', @IDO) = 1 THEN 1 ELSE 0 END

   DECLARE @PrefixCharsToRemove tinyint
   SET @PrefixCharsToRemove = CASE WHEN @HasSLPrefix = 1 THEN 2 ELSE 0 END

   RETURN
   SUBSTRING(@IDO, 1 + @PrefixCharsToRemove, LEN(@IDO))
END

GO
