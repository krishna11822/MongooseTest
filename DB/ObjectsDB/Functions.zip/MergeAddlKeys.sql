IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MergeAddlKeys]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[MergeAddlKeys]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Merge the lists @Keys1 and @Keys2, who are ordered by @Order1 and @Order2, according to the order of @ResultOrder.
CREATE FUNCTION dbo.MergeAddlKeys (
   @Keys1 [nvarchar] (2000),    -- First list of keys/expressions to be merged (cf. DomainAttributes.{Member,Owner}Keys).
   @Order1 [nvarchar] (2000),   -- List of keys corresponding to @Keys1 (cf. DomainAttributes.MemberKeys).
   @Keys2 [nvarchar] (2000),    -- Second list of keys/expressions to be merged [cf. dbo.JoinTo{Key,Expression}List()].
   @Order2 [nvarchar] (2000),   -- List of keys corresponding to @Keys2 [cf. dbo.JoinToKeyList()].
   @ResultOrder [nvarchar] (2000)   -- List of keys by which to order the results (should be a superset of @Order1 + @Order2).
) RETURNS nvarchar(4000)
AS
BEGIN
   DECLARE @Result nvarchar(4000)
   --SET @Result = N''

   DECLARE @ro int
   SET @ro = 1
   DECLARE @ResultOrderEntries int
   SET @ResultOrderEntries = dbo.NumEntries(@ResultOrder, N',')
   WHILE @ro <= @ResultOrderEntries
   BEGIN
      DECLARE @ThisOrder sysname
      SET @ThisOrder = dbo.Entry(@ro, @ResultOrder, N',')

      DECLARE @Lookup int
      SET @Lookup = dbo.Lookup(@ThisOrder, @Order1, N',')
      IF @Lookup > 0
      --BEGIN
         SET @Result = isnull(@Result + N',', N'')
            + dbo.EntryObeyingParentheses(@Lookup, @Keys1, N',')
      --END
      ELSE
      BEGIN
         SET @Lookup = dbo.Lookup(@ThisOrder, @Order2, N',')
         IF @Lookup > 0
         --BEGIN
            SET @Result = isnull(@Result + N',', N'')
               + dbo.EntryObeyingParentheses(@Lookup, @Keys2, N',')
         --END
      END
      SET @ro = @ro + 1
   END

   RETURN @Result
END

GO
