IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PrefixSuffixFromKeys]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[PrefixSuffixFromKeys]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Translates OwnerKeys (UniERD.OwnerKeys) to the suffix of a Relationship Prefix (BO_KEYS.PREFIX)
CREATE FUNCTION dbo.PrefixSuffixFromKeys (
  @Keys nvarchar(2000)
) RETURNS sysname
AS
BEGIN
   DECLARE @Result1 sysname
   SET @Result1 = N''
   DECLARE @Result2 sysname
   SET @Result2 = N''

   declare @i int, @e int
   set @i = 1
   set @e = dbo.NumEntriesObeyingParentheses(@Keys, N',')
   while @i <= @e
   begin
      declare @k nvarchar(2000)
      SET @k = dbo.EntryObeyingParentheses(@i, @Keys, N',')
      IF @k like N'(%)'
      BEGIN
         -- Expression
         IF charindex(N' ', @k) > 0
         BEGIN
            SET @i = @i + 1
            -- Skip it!
            CONTINUE
         END
         SET @k = dbo.TRIMParentheses(@k)
         IF @k like N'N''%'
            SET @k = substring(@k, 2, len(@k))
         SET @Result2 = @Result2
            + dbo.AdhocPrefix(@k)
      END
      ELSE
      BEGIN
         -- {table.}column
         IF dbo.NumEntries(@k, N'.') = 2
            SET @k = dbo.Entry(2, @k, N'.')

         SET @Result1 = @Result1
            + dbo.Hungarianize(@k)
      END
      SET @i = @i + 1
   end

   RETURN @Result1 + @Result2
END

GO
