IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ListDiff]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[ListDiff]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Returns a comma-separated list of the elements in @List1 that are not in @List2.
CREATE FUNCTION [dbo].[ListDiff] 
(
     @List1 nvarchar(4000)
   , @List2 nvarchar(4000)
)
RETURNS nvarchar(4000) AS  
BEGIN
   DECLARE @N1 smallint
   DECLARE @N2 smallint
   SET @N1 = dbo.NumEntries(@List1, ',')
   SET @N2 = dbo.NumEntries(@List2, ',')
   IF @N1 = 0
      RETURN NULL
   IF @N2 = 0
      RETURN @List1

   DECLARE @Diff nvarchar(4000)

   DECLARE @i smallint
   SET @i = 1
   WHILE @i <= @N1
   BEGIN
      DECLARE @Element sysname
      SET @Element = dbo.Entry(@i, @List1, ',')
      IF dbo.IsInList(@List2, @Element) = 0
         SET @Diff =
            CASE WHEN @Diff IS NULL THEN '' ELSE @Diff + ',' END
            + @Element

      SET @i = @i + 1
   END

   RETURN @Diff
END

GO
