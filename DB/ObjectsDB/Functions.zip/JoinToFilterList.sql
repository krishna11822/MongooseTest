IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[JoinToFilterList]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[JoinToFilterList]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Returns the part of @JoinClause NOT corresponding to the conjoined list of equality comparisons
-- corresponding to dbo.JoinToKeyList(@JoinClause, @TableAlias) and dbo.JoinToExpressionList(@JoinClause, @TableAlias).
CREATE FUNCTION dbo.JoinToFilterList (
  @JoinClause nvarchar(4000)
, @TableAlias sysname
)
RETURNS nvarchar(4000) AS
BEGIN
   RETURN dbo.JoinToFilterListRestricted (@JoinClause, @TableAlias, DEFAULT)
END

GO
