IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[JoinToExpressionList]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[JoinToExpressionList]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Returns the ordered comma-separated list of columns or expressions equality-matched to
-- key-columns prefixed by the @TableAlias within the @JoinClause.
-- Ignores "EXISTS()" clauses and other non-equality conjoinees,
-- and optionally ignores key-columns compared to constants or other non-key-columns
-- based on the (one's complement of the) function dbo.CanCompareKeysToExpressions().
CREATE FUNCTION dbo.JoinToExpressionList (
  @JoinClause nvarchar(4000)
, @TableAlias sysname
--, @MaxKeys int = null
)
RETURNS nvarchar(4000) AS
BEGIN
   /* Debug:
   DECLARE @JoinClause nvarchar(4000), @TableAlias sysname
   SET @TableAlias = 'Trx' SET @JoinClause = 'Trx.site_ref = Sgrp.site and Trx.active = 1 and Trx.type = ''V'''
    */

   DECLARE @IgnoreKeyExpressions bit
   SET @IgnoreKeyExpressions = 1 - dbo.CanCompareKeysToExpressions()

   DECLARE @Result nvarchar(4000)

   DECLARE @Keys int
   SET @Keys = dbo.NumEntries(@JoinClause, ' and ')
   /* Debug:
   PRINT @Keys
    */
   DECLARE @i int
   SET @i = 1
   WHILE @i <= @Keys
   BEGIN
      IF @Result IS NULL
         SET @Result = ''
      DECLARE @KeyClause nvarchar(4000)
      SET @KeyClause = dbo.Entry(@i, @JoinClause, ' and ')
      /* Debug:
      PRINT @KeyClause
      PRINT dbo.NumEntries(@KeyClause, '=')
       */
      IF @KeyClause LIKE 'exists%'
      OR @KeyClause LIKE '(%)' BREAK
      IF dbo.NumEntries(@KeyClause, '=') <> 2 BREAK

      DECLARE @Key1 nvarchar(4000), @Key2 nvarchar(4000)
      SET @Key1 = LTRIM(RTRIM(REPLACE(REPLACE(dbo.Entry(1, @KeyClause, '='), '(', ' '), ')', ' ')))
      SET @Key2 = LTRIM(RTRIM(REPLACE(REPLACE(dbo.Entry(2, @KeyClause, '='), '(', ' '), ')', ' ')))
      /* Debug:
      PRINT @Key1
      PRINT @Key2
       */

      DECLARE @ThisKey nvarchar(4000)
      DECLARE @OtherKey nvarchar(4000)
      -- Does not contain a period
      IF CHARINDEX('.', @Key1) = 0
         -- ...and begins with a letter:
         AND CHARINDEX(SUBSTRING(@Key1, 1, 1), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ') > 0
         -- ...but is not a Unicode string constant:
         AND @Key1 NOT LIKE 'N''%'
         -- (i.e., is only the unqualified column name)
         -- Prepend the Table Alias followed by a period:
         SET @Key1 = @TableAlias + '.' + @Key1

      -- Begins with the Table Alias followed by a period:
      IF @Key1 LIKE @TableAlias + '.%'
      BEGIN
         SET @ThisKey = @Key1
         SET @OtherKey = @Key2
      END
      ELSE
      BEGIN
         SET @ThisKey = @Key2
         SET @OtherKey = @Key1
      END

      IF CHARINDEX('.', @ThisKey) > 0 AND CHARINDEX(' ', @ThisKey) = 0
      AND (@IgnoreKeyExpressions = 0
         OR CHARINDEX('.', @OtherKey) > 0 AND CHARINDEX(' ', @OtherKey) = 0)
         SET @Result = CASE WHEN @Result IS NULL OR @Result = '' THEN '' ELSE @Result + ',' END
            + CASE WHEN CHARINDEX('.', @OtherKey) > 0 AND CHARINDEX(' ', @OtherKey) = 0
               -- Table.Column
               THEN @OtherKey
               -- Expression
               ELSE '(' + 
                  -- Assert all string constants as Unicode!
                  CASE WHEN @OtherKey LIKE '''%' THEN 'N' ELSE '' END
                  + @OtherKey + ')'
              END

/*    IF @MaxKeys IS NOT NULL
      AND dbo.NumEntries(@Result, ',') >= @MaxKeys
         BREAK */

      SET @i = @i + 1
   END
   /* Debug:
   PRINT @Result
    */
   RETURN @Result
END

GO
