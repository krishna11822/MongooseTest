IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ReorderList]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[ReorderList]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Merge the lists @Keys1 and @Keys2, who are ordered by @Order1 and @Order2, according to the order of @ResultOrder.
CREATE FUNCTION dbo.ReorderList (
   @List [nvarchar] (2000),    -- List of keys/expressions to be re-ordered (cf. IDO_ERD_ALL.{Member,Owner}Keys).
   @CurrentOrder [nvarchar] (100),   -- List of keys corresponding to @List.
   @ResultOrder [nvarchar] (100)   -- List of keys by which to order the results (must be a re-ordering of @CurrentOrder).
) RETURNS nvarchar(2000)
AS
BEGIN
   DECLARE @Result nvarchar(2000)
   --SET @Result = N''

   DECLARE @ResultOrderEntries int
   SET @ResultOrderEntries = dbo.NumEntries(@ResultOrder, N',')
   DECLARE @ro int
   SET @ro = 1
   WHILE @ro <= @ResultOrderEntries
   BEGIN
      DECLARE @ThisOrder sysname
      SET @ThisOrder = dbo.Entry(@ro, @ResultOrder, N',')

      DECLARE @Lookup int
      SET @Lookup = dbo.Lookup(@ThisOrder, @CurrentOrder, N',')
         SET @Result = isnull(@Result + N',', N'')
            + dbo.EntryObeyingParentheses(@Lookup, @List, N',')

      SET @ro = @ro + 1
   END

   RETURN @Result
END

GO
