IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[NewIDOName]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[NewIDOName]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Translates a SL7 IDO name (Collections.CollectionName) to a Unitecture IDO name (BUSINESS_OBJECT.NAME).
CREATE FUNCTION dbo.NewIDOName (
  @CollectionName sysname
) RETURNS sysname
AS
BEGIN
   DECLARE @HasSLPrefix bit
   SET @HasSLPrefix = CASE WHEN CHARINDEX('SL', @CollectionName) = 1 THEN 1 ELSE 0 END

   DECLARE @KeepSLPrefix bit
   SET @KeepSLPrefix = dbo.KeepSLPrefix()
   DECLARE @KeepPluralSuffix bit
   SET @KeepPluralSuffix = dbo.KeepPluralSuffix()

   DECLARE @PrefixCharsToRemove tinyint
   SET @PrefixCharsToRemove = CASE WHEN @KeepSLPrefix = 0 AND @HasSLPrefix = 1 THEN 2 ELSE 0 END

   DECLARE @NewCollectionName sysname
   SET @NewCollectionName =
      CASE @CollectionName
         WHEN N'UserNames' THEN N'User'
         ELSE @CollectionName
      END

   RETURN
   dbo.NewIDOQualifier(dbo.NewProjectName(@CollectionName))
   + CASE WHEN @KeepSLPrefix = 1 AND @HasSLPrefix = 0 THEN 'SL' ELSE '' END
   + CASE @KeepPluralSuffix
      WHEN 1
      THEN dbo.Pluralize(dbo.Hungarianize(SUBSTRING(@NewCollectionName, 1 + @PrefixCharsToRemove, LEN(@NewCollectionName))))
      ELSE dbo.Singularize(dbo.Hungarianize(SUBSTRING(@NewCollectionName, 1 + @PrefixCharsToRemove, LEN(@NewCollectionName))))
     END
END

GO
