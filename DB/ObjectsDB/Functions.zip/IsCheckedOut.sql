IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[IsCheckedOut]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[IsCheckedOut]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE  FUNCTION IsCheckedOut( @IDOName AS VARCHAR(30) )
RETURNS INT
BEGIN
   DECLARE @IsCheckedOut INT

   SELECT @IsCheckedOut = CASE
                            WHEN EXISTS(SELECT 1 
                                        FROM ObjCollections 
                                        WHERE CollectionName = @IDOName 
                                          AND DevelopmentFlag = 1) 
                            THEN 1
                            ELSE 0
                          END

   RETURN @IsCheckedOut
END


GO
