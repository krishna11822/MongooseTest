IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DefaultPropertyName]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[DefaultPropertyName]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Returns the default Property name (BO_PROPS.NAME) for binding to @ColumnName
CREATE FUNCTION dbo.DefaultPropertyName (
  @TableName sysname,
  @ColumnName sysname
) RETURNS sysname
AS
BEGIN
   IF @ColumnName is null
      RETURN NULL

   DECLARE @PropName sysname
   SET @PropName = dbo.Hungarianize(@ColumnName)
   RETURN
      -- Prefix "SL" onto {serial,serial_all,lot,dep_dtl}.create_date to distinguish from *.CreateDate!
      CASE
         WHEN @PropName <> @ColumnName
         AND EXISTS(SELECT 1 FROM OH_App..syscolumns as dup
            INNER JOIN OH_App..sysobjects AS tab ON tab.id = dup.id
            where tab.name = @TableName
            -- Speed it up!
            and SUBSTRING(dup.name, 1, 1) = substring(@ColumnName, 1, 1)
            and dup.name <> @ColumnName
            and dbo.Hungarianize(dup.name) = @PropName)
         THEN 'SL'
         ELSE ''
      END
      + @PropName
END

GO
