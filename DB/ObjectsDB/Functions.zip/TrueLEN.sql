IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TrueLEN]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[TrueLEN]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Returns the length of @String, including trailing blanks!
CREATE FUNCTION dbo.TrueLEN (
  @String nvarchar(4000)
) RETURNS INT
AS
BEGIN
   RETURN DATALENGTH(@String) / 2
   /* Close, but does not work for N' ' !
   RETURN LEN(@String)
      + LEN(REVERSE(@String)) - LEN(LTRIM(REVERSE(@String)))
    */
END

GO
