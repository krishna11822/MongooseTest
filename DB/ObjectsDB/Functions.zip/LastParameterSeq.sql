IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LastParameterSeq]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[LastParameterSeq]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION LastParameterSeq( 
  @CollectionName VARCHAR(30)
, @MethodName VARCHAR(30)
, @DevelopmentFlag INT)
RETURNS INT
BEGIN
   DECLARE @LastSeq INT

   SELECT @LastSeq = MAX(sq.Sequence)
   FROM ObjMethodParameters sq
   WHERE sq.CollectionName = @CollectionName
     AND sq.MethodName = @MethodName
     AND sq.DevelopmentFlag = @DevelopmentFlag

   RETURN @LastSeq
END


GO
