IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DefaultPropertyNames]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[DefaultPropertyNames]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Returns a comma-separated list of the default Property names (BO_PROPS.NAME) for binding to the comma-separated list @ColumnNames.
CREATE FUNCTION dbo.DefaultPropertyNames (
  @TableName sysname,
  @ColumnNames nvarchar(4000)
) RETURNS nvarchar(4000)
AS
BEGIN
   IF @ColumnNames is null
      RETURN NULL

   DECLARE @Result nvarchar(4000)

   DECLARE @n int
   SET @n = dbo.NumEntries(@ColumnNames, N',')
   DECLARE @i int
   SET @i = 1
   WHILE @i <= @n
   BEGIN
      SET @Result =
         case when @Result is null THEN N'' ELSE @Result + N',' end
         + dbo.DefaultPropertyName(@TableName, dbo.Entry(@i, @ColumnNames, N','))
      SET @i = @i + 1
   END

   RETURN @Result
END

GO
