IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[PrimaryIndexKeyString]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[PrimaryIndexKeyString]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Returns the comma-separated list of user-keys most probably corresponding to
-- @TableName's SyteLine 6 Primary Index.
CREATE FUNCTION dbo.PrimaryIndexKeyString (
  @TableName sysname
) RETURNS nvarchar(4000)
AS
BEGIN
   RETURN OH_App.dbo.IndexKeyString(dbo.PrimaryIndexName(@TableName), @TableName)
END

GO
