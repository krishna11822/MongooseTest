IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ListsHaveSameElements]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[ListsHaveSameElements]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Returns 1 if and only if comma-separated lists @List1 and @List2 contain the exact same elements (in any order).
CREATE FUNCTION [dbo].[ListsHaveSameElements] 
(
     @List1 nvarchar(4000)
   , @List2 nvarchar(4000)
)  
RETURNS bit AS  
BEGIN
   DECLARE @Elements1 TABLE (element sysname)
   DECLARE @Elements2 TABLE (element sysname)
   DECLARE @N1 smallint
   DECLARE @N2 smallint
   SET @N1 = dbo.NumEntries(@List1, ',')
   SET @N2 = dbo.NumEntries(@List2, ',')
   IF @N1 <> @N2
      RETURN 0
   IF @N1 = 0
      RETURN 1

   DECLARE @i smallint
   SET @i = 1
   WHILE @i <= @N1
   BEGIN
      INSERT @Elements1 VALUES(dbo.Entry(@i, @List1, ','))
      INSERT @Elements2 VALUES(dbo.Entry(@i, @List2, ','))
      SET @i = @i + 1
   END

   DECLARE @Same bit
   SET @Same = 1

   DECLARE C1 CURSOR LOCAL STATIC FOR
   SELECT * FROM @Elements1 ORDER BY element
   DECLARE C2 CURSOR LOCAL STATIC FOR
   SELECT * FROM @Elements2 ORDER BY element
   OPEN C1
   OPEN C2
   WHILE @Same=1
   BEGIN
      DECLARE @Element1 sysname
      DECLARE @Element2 sysname
      FETCH C1 INTO @Element1
      IF @@FETCH_STATUS < 0 BREAK
      FETCH C2 INTO @Element2
      IF @Element1 <> @Element2
         SET @Same = 0
   END
   CLOSE C1
   CLOSE C2
   DEALLOCATE C1
   DEALLOCATE C2

   RETURN @Same
END

GO
