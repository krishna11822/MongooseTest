IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BaseTypeOf]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[BaseTypeOf]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--  This routine takes an input table and column and returns a string
-- suitable for declaring a SQL table-variable column of that same type.

/*
Copyright © Frontstep, Inc. 2001 - All Rights Reserved

Use, duplication, or disclosure by the Government is subject to restrictions
as set forth in subparagraph (c)(1)(ii) of the Rights in Technical Data and
Computer Software clause at DFARS 252.227-7013, and Rights in Data-General at
FAR 52.227.14, as applicable. 

Name of Contractor: Frontstep, Inc., 2800 Corporate Exchange Dr.,
Columbus, Ohio 43231.

Without a license that includes the source code, customer may not, copy, 
modify or otherwise update the code contained within this file.  Nor may the 
customer merge this code with other computer programs.  

With a license that includes the source code, customer may, for its internal 
information management and data processing purposes only, copy and modify the 
code contained within this file (but not the Limiting Devices) or merge the 
code with other computer programs.  The preparation of modified or merged works
will not enlarge the scope of permitted use and any modified or merged version
of the code or any work including any portion of the code shall remain subject
to the provisions of the separately executed license agreement.  All rights and
title to the code remain the sole property of Frontstep, Inc.

Frontstep is a trademark of Frontstep Solutions Group, Inc. All other product
names used in this code are trademarks, registered trademarks, or trade names
of their respective companies.
 * CoreDev 1 252211 johndou Fri Apr 12 08:23:40 2010
 * Issue #252211 - Temp table collation update.
 *
*/
CREATE FUNCTION dbo.BaseTypeOf (
  @TableName  sysname
, @ColumnName sysname
)
RETURNS sysname
AS
BEGIN

DECLARE
   @TypeString sysname
   , @TypeLength smallint
   , @TypePrec tinyint
   , @TypeScale TINYINT

DECLARE @DBdot sysname
DECLARE @period tinyint
SET @period = charindex('.', REVERSE(@TableName))
IF @period > 0
BEGIN
   SET @DBdot = LEFT(@TableName, LEN(@TableName) + 1 - @period)
   SET @TableName = RIGHT(@TableName, @period - 1)
/*
   CREATE TABLE #BaseTypeOf (
      TypeString sysname collate database_default,
      TypeLength SMALLINT,
      TypePrec SMALLINT,
      TypeScale SMALLINT
      )

   DECLARE @SQL VARCHAR(4000)
   SET @SQL = '
      INSERT INTO #TypeOf
      SELECT
         bt.name,
         sc.length,
         sc.xprec,
         sc.xscale
      FROM ' + @DBdot + 'syscolumns AS sc
      INNER JOIN ' + @DBdot + 'systypes AS st ON
         st.xusertype = sc.xusertype
      INNER JOIN ' + @DBdot + 'systypes AS bt ON
         bt.xtype = st.xtype AND bt.xusertype = bt.xtype
      WHERE sc.id = OBJECT_ID(''' + @TableName + ''')
      AND sc.name = ''' + @ColumnName + ''''

   EXEC(@SQL)
   SELECT @TypeString = TypeString
      @TypeLength = TypeLength
      @TypePrec   = TypePrec
      @TypeScale  = TypeScale
      FROM #BaseTypeOf
      */
END
--ELSE
SELECT
   @TypeString = bt.name,
   @TypeLength = sc.length,
   @TypePrec   = sc.xprec,
   @TypeScale  = sc.xscale
FROM syscolumns AS sc
INNER JOIN systypes AS st ON
   st.xusertype = sc.xusertype
INNER JOIN systypes AS bt ON
   bt.xtype = st.xtype AND bt.xusertype = bt.xtype
WHERE sc.id = OBJECT_ID(@TableName)
AND sc.name = @ColumnName

IF @@ROWCOUNT = 0
BEGIN
   /*
   IF @period > 0
   BEGIN
      SET @SQL = '
         INSERT INTO #TypeOf
         SELECT
            bt.name,
            sc.length,
            sc.xprec,
            sc.xscale
         FROM ' + @DBdot + 'syscolumns AS sc
         INNER JOIN ' + @DBdot + 'systypes AS st ON
            st.xusertype = sc.xusertype
         INNER JOIN ' + @DBdot + 'systypes AS bt ON
            bt.xtype = st.xtype AND bt.xusertype = bt.xtype
         WHERE sc.id = OBJECT_ID(''' + @TableName + ''')
         AND sc.name LIKE ''' + @ColumnName + '%'''

      EXEC(@SQL)
      SELECT @TypeString = TypeString
         @TypeLength = TypeLength
         @TypePrec   = TypePrec
         @TypeScale  = TypeScale
         FROM #BaseTypeOf
   END
   ELSE
   */
   SELECT
   @TypeString = bt.name,
   @TypeLength = sc.length,
   @TypePrec   = sc.xprec,
   @TypeScale  = sc.xscale
   FROM syscolumns AS sc
   INNER JOIN systypes AS st ON
      st.xusertype = sc.xusertype
   INNER JOIN systypes AS bt ON
      bt.xtype = st.xtype AND bt.xusertype = bt.xtype
   WHERE sc.id = OBJECT_ID(@TableName)
   AND sc.name like @ColumnName + '%'

   IF @@ROWCOUNT <> 1
   BEGIN
      SET @TypeString = 'Unknown Column: ' + @TableName + '.' + @ColumnName
      RETURN @TypeString
   END
END
/*
IF @period > 0
   DROP TABLE #BaseTypeOf
 */
SET @TypeString = @TypeString
   + CASE
      WHEN @TypeString IN ('char', 'varchar', 'text')
         THEN '(' + CAST(@TypeLength AS VARCHAR) + ')'
      WHEN @TypeString IN ('nchar', 'nvarchar', 'ntext')
         THEN '(' + CAST(@TypeLength / 2 AS VARCHAR) + ')'
      WHEN @TypeString in ('decimal', 'numeric')
         THEN '(' + CAST(@TypePrec AS VARCHAR) + ', ' + CAST(@TypeScale AS VARCHAR) + ')'
      ELSE ''
   END

RETURN @TypeString

END


GO
