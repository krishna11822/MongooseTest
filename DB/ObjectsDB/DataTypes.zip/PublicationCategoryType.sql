IF NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'PublicationCategoryType' AND ss.name = N'dbo')
CREATE TYPE [dbo].[PublicationCategoryType] FROM [nvarchar](30) NULL
GO
