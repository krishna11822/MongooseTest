IF NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'WBScopeTypeType' AND ss.name = N'dbo')
CREATE TYPE [dbo].[WBScopeTypeType] FROM [smallint] NULL
GO
