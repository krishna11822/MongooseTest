IF NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'AppModuleType' AND ss.name = N'dbo')
CREATE TYPE [dbo].[AppModuleType] FROM [nvarchar](40) NULL
GO
