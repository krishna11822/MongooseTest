IF NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'HashType' AND ss.name = N'dbo')
CREATE TYPE [dbo].[HashType] FROM [char](64) NOT NULL
GO
