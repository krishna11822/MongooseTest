IF NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'GenericTypeType' AND ss.name = N'dbo')
CREATE TYPE [dbo].[GenericTypeType] FROM [int] NULL
GO
