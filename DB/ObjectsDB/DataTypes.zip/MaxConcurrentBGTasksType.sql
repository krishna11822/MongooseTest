IF NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'MaxConcurrentBGTasksType' AND ss.name = N'dbo')
CREATE TYPE [dbo].[MaxConcurrentBGTasksType] FROM [int] NULL
GO
