IF NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'EventVotingMinimumType' AND ss.name = N'dbo')
CREATE TYPE [dbo].[EventVotingMinimumType] FROM [decimal](6, 2) NULL
GO
