IF NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'ExtDataStoreAccessKeyType' AND ss.name = N'dbo')
CREATE TYPE [dbo].[ExtDataStoreAccessKeyType] FROM [nvarchar](440) NULL
GO
