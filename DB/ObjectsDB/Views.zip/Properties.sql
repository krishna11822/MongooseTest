SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON 
GO

IF OBJECTPROPERTY(OBJECT_ID(N'[dbo].[Properties]'), N'IsView') = 1
   DROP VIEW dbo.Properties
GO
-- Only create this view if this is not the application database.
IF OBJECTPROPERTY(OBJECT_ID(N'[dbo].[ObjProperties]'), N'IsTable') = 1 AND OBJECT_ID(N'[dbo].[UserNames]') IS NULL
EXECUTE (N'
/* $Header: /Tools/SQLScripts/ObjectsDB/Views/Properties.sql 3     7/19/16 5:07p Djohnson $Archive: $ */
CREATE VIEW dbo.Properties
AS
SELECT *
from dbo.ObjProperties'
)
GO
