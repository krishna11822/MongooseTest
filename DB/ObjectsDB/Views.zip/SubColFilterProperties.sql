SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON 
GO

IF OBJECTPROPERTY(OBJECT_ID(N'[dbo].[SubColFilterProperties]'), N'IsView') = 1
   DROP VIEW dbo.SubColFilterProperties
GO
-- Only create this view if this is not the application database.
IF OBJECTPROPERTY(OBJECT_ID(N'[dbo].[ObjSubColFilterProperties]'), N'IsTable') = 1 AND OBJECT_ID(N'[dbo].[UserNames]') IS NULL
EXECUTE (N'
/* $Header: /Tools/SQLScripts/ObjectsDB/Views/SubColFilterProperties.sql 3     7/19/16 5:07p Djohnson $Archive: $ */
CREATE VIEW dbo.SubColFilterProperties
AS
SELECT *
from dbo.ObjSubColFilterProperties'
)
GO
