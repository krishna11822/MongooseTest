SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON 
GO

IF OBJECTPROPERTY(OBJECT_ID(N'[dbo].[Methods]'), N'IsView') = 1
   DROP VIEW dbo.Methods
GO
-- Only create this view if this is not the application database.
IF OBJECTPROPERTY(OBJECT_ID(N'[dbo].[ObjMethods]'), N'IsTable') = 1 AND OBJECT_ID(N'[dbo].[UserNames]') IS NULL
EXECUTE (N'
/* $Header: /Tools/SQLScripts/ObjectsDB/Views/Methods.sql 3     7/19/16 5:07p Djohnson $Archive: $ */
CREATE VIEW dbo.Methods
AS
SELECT *
from dbo.ObjMethods'
)
GO
