SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON 
GO

IF OBJECTPROPERTY(OBJECT_ID(N'[dbo].[Tables]'), N'IsView') = 1
   DROP VIEW dbo.Tables
GO
-- Only create this view if this is not the application database.
IF OBJECTPROPERTY(OBJECT_ID(N'[dbo].[ObjTables]'), N'IsTable') = 1 AND OBJECT_ID(N'[dbo].[UserNames]') IS NULL
EXECUTE (N'
/* $Header: /Tools/SQLScripts/ObjectsDB/Views/Tables.sql 1     3/17/17 3:59p Djohnson $Archive: $ */
CREATE VIEW dbo.Tables
AS
SELECT *
from dbo.ObjTables'
)
GO
