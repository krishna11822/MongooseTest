/* $Header: /Tools/SQLScripts/ApplicationDB/Init Data/MessageTypes.sql 4     9/22/13 3:12a Hdu $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
*************************************************************** 
*/
/* Message Types */
IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 0)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  0
, 'DELETE'
, 'Delete Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 1)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  1
, 'EXISTS'
, 'Exists Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 2)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  2
, 'KEY'
, 'Key Field Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 3)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  3
, 'NOUPD'
, 'No Update Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 4)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  4
, 'CHILD'
, 'Child Exists Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 5)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  5
, 'SPST1'
, 'Standard Message Or Text'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 6)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  6
, 'SPST2'
, 'Sp Step 2 Message Type'
)


IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 7)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  7
, 'SYSDEL'
, 'Delete of System Type'
)


IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 8)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  8
, 'VALID'
, 'Data Entered is not Valid'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 9)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  9
, 'NODEL'
, 'Delete is Not Allowed'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 10)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  10
, 'CHART'
, 'Update of Chart'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 11)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  11
, 'SPST3'
, 'Sp Step 3 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 12)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  12
, 'SPST4'
, 'Sp Step 4 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 13)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  13
, 'SPST5'
, 'Sp Step 5 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 14)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  14
, 'SPST6'
, 'Sp Step 6 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 15)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  15
, 'SPST7'
, 'Sp Step 7 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 16)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  16
, 'SPST8'
, 'Sp Step 8 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 17)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  17
, 'CONSTR'
, 'Constraint Message'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 18)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  18
, 'DELCON'
, 'Delete Constraint Message'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 19)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  19
, 'SPST9'
, 'Sp Step 9 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 20)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  20
, 'SPST10'
, 'Sp Step 10 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 21)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  21
, 'SPST11'
, 'Sp Step 11 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 22)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  22
, 'SPST12'
, 'Sp Step 12 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 23)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  23
, 'SPST13'
, 'Sp Step 13 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 24)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  24
, 'SPST14'
, 'Sp Step 14 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 25)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  25
, 'SPST15'
, 'Sp Step 15 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 26)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  26
, 'SPST16'
, 'Sp Step 16 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 27)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  27
, 'SPST17'
, 'Sp Step 17 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 28)
insert into MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) values (
  28
, 'SPST18'
, 'Sp Step 18 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 29)
INSERT INTO MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) VALUES (
  29
, 'SPST19'
, 'Sp Step 19 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 30)
INSERT INTO MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) VALUES (
  30
, 'SPST20'
, 'Sp Step 20 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 31)
INSERT INTO MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) VALUES (
  31
, 'SPST21'
, 'Sp Step 21 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 32)
INSERT INTO MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) VALUES (
  32
, 'SPST22'
, 'Sp Step 22 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 33)
INSERT INTO MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) VALUES (
  33
, 'SPST23'
, 'Sp Step 23 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 34)
INSERT INTO MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) VALUES (
  34
, 'SPST24'
, 'Sp Step 24 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 35)
INSERT INTO MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) VALUES (
  35
, 'SPST25'
, 'Sp Step 25 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 36)
INSERT INTO MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) VALUES (
  36
, 'SPST26'
, 'Sp Step 26 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 37)
INSERT INTO MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) VALUES (
  37
, 'SPST27'
, 'Sp Step 27 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 38)
INSERT INTO MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) VALUES (
  38
, 'SPST28'
, 'Sp Step 28 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 39)
INSERT INTO MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) VALUES (
  39
, 'SPST29'
, 'Sp Step 29 Message Type'
)

IF NOT EXISTS (SELECT 1 FROM MessageTypes WHERE MessageType = 40)
INSERT INTO MessageTypes (
  MessageType
, MessageCode
, MessageDesc
) VALUES (
  40
, 'SPST30'
, 'Sp Step 30 Message Type'
)

GO
