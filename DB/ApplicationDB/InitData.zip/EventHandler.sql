/* $Header: /Tools/SQLScripts/ApplicationDB/Init Data/EventHandler.sql 45    20-11-2019 20:24 R.Shilts $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
*************************************************************** 
*/
DECLARE @EHRP uniqueidentifier
SET @EHRP = 'E436BF15-9A8E-45F4-9705-08A238B511334'

IF NOT EXISTS (SELECT 1 FROM EventHandler WHERE RowPointer = @EHRP)
   INSERT INTO EventHandler (EventName, Sequence, AccessAs, Synchronous, Transactional, Overridable, Active, RowPointer, Description)
      VALUES ('GenericNotify', 1, 'Core', 1, 0, 1, 1, @EHRP,
         N'Sends a message based on parameters')

   IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP)
      INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
         VALUES (@EHRP, 10, 1, 'TO(E(ToVar)) SUBJECT(E(SubjectVar)) CATEGORY(E(CategoryParm)) BODY(E(BodyVar)) SAVEMESSAGE(FALSE)
HTMLBODY(E(HTMLBodyVar))',
            N'Sends a message based on parameters')
GO

DECLARE @EHRP uniqueidentifier
SET @EHRP = 'DF0657B7-ADD1-4426-8423-A4E33FCBB814'

IF NOT EXISTS (SELECT 1 FROM EventHandler WHERE RowPointer = @EHRP)
   INSERT INTO EventHandler (EventName, Sequence, AccessAs, Synchronous, Transactional, Overridable, Active, RowPointer, Description)
      VALUES ('TaskListCheck', 1, 'Core', 1, 1, 1, 1, @EHRP,
         N'Reminds users of their tasks and appts.')
         
   IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP)
   BEGIN
      INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
         VALUES (@EHRP, 10, 22, 'METHOD("CheckAndFireTaskListSp") PARMS(RV(InfobarVar))',
            N'Reminds users of their tasks and appts.')

      INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
         VALUES (@EHRP, 20, 12, 'CONDITION(V(InfobarVar) > "")
SETPARMVALUES(InfobarParm=V(InfobarVar))',
            N'Preserves any error message')
   END
GO


-- Send e-mail message
DECLARE @EHRP_6F9605FA_AD8E_4FDE_8881_1898C610AC5D RowPointerType
SET @EHRP_6F9605FA_AD8E_4FDE_8881_1898C610AC5D = '6F9605FA-AD8E-4FDE-8881-1898C610AC5D'
DECLARE @MaxSeq_6F9605FA_AD8E_4FDE_8881_1898C610AC5D EventSequenceType
SELECT @MaxSeq_6F9605FA_AD8E_4FDE_8881_1898C610AC5D = ISNULL(MAX(Sequence), 0) + 1 FROM EventHandler WHERE EventName = N'GenericSendEmail'
 
IF NOT EXISTS (SELECT 1 FROM EventHandler WHERE RowPointer = @EHRP_6F9605FA_AD8E_4FDE_8881_1898C610AC5D)
INSERT [dbo].[EventHandler] ([EventName],[Sequence],[AccessAs],[AppliesToObjects],[Chrono],[KeepWithEventHandler],[Synchronous],[Transactional],[IgnoreFailure],[EventInitialStateRowPointer],[InitialEventActionRowPointer],[RowPointer],[Overridable],[Active],[Obsolete],[AppliesToInitiators],[Suspend],[Description],[EditableByWizard],[Purpose],[TriggeringProperty],[MethodToCall],[AppliesToSites])
   VALUES(N'GenericSendEmail', @MaxSeq_6F9605FA_AD8E_4FDE_8881_1898C610AC5D, N'Core', NULL, NULL, NULL, 1, 0, 0, NULL, NULL, '6F9605FA-AD8E-4FDE-8881-1898C610AC5D', 1, 1, 0, NULL, 0, N'Send e-mail message', 0, NULL, NULL, NULL, NULL)
 
IF EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP_6F9605FA_AD8E_4FDE_8881_1898C610AC5D)
BEGIN
   DELETE eava FROM EventAction ea INNER JOIN EventActionVariableAccess eava ON EventActionRowPointer = ea.RowPointer WHERE EventHandlerRowPointer = @EHRP_6F9605FA_AD8E_4FDE_8881_1898C610AC5D
   DELETE EventAction WHERE EventHandlerRowPointer = @EHRP_6F9605FA_AD8E_4FDE_8881_1898C610AC5D
END
 
INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description],[PayloadAccess],[ModifiedPayloadAccess],[UnmodifiedPayloadAccess])
   VALUES('6F9605FA-AD8E-4FDE-8881-1898C610AC5D', 10, 12, N'SETVARVALUES(
   AttachmentNum=1,
   NumAttachments=DBFUNCTION("dbo.NumEntries", E(AttachmentFileList), ",")
   )
', 'E09252C9-7080-4DA2-98BB-53C009C8D17E', NULL, NULL, NULL, NULL)
 
INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description],[PayloadAccess],[ModifiedPayloadAccess],[UnmodifiedPayloadAccess])
   VALUES('6F9605FA-AD8E-4FDE-8881-1898C610AC5D', 15, 5, N'CONDITION(V(NumAttachments) = 0)
DEST(100)
', '79547FDD-08B2-42F5-876A-7AB1BAEEB04D', NULL, NULL, NULL, NULL)
 
INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description],[PayloadAccess],[ModifiedPayloadAccess],[UnmodifiedPayloadAccess])
   VALUES('6F9605FA-AD8E-4FDE-8881-1898C610AC5D', 20, 12, N'SETVARVALUES(
   AttachmentFileVar=DBFUNCTION("dbo.Entry", V(AttachmentNum), E(AttachmentFileList), ","),
   AttachmentNameVar=DBFUNCTION("dbo.Entry", V(AttachmentNum), E(AttachmentNameList), ","),
   AttachmentDocTypeVar=DBFUNCTION("dbo.Entry", V(AttachmentNum), E(AttachmentDocTypeList), ","),
   AttachmentNum=1+V(AttachmentNum)
   )
', 'F9E2733C-9F6E-4FF6-967F-3BD22C0A2F9D', NULL, NULL, NULL, NULL)
 
INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description],[PayloadAccess],[ModifiedPayloadAccess],[UnmodifiedPayloadAccess])
   VALUES('6F9605FA-AD8E-4FDE-8881-1898C610AC5D', 30, 28, N'DOCACTION(ATTACH)
DOCTYPE(V(AttachmentDocTypeVar))
FILENAME(V(AttachmentFileVar))
ATTACHMENTNAME(V(AttachmentNameVar))
', '98AFB10C-B383-4233-B7FA-B16A2B42ACDD', NULL, NULL, NULL, NULL)
 
INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description],[PayloadAccess],[ModifiedPayloadAccess],[UnmodifiedPayloadAccess])
   VALUES('6F9605FA-AD8E-4FDE-8881-1898C610AC5D', 40, 5, N'CONDITION(V(AttachmentNum)<=V(NumAttachments))
DEST(20)
', '95C7E618-B064-4F81-BB5A-24D4C1B38AF1', NULL, NULL, NULL, NULL)
 
INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description],[PayloadAccess],[ModifiedPayloadAccess],[UnmodifiedPayloadAccess])
   VALUES('6F9605FA-AD8E-4FDE-8881-1898C610AC5D', 100, 26, N'CONDITION(TRUE)  TO(E(EmailTo))  REPLYTO(E(EmailReplyTo))  CC(E(EmailCc))  BCC(E(EmailBcc))  SUBJECT(E(EmailSubject))  BODY(E(EmailMessage)) HTMLFORMAT(E(EmailHTMLFormat) = "TRUE")', '1DA5CB84-EBD5-469F-82AB-4460A78744DD', N'Send e-mail message', NULL, NULL, NULL)
 
GO

DECLARE @EHRP uniqueidentifier
SET @EHRP = 'E70B3E38-D312-4D47-9D33-630F7D3D63E0'

IF NOT EXISTS (SELECT 1 FROM EventHandler WHERE RowPointer = @EHRP)
   INSERT INTO EventHandler (EventName, Sequence, AccessAs, Synchronous, Transactional, Overridable, Active, RowPointer, Description)
      VALUES (N'ProcessNewDataMaintenance', 1, 'Core', 1, 0, 1, 1, @EHRP,
         N'P: ProcessID, IdoProject, UserID')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 10)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 10, 27, N'IDO("TmpStagingNewDataMaintenances")
PROPERTIES("ProcessID, DataType, PropertyScale, LabelStringID, PropertyLength, Name, PrimaryKey, PropertyClass, Required, TableIDOName, ColumnDataType, DefaultValue")
FILTER(SUBSTITUTE("ProcessID = N''{0}''", E(ProcessID)))
ORDERBY(E(SortOrder))
SET(R(Batch) = RESULT)', N'query the batch')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 11)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 11, 11, N'CONDITION(ROWS(Batch) <= 0)
RESULT(MESSAGE("E=NoRowsDefinedForNewDataMaintenanceToProcess"))', N'verify at least 1 row in batch')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 20)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 20, 14, N'IDO("SqlTables")
PROPERTIES("table_name")
FILTER(SUBSTITUTE("table_name = N''{0}''", P(Batch, 1, "TableIDOName")))
SET(RV(ExistingTableName) = "table_name")', N'see if the table exists')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 21)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 21, 14, N'IDO("IdoCollections")
PROPERTIES("CollectionName")
FILTER(SUBSTITUTE("CollectionName = N''{0}''", P(Batch, 1, "TableIDOName")))
SET(RV(ExistingIDOName) = "CollectionName")', N'see if the IDO exists')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 22)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 22, 11, N'CONDITION(LEN(V(ExistingTableName)) > 0)
RESULT(MESSAGE("E=TableAlreadyExists"))', N'fail if the table exists')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 23)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 23, 11, N'CONDITION(LEN(V(ExistingIDOName)) > 0)
RESULT(MESSAGE("E=IDOAlreadyExists"))', N'fail if the IDO exists')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 40)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 40, 15, N'IDO("SqlTables")
ACTION(INSERT)
SETPROPVALUES("table_name" = E(TableName), "table_schema" = "dbo", "object_id" = V(nullvalue), "DerSource" = "ndmw", "DerIsSiteSplit" = E(SiteSplit) )', N'insert the table')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 50)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 50, 12, N'SETVARVALUES(BatchRowIndex = "0", PrimaryKeyColumns = "")', N'set column loop counter')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 51)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 51, 12, N'SETVARVALUES(SiteRefColumn = "")', N'initialize site ref column name variable')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 60)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 60, 12, N'SETVARVALUES(BatchRowIndex = 1 + V(BatchRowIndex), ColumnNullable = V(nullvalue))', N'increment batch row counter')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 70)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 70, 5, N'CONDITION(V(BatchRowIndex) > ROWS(Batch))
DEST(120)', N'go on to the ido if columns done')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 80)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 80, 12, N'CONDITION(P(Batch, V(BatchRowIndex), "Required") <> "1")
SETVARVALUES(ColumnNullable = "YES")', N'set column nullable var')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 90)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 90, 15, N'IDO("SqlColumns")
ACTION(INSERT)
SETPROPVALUES("columnName" = P(Batch, V(BatchRowIndex), "Name"), "tableName" = E(TableName), "tableSchema" = "dbo", "dataType" = P(Batch, V(BatchRowIndex), "ColumnDataType"), "decimalPos" = P(Batch, V(BatchRowIndex), "PropertyScale"), "UBDecPosUsed" = "0", "dataLength" = P(Batch, V(BatchRowIndex), "PropertyLength"), "UBLengthUsed" = "0", "isNullable" = V(ColumnNullable), "defaultValue" = V(nullvalue), "systemDataType" = V(nullvalue), "derShadowColumnName" = V(nullvalue))', N'insert the column')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 100)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 100, 12, N'CONDITION(P(Batch, V(BatchRowIndex), "PrimaryKey") = "1")
SETVARVALUES(PrimaryKeyColumns = SUBSTITUTE("{0}{1}{2}", V(PrimaryKeyColumns), V(Comma), P(Batch, V(BatchRowIndex), "Name")), Comma = ",")', N'maybe add to primary key list')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 110)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 110, 6, N'DEST(60)', N'back to top of column loop')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 120)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 120, 21, N'IDO("SqlTables")
METHOD("GenerateFrameworkDataForNDMW")
PARMS("dbo",E(TableName),RE(Infobar46), E(ViewName))', N'create mongoose system columns')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 130)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 130, 5, N'CONDITION(LEN(V(PrimaryKeyColumns)) <= 0)
DEST(300)', N'skip primary key if we don''t have any')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 131)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 131, 21, N'IDO("SqlTables")
METHOD("GetDefaultSiteColumnName")
PARMS(RV(SiteRefColumn))', N'get site ref column name value')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 140)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 140, 12, N'CONDITION(E(SiteSplit)= "1")
SETVARVALUES(PrimaryKeyColumns = SUBSTITUTE("{0}{1}{2}", V(PrimaryKeyColumns), V(Comma), V(SiteRefColumn)), Comma = ",")', N'Set SiteRef PK if it SiteSplit')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 150)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 150, 21, N'IDO("SqlTables")
METHOD("SqlPrimaryKeyModifySp")
PARMS(E(TableName), V(PrimaryKeyColumns), "1", RV(PrimaryKeyResult))', N'maybe create the primary key')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 200)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 200, 12, N'SETVARVALUES(IDONAME = E(TABLENAME))', N'set initial IDO name')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 210)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 210, 5, N'CONDITION(E(SiteSplit) <> "1")
DEST(300)', N'branch for site split logic')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 220)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 220, 21, N'IDO("AppTables")
METHOD("CreateViewsOverMultiSiteTablesSp")
PARMS(E(TableName), E(TableName), RV(Infobar210))', N'generate view')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 230)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 230, 12, N'SETVARVALUES(IDONAME = E(VIEWNAME))', N'Change IDO name to View name')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 300)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 300, 21, N'IDO("IdoCollections")
METHOD("IdoCollectionCreateSp")
PARMS(V(IDONAME), E(IdoProject), E(IDODescription), E(UserID), V(nullvalue), "0", "o" + V(IDOName), V(nullvalue), RV(InsertMessage))', N'create the ido')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 310)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 310, 21, N'IDO("IdoTables")
METHOD("IdoTableCreateSp")
PARMS(V(IDOName), V(IDOName), E(TableAlias), "3", "0", V(nullvalue), RV(IdoTableResult))', N'add the primary base table for the ido')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 320)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 320, 12, N'SETVARVALUES(BatchRowIndex = "0")', N'set the prop loop counter')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 330)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 330, 12, N'SETVARVALUES(BatchRowIndex = 1+V(BatchRowIndex))', N'increment the prop loop counter')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 340)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 340, 5, N'CONDITION(V(BatchRowIndex) > ROWS(Batch))
DEST(600)', N'go to finish if we are done')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 350)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 350, 21, N'IDO("IdoProperties")
METHOD("IdoPropertyCreateAutoSp")
PARMS(V(IDOName), E(TableAlias), P(Batch, V(BatchRowIndex), "Name"), P(Batch, V(BatchRowIndex), "Name"), RV(PropertyInsertResult))', N'insert the property')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 360)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 360, 5, N'CONDITION(P(Batch, V(BatchRowIndex), "PropertyClass") <> V(NullValue))
DEST(400)', N'check if property class is defined')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 370)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 370, 15, N'IDO("IdoProperties")
ACTION(UPDATE)
SETPROPVALUES("CollectionName" = V(IDOName), "PropertyName" = P(Batch, V(BatchRowIndex), "Name"), "DataType" = P(Batch, V(BatchRowIndex), "DataType"), "DataLength" = P(Batch, V(BatchRowIndex), "PropertyLength"), "DataDecimalPos" = P(Batch, V(BatchRowIndex), "PropertyScale"), "DefaultValue" = P(Batch, V(BatchRowIndex), "DefaultValue"), "LabelStringID" = P(Batch, V(BatchRowIndex), "LabelStringID"), "DevelopmentFlag" = "1", "PropertyClass" = P(Batch, V(BatchRowIndex), "PropertyClass"))', N'add property atts (no property class)')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 380)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 380, 6, N'DEST(330)', N'loop back')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 400)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 400, 14, N'IDO("IdoPropertyClasses")
PROPERTIES("EffectiveDataType, EffectiveDataLength, EffectiveDataDecimalPos, EffectiveDefaultValue, EffectiveColumnDataType, EffectiveIsRequired, EffectiveLabelStringID")
FILTER(SUBSTITUTE("ClassName = N''{0}''", P(Batch, V(BatchRowIndex), "PropertyClass")))
SET(RV(PCDataType) = "EffectiveDataType", RV(PCDataLength) = "EffectiveDataLength", RV(PCDataDecimalPos) = "EffectiveDataDecimalPos", RV(PCDefaultValue) = "EffectiveDefaultValue", RV(PCColumnDataType) = "EffectiveColumnDataType", RV(PCIsRequired) = "EffectiveIsRequired", RV(PCLabelStringID) = "EffectiveLabelStringID")', N'load property class data')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 410)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 410, 12, N'CONDITION(TRUE)
SETVARVALUES(DefDataType = P(Batch, V(BatchRowIndex), "DataType"),
 DefColumnDataType = P(Batch, V(BatchRowIndex), "ColumnDataType"),
 DefDataLength = P(Batch, V(BatchRowIndex), "PropertyLength"),
 DefDataDecimalPos = P(Batch, V(BatchRowIndex), "PropertyScale"),
 DefDefaultValue = P(Batch, V(BatchRowIndex), "DefaultValue"),
 DefLabelStringID = P(Batch, V(BatchRowIndex), "LabelStringID") )', N'set initial variables')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 420)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 420, 12, N'CONDITION(V(DefDataType) = V(PCDataType))
SETVARVALUES(DefDataType = V(nullvalue))', N'define data type')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 421)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 421, 12, N'CONDITION(V(DefColumnDataType) = V(PCColumnDataType))
SETVARVALUES(DefColumnDataType = V(nullvalue))', N'define column (SQL) data type')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 422)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 422, 12, N'CONDITION(V(DefDataLength) = V(PCDataLength))
SETVARVALUES(DefDataLength = V(nullvalue))', N'define data length')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 423)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 423, 12, N'CONDITION(V(DefDataDecimalPos) = V(PCDataDecimalPos))
SETVARVALUES(DefDataDecimalPos = V(nullvalue))', N'define decimal position (scale)')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 424)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 424, 12, N'CONDITION(V(DefDefaultValue) = V(PCDefaultValue))
SETVARVALUES(DefDefaultValue = V(nullvalue))', N'define default value')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 425)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 425, 12, N'CONDITION(V(DefLabelStringID) = V(PCLabelStringID))
SETVARVALUES(DefLabelStringID = V(nullvalue))', N'define label string ID')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 490)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 490, 15, N'IDO("IdoProperties")
ACTION(UPDATE)
SETPROPVALUES("CollectionName" = V(IDOName), "PropertyName" = P(Batch, V(BatchRowIndex), "Name"), "DataType" = V(DefDataType), "ColumnDataType" = V(DefColumnDataType), "DataLength" = V(DefDataLength), "DataDecimalPos" = V(DefDataDecimalPos), "DefaultValue" = V(DefDefaultValue), "LabelStringID" = V(DefLabelStringID), "DevelopmentFlag" = "1", "PropertyClass" = P(Batch, V(BatchRowIndex), "PropertyClass"))', N'update with Property class defined')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 500)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 500, 5, N'CONDITION(E(KeepStg) = "1")
DEST(360)', N'skip batch delete if we are keeping')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 510)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 510, 15, N'IDO("TmpStagingNewDataMaintenances")
ACTION(DELETE)
SETPROPVALUES("ProcessID" = E(ProcessID), "Name" = P(Batch, V(BatchRowIndex), "Name"))', N'delete the staging data row')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 520)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 520, 6, N'DEST(330)', N'top of property loop')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 600)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 600, 21, N'IDO("IdoProperties")
METHOD("IdoPropertyCreateAutoSp")
PARMS(V(IDOName), E(TableAlias), "NoteExistsFlag", "NoteExistsFlag", RV(PropertyInsertResult))', N'add the NoteExists framework property')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 601)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 601, 21, N'IDO("IdoProperties")
METHOD("IdoPropertyCreateAutoSp")
PARMS(V(IDOName), E(TableAlias), "CreatedBy", "CreatedBy", RV(PropertyInsertResult))', N'add the CreatedBy framework property')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 602)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 602, 21, N'IDO("IdoProperties")
METHOD("IdoPropertyCreateAutoSp")
PARMS(V(IDOName), E(TableAlias), "UpdatedBy", "UpdatedBy", RV(PropertyInsertResult))', N'add the UpdatedBy framework property')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 603)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 603, 21, N'IDO("IdoProperties")
METHOD("IdoPropertyCreateAutoSp")
PARMS(V(IDOName), E(TableAlias), "CreateDate", "CreateDate", RV(PropertyInsertResult))', N'add the CreateDate framework property')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 604)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 604, 21, N'IDO("IdoProperties")
METHOD("IdoPropertyCreateAutoSp")
PARMS(V(IDOName), E(TableAlias), "RecordDate", "RecordDate", RV(PropertyInsertResult))', N'add the RecordDate framework property')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 605)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 605, 21, N'IDO("IdoProperties")
METHOD("IdoPropertyCreateAutoSp")
PARMS(V(IDOName), E(TableAlias), "RowPointer", "RowPointer", RV(PropertyInsertResult))', N'add the RowPointer framework property')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 606)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 606, 21, N'IDO("IdoProperties")
METHOD("IdoPropertyCreateAutoSp")
PARMS(V(IDOName), E(TableAlias), "InWorkflow", "InWorkflow", RV(PropertyInsertResult))', N'add the InWorkFlow framework property')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 620)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 620, 5, N'CONDITION(E(IDOTablesXml) = "")
DEST(625)', N'Branch if no IdoTables to be created')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 621)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 621, 21, N'IDO("IdoTables")
METHOD("CreateTableFromDataTable")
PARMS(E(IDOTablesXml), RV(IDOTablesXmlResult))', N'add any Ido Tables')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 625)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 625, 5, N'CONDITION(E(IDOSubCollectionPropertiesXml) = "")
DEST(700)', N'branch if no subCollection properties')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 626)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 626, 21, N'IDO("IdoProperties")
METHOD("CreatePropertyFromDataTable")
PARMS(E(IDOSubCollectionPropertiesXml), RV(IDOSubCollectionPropertiesXmlResult))', N'add any Ido SubCollection properties')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 700)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 700, 5, N'CONDITION(E(GenerateScripts) = "0")
DEST(1000)', N'branch if generating SQL scripts')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 710)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 710, 5, N'CONDITION(E(UDTNames) = "")
DEST(730)', N'if no UDTs, go on to script table')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 720)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 720, 21, N'IDO("TmpStagingNewDataMaintenances")
METHOD("UDTScriptSp")
PARMS(E(UDTNames), "dbo", RV(UDTScript))', N'write UDT script')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 730)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 730, 21, N'IDO("TmpStagingNewDataMaintenances")
METHOD("TableScriptStringSp")
PARMS(P(Batch, 1, "TableIDOName"), "dbo", RV(TableScript))', N'write Create Table script')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 800)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 800, 12, N'CONDITION(1 = 1)
SETPARMVALUES(ScriptString = SUBSTITUTE( "{0}  {1}", V(UDTScript),V(TableScript)))', N'Concatenate the script strings')

IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP AND Sequence = 1000)
   INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
      VALUES (@EHRP, 1000, 10, N'RESULT(MESSAGE("E=TableAndIDOCreated"))', N'finish')

		 
GO

-- Event Handler for send e-mail message with attachments

DECLARE @EHRP_78D548B1_E7F4_412C_9618_843A4C9F863F RowPointerType
SET @EHRP_78D548B1_E7F4_412C_9618_843A4C9F863F = '78D548B1-E7F4-412C-9618-843A4C9F863F'
DECLARE @MaxSeq_78D548B1_E7F4_412C_9618_843A4C9F863F EventSequenceType
SELECT @MaxSeq_78D548B1_E7F4_412C_9618_843A4C9F863F = ISNULL(MAX(Sequence), 0) + 1 FROM EventHandler WHERE EventName = N'GenericNotifyWithAttachments'
 
IF NOT EXISTS (SELECT 1 FROM EventHandler WHERE RowPointer = @EHRP_78D548B1_E7F4_412C_9618_843A4C9F863F)
INSERT [dbo].[EventHandler] ([EventName],[Sequence],[AccessAs],[AppliesToObjects],[Chrono],[KeepWithEventHandler],[Synchronous],[Transactional],[IgnoreFailure],[EventInitialStateRowPointer],[InitialEventActionRowPointer],[RowPointer],[Overridable],[Active],[Obsolete],[AppliesToInitiators],[Suspend],[Description],[EditableByWizard],[Purpose],[TriggeringProperty],[MethodToCall],[AppliesToSites])
   VALUES(N'GenericNotifyWithAttachments', @MaxSeq_78D548B1_E7F4_412C_9618_843A4C9F863F, N'Core', NULL, NULL, NULL, 1, 1, 0, 'F38D0708-DCD8-4AD2-95F5-DFE0389B027B', '0FA4BC38-FDEA-4217-B3BB-72D40B245C84', '78D548B1-E7F4-412C-9618-843A4C9F863F', 1, 1, 0, NULL, 0, N'Send e-mail message with attachments', 0, NULL, NULL, NULL, NULL)
 
IF EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP_78D548B1_E7F4_412C_9618_843A4C9F863F)
BEGIN
   DELETE eava FROM EventAction ea INNER JOIN EventActionVariableAccess eava ON EventActionRowPointer = ea.RowPointer WHERE EventHandlerRowPointer = @EHRP_78D548B1_E7F4_412C_9618_843A4C9F863F
   DELETE EventAction WHERE EventHandlerRowPointer = @EHRP_78D548B1_E7F4_412C_9618_843A4C9F863F
END
 
INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description],[PayloadAccess],[ModifiedPayloadAccess],[UnmodifiedPayloadAccess])
   VALUES('78D548B1-E7F4-412C-9618-843A4C9F863F', 10, 22, N'METHOD("EventSpawnEventAttachmentsSp")
PARMS("ObjectSentEmail", E(RowPointer), EVENTSTATEID(), "False")
', '1A05D909-EAA1-40F5-9DDB-AB6797588735', N'Attach attachments as event attachments', NULL, NULL, NULL)
 
INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description],[PayloadAccess],[ModifiedPayloadAccess],[UnmodifiedPayloadAccess])
   VALUES('78D548B1-E7F4-412C-9618-843A4C9F863F', 20, 27, N'IDO("ObjectSentEmails")
PROPERTIES("BccList, CcList, HtmlFormat, Message, RowPointer, Sent, SentDate, SentFrom, TableRowPointer, Subject,ToList")
FILTER(SUBSTITUTE("RowPointer = ''{0}''", E(RowPointer)))
SET(R(SentEmail) = RESULT)
', '7B56AAFE-CE56-4C8E-B897-309C97104106', N'Get Email to send in result set', NULL, NULL, NULL)
 
INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description],[PayloadAccess],[ModifiedPayloadAccess],[UnmodifiedPayloadAccess])
   VALUES('78D548B1-E7F4-412C-9618-843A4C9F863F', 30, 26, N'CONDITION(TRUE)
TO(P(SentEmail, 1, "ToList"))
CC(P(SentEmail, 1, "CcList"))
BCC(P(SentEmail, 1, "BccList"))
REPLYTO(P(SentEmail, 1, "SentFrom"))
SUBJECT(P(SentEmail, 1, "Subject"))
HTMLFORMAT(P(SentEmail, 1, "HtmlFormat")="1")
BODY(P(SentEmail, 1, "Message"))
ATTACH(ALL)
', '7791637B-2A64-45B6-9C1A-4F91B91DAAD9', N'Send email with attachments', NULL, NULL, NULL)
 
INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description],[PayloadAccess],[ModifiedPayloadAccess],[UnmodifiedPayloadAccess])
   VALUES('78D548B1-E7F4-412C-9618-843A4C9F863F', 40, 15, N'COLLECTION(SentEmail)
ROW(1)
ACTION(UPDATE)
SETPROPVALUES("Sent" = "1", "SentDate" = CURDATETIME())
OPTIMISTICLOCKING(FALSE)
COMMIT(TRUE)
', '776665F7-08DB-4995-9F3F-07B7D537B3EB', N'Update sent flag and date', NULL, NULL, NULL)
GO


-- Send an Alert to ION
DECLARE @EHRP_EF2404C5_4679_4D93_9A9F_E26542CBE6D8 RowPointerType
SET @EHRP_EF2404C5_4679_4D93_9A9F_E26542CBE6D8 = 'EF2404C5-4679-4D93-9A9F-E26542CBE6D8'
DECLARE @MaxSeq_EF2404C5_4679_4D93_9A9F_E26542CBE6D8 EventSequenceType
SELECT @MaxSeq_EF2404C5_4679_4D93_9A9F_E26542CBE6D8 = ISNULL(MAX(Sequence), 0) + 1 FROM EventHandler WHERE EventName = N'GenericSendPulseAlertBOD'
 
IF NOT EXISTS (SELECT 1 FROM EventHandler WHERE RowPointer = @EHRP_EF2404C5_4679_4D93_9A9F_E26542CBE6D8)
INSERT [dbo].[EventHandler] ([EventName],[Sequence],[AccessAs],[AppliesToObjects],[Chrono],[KeepWithEventHandler],[Synchronous],[Transactional],[IgnoreFailure],[EventInitialStateRowPointer],[InitialEventActionRowPointer],[RowPointer],[Overridable],[Active],[Obsolete],[AppliesToInitiators],[Suspend],[Description],[EditableByWizard],[Purpose],[TriggeringProperty],[MethodToCall],[AppliesToSites])
   VALUES(N'GenericSendPulseAlertBOD', @MaxSeq_EF2404C5_4679_4D93_9A9F_E26542CBE6D8, N'Core', NULL, NULL, NULL, 1, 0, 0, 'B3F98CFE-2522-4322-824E-C86687EA49A6', 'E8564000-3B4F-47DE-A667-901F08BE6748', @EHRP_EF2404C5_4679_4D93_9A9F_E26542CBE6D8, 1, 1, 0, NULL, 0, N'Send an alert to ION', 0, NULL, NULL, NULL, NULL)
 
IF EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP_EF2404C5_4679_4D93_9A9F_E26542CBE6D8)
BEGIN
   DELETE eava FROM EventAction ea INNER JOIN EventActionVariableAccess eava ON EventActionRowPointer = ea.RowPointer WHERE EventHandlerRowPointer = @EHRP_EF2404C5_4679_4D93_9A9F_E26542CBE6D8
   DELETE EventAction WHERE EventHandlerRowPointer = @EHRP_EF2404C5_4679_4D93_9A9F_E26542CBE6D8
END
 
INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description])
   VALUES(@EHRP_EF2404C5_4679_4D93_9A9F_E26542CBE6D8, 10, 29, N'BODNOUN("PulseAlert")  BODVERB("Process")  BODXML(''<ProcessPulseAlert xmlns="http://schema.infor.com/InforOAGIS/2" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://schema.infor.com/InforOAGIS/2 http://schema.infor.com/2.9.0/InforOAGIS/BODs/Developer/ProcessPulseAlert.xsd" releaseID="9.2"><ApplicationArea><Sender><LogicalID>FROMLOGICALID()</LogicalID><ComponentID>erp</ComponentID><ConfirmationCode>OnError</ConfirmationCode><AuthorizationID /></Sender><CreationDateTime>BODCURDATETIME()</CreationDateTime><BODID>TNIDID(PARMS(localSite.site))?BODNOUN()&amp;verb=BODVERB()</BODID></ApplicationArea><DataArea><Process><TenantID>TENANTID()</TenantID><AccountingEntityID>PARMS(localSite.site)</AccountingEntityID><ActionCriteria><ActionExpression actionCode="Add" /></ActionCriteria></Process><PulseAlert><Description languageID="en-us">IF(E(MessageDescription) = "", E(MessageBody), E(MessageDescription))</Description><AlertDetail sequence="1"><PulseDocumentReference sequence="1" type="PulseAlert"><DocumentID><ID accountingEntity="PARMS(localSite.site)" lid="FROMLOGICALID()" /></DocumentID></PulseDocumentReference><TreeNode sequence="1"><ID>1</ID><NodeName>Message</NodeName><TreeNodeParameter><Name>Message 1</Name><Value>E(MessageBody)</Value><DataType listID="PulseDatatypes">STRING</DataType></TreeNodeParameter></TreeNode></AlertDetail><DistributionPerson><PersonReference><IDs><ID>E(UserEmail)</ID></IDs></PersonReference></DistributionPerson></PulseAlert></DataArea></ProcessPulseAlert>'')  BODXMLNAME("ProcessPulseAlert.xml")  BODATTRS("//ProcessPulseAlert[1]/DataArea[1]/PulseAlert[1]/Description[1]" = IF(E(MessageDescription) = "", E(MessageBody), E(MessageDescription)), "//ProcessPulseAlert[1]/DataArea[1]/PulseAlert[1]/AlertDetail[1]/TreeNode[1]/TreeNodeParameter[1]/Name[1]" = E(MessageSubject), "//ProcessPulseAlert[1]/DataArea[1]/PulseAlert[1]/AlertDetail[1]/TreeNode[1]/TreeNodeParameter[1]/Value[1]" = E(MessageBody), "//ProcessPulseAlert[1]/DataArea[1]/PulseAlert[1]/DistributionPerson[1]/PersonReference[1]/IDs[1]/ID[1]" = E(UserEmail))','A4792696-2077-45F0-967E-7AB5854B2DF0', N'Send an alert to ION')
 

-- Event to assign admin licence module to user
DECLARE @EHRP_D946FCAF_944C_414C_AD87_03F9843D23AF RowPointerType
SET @EHRP_D946FCAF_944C_414C_AD87_03F9843D23AF = 'D946FCAF-944C-414C-AD87-03F9843D23AF'
DECLARE @MaxSeq_D946FCAF_944C_414C_AD87_03F9843D23AF EventSequenceType
SELECT @MaxSeq_D946FCAF_944C_414C_AD87_03F9843D23AF = ISNULL(MAX(Sequence), 0) + 1 FROM EventHandler WHERE EventName = N'AssignUserToAdminLicenseModule'
 
IF NOT EXISTS (SELECT 1 FROM EventHandler WHERE RowPointer = @EHRP_D946FCAF_944C_414C_AD87_03F9843D23AF)
INSERT [dbo].[EventHandler] ([EventName],[Sequence],[AccessAs],[AppliesToObjects],[Chrono],[KeepWithEventHandler],[Synchronous],[Transactional],[IgnoreFailure],[EventInitialStateRowPointer],[InitialEventActionRowPointer],[RowPointer],[Overridable],[Active],[Obsolete],[AppliesToInitiators],[Suspend],[Description],[EditableByWizard],[Purpose],[TriggeringProperty],[MethodToCall],[AppliesToSites])
   VALUES(N'AssignUserToAdminLicenseModule', @MaxSeq_D946FCAF_944C_414C_AD87_03F9843D23AF, N'Core', NULL, NULL, NULL, 1, 0, 0, '0CA4F893-048A-41F6-8170-9193CAD04FBC', 'E495D802-6718-44A7-86FF-F524DAB57260', @EHRP_D946FCAF_944C_414C_AD87_03F9843D23AF, 1, 1, 0, NULL, 0, N'Event to assign admin license module', 0, NULL, NULL, NULL, NULL)
 
IF EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP_D946FCAF_944C_414C_AD87_03F9843D23AF)
BEGIN
   DELETE eava FROM EventAction ea INNER JOIN EventActionVariableAccess eava ON EventActionRowPointer = ea.RowPointer WHERE EventHandlerRowPointer = @EHRP_D946FCAF_944C_414C_AD87_03F9843D23AF
   DELETE EventAction WHERE EventHandlerRowPointer = @EHRP_D946FCAF_944C_414C_AD87_03F9843D23AF
END
 
INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description])
   VALUES(@EHRP_D946FCAF_944C_414C_AD87_03F9843D23AF, 10, 14, N'IDO("SystemProcessDefaults")
PROPERTIES("DefaultValue")
FILTER("DefaultType=57")
SET(RV(AdminLicenseModuleName) = "DefaultValue")
','8D1821A8-2941-452A-B012-EF0FDF035ABA', N'Load row from SystemProcessDefaults')

INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description])
   VALUES(@EHRP_D946FCAF_944C_414C_AD87_03F9843D23AF, 20, 14, N'IDO("UserNames")
PROPERTIES("UserId")
FILTER(SUBSTITUTE("Username={0}", FE(UsernameParm)))
SET(RV(UserIdV) = "UserId")
','C473462B-60F3-4C20-AF7A-4EE0F084162C', N'Get Userid from UserName')
 
INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description])
   VALUES(@EHRP_D946FCAF_944C_414C_AD87_03F9843D23AF, 30, 5, N'CONDITION(V(UserIdV) = "")
DEST(70)
','D2C5B580-1FA1-4C9D-95F4-95A682913F10', N'if userid does not exit finish it')

INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description])
   VALUES(@EHRP_D946FCAF_944C_414C_AD87_03F9843D23AF, 40, 14, N'IDO("UserModules")
PROPERTIES("UserId")
FILTER(SUBSTITUTE("UserId= {0} AND ModuleName = {1}", FV(UserIdV), FV(AdminLicenseModuleName)))
SET(RV(ModuleUserIdV) = "UserId")
','2E6E53A1-EF82-4254-94BF-1A13843B7825', N'Check if userid exists in UsersModule')
 

INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description])
   VALUES(@EHRP_D946FCAF_944C_414C_AD87_03F9843D23AF, 50, 5, N'CONDITION(V(ModuleUserIdV) <> "")
DEST(70)','EFD543DE-CC08-4588-B087-1255919B3440', N'Finish if record exists')
 
INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description])
   VALUES(@EHRP_D946FCAF_944C_414C_AD87_03F9843D23AF, 60, 15, N'IDO("UserModules")
ACTION(INSERT)
SETPROPVALUES("UserId" = V(UserIdV), "ModuleName" = V(AdminLicenseModuleName))
','8E5EA813-C4DD-4DDD-BCC5-ED829AE99977', N'Insert Module Name')
 
INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description])
   VALUES(@EHRP_D946FCAF_944C_414C_AD87_03F9843D23AF, 70, 10, NULL,'7C4DD777-EB6D-4F3F-BD24-C056A0C6A837', N'Finish it')

GO

-- Event to assign named license module to named user
DECLARE @EHRP_187D7817_A429_456D_A07E_9707A4CC710F RowPointerType
SET @EHRP_187D7817_A429_456D_A07E_9707A4CC710F = '187D7817-A429-456D-A07E-9707A4CC710F'
DECLARE @MaxSeq_187D7817_A429_456D_A07E_9707A4CC710F EventSequenceType
SELECT @MaxSeq_187D7817_A429_456D_A07E_9707A4CC710F = ISNULL(MAX(Sequence), 0) + 1 FROM EventHandler WHERE EventName = N'AssignUserToLicenseModule'

IF NOT EXISTS (SELECT 1 FROM EventHandler WHERE RowPointer = @EHRP_187D7817_A429_456D_A07E_9707A4CC710F)
INSERT [dbo].[EventHandler] ([EventName],[Sequence],[AccessAs],[AppliesToObjects],[Chrono],[KeepWithEventHandler],[Synchronous],[Transactional],[IgnoreFailure],[EventInitialStateRowPointer],[InitialEventActionRowPointer],[RowPointer],[Overridable],[Active],[Obsolete],[AppliesToInitiators],[Suspend],[Description],[EditableByWizard],[Purpose],[TriggeringProperty],[MethodToCall],[AppliesToSites])
   VALUES(N'AssignUserToLicenseModule', @MaxSeq_187D7817_A429_456D_A07E_9707A4CC710F, N'Core', NULL, NULL, NULL, 1, 0, 0, '005611B2-5470-4F9A-91D3-59FCD1284E9C', '424411C3-ABCE-4490-B113-AD9AE0B01FCD', @EHRP_187D7817_A429_456D_A07E_9707A4CC710F, 1, 1, 0, NULL, 0, N'Assign UserID to license module', 0, NULL, NULL, NULL, NULL)
 
IF EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP_187D7817_A429_456D_A07E_9707A4CC710F)
BEGIN
   DELETE eava FROM EventAction ea INNER JOIN EventActionVariableAccess eava ON EventActionRowPointer = ea.RowPointer WHERE EventHandlerRowPointer = @EHRP_187D7817_A429_456D_A07E_9707A4CC710F
   DELETE EventAction WHERE EventHandlerRowPointer = @EHRP_187D7817_A429_456D_A07E_9707A4CC710F
END

INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description])
   VALUES(@EHRP_187D7817_A429_456D_A07E_9707A4CC710F, 10, 12, N'SETVARVALUES(ModuleNameV = E(ModulenameParm))
','9D7702C5-847F-44AC-B014-CD57F76F958F', N'Shuffle Module Name')

INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description])
   VALUES(@EHRP_187D7817_A429_456D_A07E_9707A4CC710F, 20, 14, N'IDO("UserNames")
PROPERTIES("UserId")
FILTER(SUBSTITUTE("Username={0}", FE(UsernameParm)))
SET(RV(UserIdV) = "UserId")
','F720E443-12DB-4E14-B15D-2A673BDB6E48', N'Get Userid from UserName')

INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description])
   VALUES(@EHRP_187D7817_A429_456D_A07E_9707A4CC710F, 30, 5, N'CONDITION(V(UserIdV) = "")
DEST(99)
','67A5DD1E-5FBD-41D5-8441-22D85C670E6D', N'If userid does not exist, finish')

INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description])
   VALUES(@EHRP_187D7817_A429_456D_A07E_9707A4CC710F, 40, 14, N'IDO("UserModules")
PROPERTIES("UserId")
FILTER(SUBSTITUTE("UserId= {0} AND ModuleName = {1}", FV(UserIdV), FV(ModulenameV)))
SET(RV(ModuleUserIdV) = "UserId")
','AD694259-08F4-4C85-9377-658914C7F573', N'Check if userid exists in UsersModule')

INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description])
   VALUES(@EHRP_187D7817_A429_456D_A07E_9707A4CC710F, 50, 5, N'CONDITION(V(ModuleUserIdV) <> "")
DEST(99)
','4D772007-33D8-425F-A883-B0F45D579B87', N'Finish if record exists')

INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description])
   VALUES(@EHRP_187D7817_A429_456D_A07E_9707A4CC710F, 60, 15, N'IDO("UserModules")
ACTION(INSERT)
SETPROPVALUES("UserId" = V(UserIdV), "ModuleName" = V(ModulenameV))
','0599415E-F9D5-40C4-BAAA-060DB47D268C', N'Insert Module Name')

INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description])
   VALUES(@EHRP_187D7817_A429_456D_A07E_9707A4CC710F, 99, 10, NULL
,'3E9A7D86-FD84-4B24-A2FD-4FDBF0195ADF', N'Finish')

GO

-- Assign Random Password To User
DECLARE @EHRP_63BE1DC5_B040_486F_B5C1_C83DF98FE4E6 RowPointerType
SET @EHRP_63BE1DC5_B040_486F_B5C1_C83DF98FE4E6 = '63BE1DC5-B040-486F-B5C1-C83DF98FE4E6'
DECLARE @MaxSeq_63BE1DC5_B040_486F_B5C1_C83DF98FE4E6 EventSequenceType
SELECT @MaxSeq_63BE1DC5_B040_486F_B5C1_C83DF98FE4E6 = ISNULL(MAX(Sequence), 0) + 1 FROM EventHandler WHERE EventName = N'AssignRandomPasswordToUser'
 
IF NOT EXISTS (SELECT 1 FROM EventHandler WHERE RowPointer = @EHRP_63BE1DC5_B040_486F_B5C1_C83DF98FE4E6)
INSERT [dbo].[EventHandler] ([EventName],[Sequence],[AccessAs],[AppliesToObjects],[Chrono],[KeepWithEventHandler],[Synchronous],[Transactional],[IgnoreFailure],[EventInitialStateRowPointer],[InitialEventActionRowPointer],[RowPointer],[Overridable],[Active],[Obsolete],[AppliesToInitiators],[Suspend],[Description],[EditableByWizard],[Purpose],[TriggeringProperty],[MethodToCall],[AppliesToSites])
   VALUES(N'AssignRandomPasswordToUser', @MaxSeq_63BE1DC5_B040_486F_B5C1_C83DF98FE4E6, N'Core', NULL, NULL, NULL, 1, 0, 0, '95835D9C-DF62-4DDB-A1C5-55DC6A2BB626', '229260AC-97B3-467E-A027-F7103D3A88E6', '63BE1DC5-B040-486F-B5C1-C83DF98FE4E6', 1, 1, 0, NULL, 0, N'Assign random encrypted password to user', 0, NULL, NULL, NULL, NULL)
 
IF EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP_63BE1DC5_B040_486F_B5C1_C83DF98FE4E6)
BEGIN
   DELETE eava FROM EventAction ea INNER JOIN EventActionVariableAccess eava ON EventActionRowPointer = ea.RowPointer WHERE EventHandlerRowPointer = @EHRP_63BE1DC5_B040_486F_B5C1_C83DF98FE4E6
   DELETE EventAction WHERE EventHandlerRowPointer = @EHRP_63BE1DC5_B040_486F_B5C1_C83DF98FE4E6
END
 
INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description],[PayloadAccess],[ModifiedPayloadAccess],[UnmodifiedPayloadAccess])
   VALUES('63BE1DC5-B040-486F-B5C1-C83DF98FE4E6', 10, 14, N'IDO("UserNames")
PROPERTIES("UserId, UserPassword")
FILTER(SUBSTITUTE("Username={0}", FE(UsernameParm)))
SET(RV(UserIdV) = "UserId")
', 'A7F9D8E4-C8AC-482C-BC9E-FADA6C2D6475', N'Load row for UsernameParm', NULL, NULL, NULL)
 
INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description],[PayloadAccess],[ModifiedPayloadAccess],[UnmodifiedPayloadAccess])
   VALUES('63BE1DC5-B040-486F-B5C1-C83DF98FE4E6', 20, 5, N'CONDITION(V(UserIdV) = "")
DEST(109)', 'B603A33D-DE50-4B48-8694-6464AF7353FA', N'If no row found, finish', NULL, NULL, NULL)
 
INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description],[PayloadAccess],[ModifiedPayloadAccess],[UnmodifiedPayloadAccess])
   VALUES('63BE1DC5-B040-486F-B5C1-C83DF98FE4E6', 30, 21, N'IDO("UserNames")
METHOD("GetRandomPassword")
PARMS(RV(randomPwd))
', 'F58D83FD-17B2-4323-B13A-8062C439A02C', N'Call IDO method to get random password', NULL, NULL, NULL)
 
INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description],[PayloadAccess],[ModifiedPayloadAccess],[UnmodifiedPayloadAccess])
   VALUES('63BE1DC5-B040-486F-B5C1-C83DF98FE4E6', 40, 5, N'CONDITION(V(randomPwd) = "")
DEST(109)
', 'CF1D2280-C9C3-4640-AA41-810914CA2AF1', N'Password is empty, finish', NULL, NULL, NULL)
 
INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description],[PayloadAccess],[ModifiedPayloadAccess],[UnmodifiedPayloadAccess])
   VALUES('63BE1DC5-B040-486F-B5C1-C83DF98FE4E6', 50, 27, N'IDO("UserNames")
PROPERTIES("UserId, UserPassword")
DISTINCT(FALSE)
FILTER(SUBSTITUTE("Username={0}", FE(UsernameParm)))
SET(R(PWDToUpdate) = RESULT)
', '27E19464-F73D-42D6-B5B1-FE832E415A00', N'Load Collection for UsernameParm', NULL, NULL, NULL)
 
INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description],[PayloadAccess],[ModifiedPayloadAccess],[UnmodifiedPayloadAccess])
   VALUES('63BE1DC5-B040-486F-B5C1-C83DF98FE4E6', 60, 15, N'COLLECTION(PWDToUpdate)
ROW(1)
ACTION(UPDATE)
SETPROPVALUES("UserPassword" = V(randomPwd))
OPTIMISTICLOCKING(FALSE)
COMMIT(TRUE)
', '308D6EF8-BCC7-4E0A-BA25-89992D8B4ACC', N'Update user password', NULL, NULL, NULL)
 
INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description],[PayloadAccess],[ModifiedPayloadAccess],[UnmodifiedPayloadAccess])
   VALUES('63BE1DC5-B040-486F-B5C1-C83DF98FE4E6', 109, 10, NULL, 'CD95716B-F568-4E21-BE95-29599DB4153E', N'Finish', NULL, NULL, NULL)
 
GO

-- ClearServiceSessions
DECLARE @EHRP uniqueidentifier
SET @EHRP = 'CF41C0EE-D2B0-4E78-B9B1-01D1769E6708'

IF NOT EXISTS (SELECT 1 FROM EventHandler WHERE RowPointer = @EHRP)
   INSERT INTO EventHandler (EventName, Sequence, AccessAs, Synchronous, Transactional, Overridable, Active, RowPointer, Description)
      VALUES ('ClearServiceSessions', 1, 'Core', 1, 1, 1, 1, @EHRP,
         N'Clears out old service sessions.')
         
   IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP)
   BEGIN
      INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
         VALUES (@EHRP, 10, 21, 'IDO("EventTriggers") METHOD("ClearOldSessionsSp") PARMS("", RV(InfobarVar))',
            N'Clears out old service sessions.')

      INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
         VALUES (@EHRP, 20, 12, 'CONDITION(V(InfobarVar) > "")
SETPARMVALUES(InfobarParm=V(InfobarVar))',
            N'Preserves any error message')
   END
GO

-- LazyDeleteLicenseModuleExecute
DECLARE @EHRP uniqueidentifier
SET @EHRP = 'AD26C162-85FA-4224-9B08-15AF500F197E'

IF NOT EXISTS (SELECT 1 FROM [dbo].[EventHandler] WHERE [RowPointer] = @EHRP)
BEGIN
   INSERT [dbo].[EventHandler] ([EventName],[Sequence],[AccessAs],[AppliesToObjects],[Chrono],[KeepWithEventHandler],[Synchronous],[Transactional],[IgnoreFailure],
         [RowPointer], [EventInitialStateRowPointer],[InitialEventActionRowPointer],
         [Overridable],[Active],[Obsolete],[AppliesToInitiators],[Suspend],
         [Description],[EditableByWizard],[Purpose],[TriggeringProperty],[MethodToCall],[AppliesToSites])
      VALUES(N'LazyDeleteLicenseModuleExecute', 1, N'Core', NULL, NULL, NULL, 1, 0, 0, 
         @EHRP, 'D25238D6-C7E8-4093-8E39-74DE802B9A45', 'FF996E76-C401-471E-8150-B4E2F1EFEE31', 
         1, 1, 0, NULL, 0, 
         N'Execute the user-modules lazy delete', 0, NULL, NULL, NULL, NULL)
END

IF EXISTS (SELECT 1 FROM [dbo].[EventAction] WHERE [EventHandlerRowPointer] = @EHRP)
BEGIN
   DELETE eava FROM [dbo].[EventAction] ea INNER JOIN [dbo].[EventActionVariableAccess] eava ON [EventActionRowPointer] = ea.[RowPointer] WHERE [EventHandlerRowPointer] = @EHRP
   DELETE [dbo].[EventAction] WHERE [EventHandlerRowPointer] = @EHRP
END

INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description])
   VALUES(@EHRP, 10, 14, N'IDO("UserNames")
PROPERTIES("UserId")
FILTER(SUBSTITUTE("Username={0}", FE(UsernameParm)))
SET(RV(UserIdV) = "UserId")
','F588C1FD-3365-4419-8491-54C119528978', N'Load row for UsernameParm')

INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description])
VALUES(@EHRP, 20, 5, N'CONDITION(V(UserIdV) = "")
DEST(99)
','72F23949-44DE-405D-8C26-E646A6112978', N'If userid does not exist, finish')

INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description])
VALUES(@EHRP, 30, 21, N'IDO("UserModules")
METHOD("UserModulesDeleteForUserSp")
PARMS(V(UserIdV))
','8D08D7E9-7B82-4677-AEED-F275597B74ED', N'remove rows marked for delete')

INSERT [dbo].[EventAction] ([EventHandlerRowPointer],[Sequence],[ActionType],[Parameters],[RowPointer],[Description],[PayloadAccess],[ModifiedPayloadAccess],[UnmodifiedPayloadAccess])
VALUES(@EHRP, 99, 10, NULL, 'B7A6C6AD-CE58-4D08-A124-E90BA54DB9F4', N'Finish', NULL, NULL, NULL)

GO

-- PurgeHistoryData
DECLARE @EHRP uniqueidentifier
SET @EHRP = 'BA3AF188-0658-4583-83C6-3B7D5A598281'

IF NOT EXISTS (SELECT 1 FROM EventHandler WHERE RowPointer = @EHRP)
BEGIN
   INSERT INTO EventHandler (EventName, Sequence, AccessAs, Synchronous, Transactional, Overridable, Active, RowPointer, Description)
   VALUES ('PurgeHistoryData', 1, 'Core', 1, 1, 1, 1, @EHRP, N'Purge History Data By Parameter.')
END         
IF NOT EXISTS (SELECT 1 FROM EventAction WHERE EventHandlerRowPointer = @EHRP)
BEGIN
    INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
	VALUES (@EHRP, 10, 22, 'METHOD("PurgeHistoryDataSp")
	PARMS("$service", E(PurgeDBMethodToCall), E(DaysOld), RV(InfobarVar))', N'Call PurgeHistoryDataSp with parameters.')

    INSERT INTO EventAction (EventHandlerRowPointer, Sequence, ActionType, Parameters, Description)
	VALUES (@EHRP, 20, 12, 'CONDITION(V(InfobarVar) > "")
	SETPARMVALUES(InfobarParm=V(InfobarVar))', N'Preserves any message')
END
GO
