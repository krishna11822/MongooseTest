/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
*************************************************************** 
*/
/* MediaType */
--Add existing media type

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'%')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'%', N'application/x-trash',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'~')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'~', N'application/x-trash',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'323')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'323', N'text/h323',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'3gp')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'3gp', N'video/3gpp',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'7z')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'7z', N'application/x-7z-compressed',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'abw')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'abw', N'application/x-abiword',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ai')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ai', N'application/postscript',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'aif')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'aif', N'audio/x-aiff',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'aifc')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'aifc', N'audio/x-aiff',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'aiff')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'aiff', N'audio/x-aiff',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'alc')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'alc', N'chemical/x-alchemy',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'amr')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'amr', N'audio/amr',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'anx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'anx', N'application/annodex',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'apk')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'apk', N'application/vnd.android.package-archive',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'art')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'art', N'image/x-jg',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'asc')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'asc', N'text/plain',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'asf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'asf', N'video/x-ms-asf',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'asn')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'asn', N'chemical/x-ncbi-asn1',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'aso')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'aso', N'chemical/x-ncbi-asn1-binary',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'asx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'asx', N'video/x-ms-asf',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'atom')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'atom', N'application/atom+xml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'atomcat')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'atomcat', N'application/atomcat+xml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'atomsrv')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'atomsrv', N'application/atomserv+xml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'au')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'au', N'audio/basic',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'avi')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'avi', N'video/x-msvideo',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'awb')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'awb', N'audio/amr-wb',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'axa')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'axa', N'audio/annodex',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'axv')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'axv', N'video/annodex',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'b')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'b', N'chemical/x-molconn-Z',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'bak')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'bak', N'application/x-trash',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'bat')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'bat', N'application/x-msdos-program',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'bcpio')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'bcpio', N'application/x-bcpio',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'bib')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'bib', N'text/x-bibtex',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'bin')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'bin', N'application/octet-stream',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'bmp')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'bmp', N'image/x-ms-bmp',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'boo')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'boo', N'text/x-boo',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'book')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'book', N'application/x-maker',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'brf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'brf', N'text/plain',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'bsd')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'bsd', N'chemical/x-crossfire',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'c')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'c', N'text/x-csrc',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'c++')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'c++', N'text/x-c++src',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'c3d')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'c3d', N'chemical/x-chem3d',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cab')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cab', N'application/x-cab',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cac')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cac', N'chemical/x-cache',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cache')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cache', N'chemical/x-cache',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cap')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cap', N'application/cap',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cascii')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cascii', N'chemical/x-cactvs-binary',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cat')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cat', N'application/vnd.ms-pki.seccat',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cbin')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cbin', N'chemical/x-cactvs-binary',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cbr')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cbr', N'application/x-cbr',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cbz')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cbz', N'application/x-cbz',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cc')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cc', N'text/x-c++src',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cda')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cda', N'application/x-cdf',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cdf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cdf', N'application/x-cdf',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cdr')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cdr', N'image/x-coreldraw',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cdt')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cdt', N'image/x-coreldrawtemplate',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cdx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cdx', N'chemical/x-cdx',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cdy')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cdy', N'application/vnd.cinderella',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cef')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cef', N'chemical/x-cxf',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cer')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cer', N'chemical/x-cerius',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'chm')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'chm', N'chemical/x-chemdraw',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'chrt')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'chrt', N'application/x-kchart',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cif')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cif', N'chemical/x-cif',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'class')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'class', N'application/java-vm',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cls')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cls', N'text/x-tex',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cmdf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cmdf', N'chemical/x-cmdf',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cml')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cml', N'chemical/x-cml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cod')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cod', N'application/vnd.rim.cod',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'com')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'com', N'application/x-msdos-program',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cpa')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cpa', N'chemical/x-compass',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cpio')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cpio', N'application/x-cpio',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cpp')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cpp', N'text/x-c++src',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cpt')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cpt', N'application/mac-compactpro',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cr2')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cr2', N'image/x-canon-cr2',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'crl')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'crl', N'application/x-pkcs7-crl',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'crt')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'crt', N'application/x-x509-ca-cert',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'crw')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'crw', N'image/x-canon-crw',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'csf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'csf', N'chemical/x-cache-csf',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'csh')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'csh', N'application/x-csh',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'csm')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'csm', N'chemical/x-csml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'csml')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'csml', N'chemical/x-csml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'css')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'css', N'text/css',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'csv')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'csv', N'text/csv',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ctab')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ctab', N'chemical/x-cactvs-binary',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ctx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ctx', N'chemical/x-ctx',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cu')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cu', N'application/cu-seeme',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cub')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cub', N'chemical/x-gaussian-cube',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cxf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cxf', N'chemical/x-cxf',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'cxx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'cxx', N'text/x-c++src',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'd')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'd', N'text/x-dsrc',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'dat')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'dat', N'application/x-ns-proxy-autoconfig',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'davmount')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'davmount', N'application/davmount+xml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'dcr')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'dcr', N'application/x-director',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'deb')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'deb', N'application/x-debian-package',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'der')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'der', N'application/x-x509-ca-cert',1)

IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'dif')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'dif', N'video/dv',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'diff')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'diff', N'text/x-diff',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'dir')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'dir', N'application/x-director',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'djv')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'djv', N'image/vnd.djvu',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'djvu')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'djvu', N'image/vnd.djvu',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'dl')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'dl', N'video/dl',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'dll')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'dll', N'application/x-msdos-program',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'dmg')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'dmg', N'application/x-apple-diskimage',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'dms')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'dms', N'application/x-dms',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'doc')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'doc', N'application/msword',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'docx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'docx', N'application/vnd.openxmlformats-officedocument.wordprocessingml.document',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'dot')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'dot', N'application/msword',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'dotx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'dotx', N'application/vnd.openxmlformats-officedocument.wordprocessingml.template',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'dv')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'dv', N'video/dv',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'dvi')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'dvi', N'application/x-dvi',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'dx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'dx', N'chemical/x-jcamp-dx',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'dxr')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'dxr', N'application/x-director',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'emb')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'emb', N'chemical/x-embl-dl-nucleotide',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'embl')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'embl', N'chemical/x-embl-dl-nucleotide',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'eml')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'eml', N'message/rfc822',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ent')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ent', N'chemical/x-ncbi-asn1-ascii',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'eps')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'eps', N'application/postscript',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'eps2')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'eps2', N'application/postscript',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'eps3')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'eps3', N'application/postscript',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'epsf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'epsf', N'application/postscript',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'epsi')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'epsi', N'application/postscript',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'erf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'erf', N'image/x-epson-erf',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'es')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'es', N'application/ecmascript',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'etx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'etx', N'text/x-setext',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'exe')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'exe', N'application/x-msdos-program',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ez')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ez', N'application/andrew-inset',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'fb')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'fb', N'application/x-maker',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'fbdoc')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'fbdoc', N'application/x-maker',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'fch')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'fch', N'chemical/x-gaussian-checkpoint',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'fchk')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'fchk', N'chemical/x-gaussian-checkpoint',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'fig')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'fig', N'application/x-xfig',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'flac')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'flac', N'audio/flac',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'fli')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'fli', N'video/fli',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'flv')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'flv', N'video/x-flv',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'fm')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'fm', N'application/x-maker',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'frame')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'frame', N'application/x-maker',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'frm')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'frm', N'application/x-maker',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'gal')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'gal', N'chemical/x-gaussian-log',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'gam')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'gam', N'chemical/x-gamess-input',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'gamin')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'gamin', N'chemical/x-gamess-input',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'gau')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'gau', N'chemical/x-gaussian-input',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'gcd')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'gcd', N'text/x-pcs-gcd',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'gcf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'gcf', N'application/x-graphing-calculator',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'gcg')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'gcg', N'chemical/x-gcg8-sequence',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'gen')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'gen', N'chemical/x-genbank',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'gf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'gf', N'application/x-tex-gf',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'gif')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'gif', N'image/gif',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'gjc')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'gjc', N'chemical/x-gaussian-input',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'gjf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'gjf', N'chemical/x-gaussian-input',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'gl')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'gl', N'video/gl',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'gnumeric')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'gnumeric', N'application/x-gnumeric',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'gpt')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'gpt', N'chemical/x-mopac-graph',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'gsf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'gsf', N'application/x-font',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'gsm')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'gsm', N'audio/x-gsm',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'gtar')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'gtar', N'application/x-gtar',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'h')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'h', N'text/x-chdr',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'h++')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'h++', N'text/x-c++hdr',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'hdf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'hdf', N'application/x-hdf',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'hh')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'hh', N'text/x-c++hdr',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'hin')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'hin', N'chemical/x-hin',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'hpp')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'hpp', N'text/x-c++hdr',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'hqx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'hqx', N'application/mac-binhex40',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'hs')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'hs', N'text/x-haskell',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'hta')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'hta', N'application/hta',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'htc')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'htc', N'text/x-component',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'htm')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'htm', N'text/html',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'html')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'html', N'text/html',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'hxx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'hxx', N'text/x-c++hdr',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ica')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ica', N'application/x-ica',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ice')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ice', N'x-conference/x-cooltalk',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ico')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ico', N'image/x-icon',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ics')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ics', N'text/calendar',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'icz')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'icz', N'text/calendar',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ief')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ief', N'image/ief',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'iges')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'iges', N'model/iges',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'igs')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'igs', N'model/iges',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'iii')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'iii', N'application/x-iphone',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'info')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'info', N'application/x-info',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'inp')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'inp', N'chemical/x-gamess-input',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ins')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ins', N'application/x-internet-signup',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'iso')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'iso', N'application/x-iso9660-image',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'isp')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'isp', N'application/x-internet-signup',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ist')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ist', N'chemical/x-isostar',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'istr')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'istr', N'chemical/x-isostar',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'jad')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'jad', N'text/vnd.sun.j2me.app-descriptor',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'jam')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'jam', N'application/x-jam',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'jar')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'jar', N'application/java-archive',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'java')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'java', N'text/x-java',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'jdx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'jdx', N'chemical/x-jcamp-dx',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'jks')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'jks', N'application/octet-stream',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'jmz')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'jmz', N'application/x-jmol',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'jng')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'jng', N'image/x-jng',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'jnlp')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'jnlp', N'application/x-java-jnlp-file',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'jpe')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'jpe', N'image/jpeg',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'jpeg')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'jpeg', N'image/jpeg',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'jpg')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'jpg', N'image/jpeg',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'js')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'js', N'application/javascript',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'json')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'json', N'application/json',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'kar')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'kar', N'audio/midi',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'key')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'key', N'application/pgp-keys',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'kil')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'kil', N'application/x-killustrator',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'kin')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'kin', N'chemical/x-kinemage',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'kml')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'kml', N'application/vnd.google-earth.kml+xml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'kmz')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'kmz', N'application/vnd.google-earth.kmz',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'kpr')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'kpr', N'application/x-kpresenter',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'kpt')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'kpt', N'application/x-kpresenter',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ksp')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ksp', N'application/x-kspread',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'kwd')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'kwd', N'application/x-kword',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'kwt')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'kwt', N'application/x-kword',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'latex')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'latex', N'application/x-latex',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'lha')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'lha', N'application/x-lha',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'lhs')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'lhs', N'text/x-literate-haskell',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'lin')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'lin', N'application/bbolin',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'lsf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'lsf', N'video/x-la-asf',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'lsx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'lsx', N'video/x-la-asf',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ltx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ltx', N'text/x-tex',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'lyx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'lyx', N'application/x-lyx',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'lzh')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'lzh', N'application/x-lzh',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'lzx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'lzx', N'application/x-lzx',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'm3g')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'm3g', N'application/m3g',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'm3u')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'm3u', N'audio/mpegurl',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'm4a')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'm4a', N'audio/mpeg',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'maker')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'maker', N'application/x-maker',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'man')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'man', N'application/x-troff-man',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'manifest')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'manifest', N'text/cache-manifest',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'map')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'map', N'application/octet-stream',1)

IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mcif')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mcif', N'chemical/x-mmcif',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mcm')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mcm', N'chemical/x-macmolecule',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mdb')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mdb', N'application/msaccess',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'me')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'me', N'application/x-troff-me',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mesh')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mesh', N'model/mesh',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mid')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mid', N'audio/midi',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'midi')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'midi', N'audio/midi',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mif')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mif', N'application/x-mif',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mkv')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mkv', N'video/x-matroska',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mm')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mm', N'application/x-freemind',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mmd')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mmd', N'chemical/x-macromodel-input',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mmf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mmf', N'application/vnd.smaf',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mml')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mml', N'text/mathml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mmod')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mmod', N'chemical/x-macromodel-input',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mng')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mng', N'video/x-mng',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'moc')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'moc', N'text/x-moc',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mol')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mol', N'chemical/x-mdl-molfile',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mol2')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mol2', N'chemical/x-mol2',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'moo')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'moo', N'chemical/x-mopac-out',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mop')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mop', N'chemical/x-mopac-input',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mopcrt')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mopcrt', N'chemical/x-mopac-input',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mov')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mov', N'video/quicktime',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'movie')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'movie', N'video/x-sgi-movie',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mp2')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mp2', N'audio/mpeg',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mp3')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mp3', N'audio/mpeg',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mp4')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mp4', N'video/mp4',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mpc')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mpc', N'chemical/x-mopac-input',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mpe')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mpe', N'video/mpeg',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mpeg')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mpeg', N'video/mpeg',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mpega')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mpega', N'audio/mpeg',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mpg')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mpg', N'video/mpeg',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mpga')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mpga', N'audio/mpeg',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mpv')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mpv', N'video/x-matroska',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ms')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ms', N'application/x-troff-ms',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'msg')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'msg', N'application/vnd.ms-outlook',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'msh')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'msh', N'model/mesh',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'msi')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'msi', N'application/x-msi',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mvb')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mvb', N'chemical/x-mopac-vib',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mxf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mxf', N'application/mxf',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'mxu')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'mxu', N'video/vnd.mpegurl',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'nb')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'nb', N'application/mathematica',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'nbp')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'nbp', N'application/mathematica',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'nc')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'nc', N'application/x-netcdf',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'nef')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'nef', N'image/x-nikon-nef',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'nwc')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'nwc', N'application/x-nwc',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'o')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'o', N'application/x-object',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'oda')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'oda', N'application/oda',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'odb')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'odb', N'application/vnd.oasis.opendocument.database',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'odc')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'odc', N'application/vnd.oasis.opendocument.chart',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'odf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'odf', N'application/vnd.oasis.opendocument.formula',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'odg')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'odg', N'application/vnd.oasis.opendocument.graphics',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'odi')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'odi', N'application/vnd.oasis.opendocument.image',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'odm')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'odm', N'application/vnd.oasis.opendocument.text-master',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'odp')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'odp', N'application/vnd.oasis.opendocument.presentation',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ods')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ods', N'application/vnd.oasis.opendocument.spreadsheet',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'odt')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'odt', N'application/vnd.oasis.opendocument.text',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'oga')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'oga', N'audio/ogg',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ogg')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ogg', N'audio/ogg',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ogv')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ogv', N'video/ogg',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ogx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ogx', N'application/ogg',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'old')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'old', N'application/x-trash',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'orf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'orf', N'image/x-olympus-orf',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'otg')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'otg', N'application/vnd.oasis.opendocument.graphics-template',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'oth')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'oth', N'application/vnd.oasis.opendocument.text-web',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'otp')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'otp', N'application/vnd.oasis.opendocument.presentation-template',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ots')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ots', N'application/vnd.oasis.opendocument.spreadsheet-template',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ott')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ott', N'application/vnd.oasis.opendocument.text-template',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'oza')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'oza', N'application/x-oz-application',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'p')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'p', N'text/x-pascal',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'p12')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'p12', N'application/x-pkcs12',1)

IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'p7r')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'p7r', N'application/x-pkcs7-certreqresp',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pac')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pac', N'application/x-ns-proxy-autoconfig',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pas')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pas', N'text/x-pascal',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pat')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pat', N'image/x-coreldrawpattern',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'patch')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'patch', N'text/x-diff',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pbm')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pbm', N'image/x-portable-bitmap',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pcap')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pcap', N'application/cap',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pcf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pcf', N'application/x-font',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pcf.Z')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pcf.Z', N'application/x-font',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pcx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pcx', N'image/pcx',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pdb')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pdb', N'chemical/x-pdb',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pdf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pdf', N'application/pdf',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pfa')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pfa', N'application/x-font',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pfb')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pfb', N'application/x-font',1)

IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pfx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pfx', N'application/x-pkcs12',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pgm')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pgm', N'image/x-portable-graymap',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pgn')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pgn', N'application/x-chess-pgn',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pgp')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pgp', N'application/pgp-signature',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'php')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'php', N'application/x-httpd-php',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'php3')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'php3', N'application/x-httpd-php3',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'php3p')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'php3p', N'application/x-httpd-php3-preprocessed',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'php4')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'php4', N'application/x-httpd-php4',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'php5')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'php5', N'application/x-httpd-php5',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'phps')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'phps', N'application/x-httpd-php-source',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pht')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pht', N'application/x-httpd-php',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'phtml')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'phtml', N'application/x-httpd-php',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pk')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pk', N'application/x-tex-pk',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pl')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pl', N'text/x-perl',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pls')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pls', N'audio/x-scpls',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pm')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pm', N'text/x-perl',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'png')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'png', N'image/png',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pnm')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pnm', N'image/x-portable-anymap',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pot')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pot', N'text/plain',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'potx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'potx', N'application/vnd.openxmlformats-officedocument.presentationml.template',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ppm')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ppm', N'image/x-portable-pixmap',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pps')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pps', N'application/vnd.ms-powerpoint',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ppsx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ppsx', N'application/vnd.openxmlformats-officedocument.presentationml.slideshow',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ppt')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ppt', N'application/vnd.ms-powerpoint',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pptx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pptx', N'application/vnd.openxmlformats-officedocument.presentationml.presentation',1)
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'prf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'prf', N'application/pics-rules',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'prt')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'prt', N'chemical/x-ncbi-asn1-ascii',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ps')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ps', N'application/postscript',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'psd')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'psd', N'image/x-photoshop',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'py')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'py', N'text/x-python',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pyc')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pyc', N'application/x-python-code',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'pyo')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'pyo', N'application/x-python-code',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'qgs')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'qgs', N'application/x-qgis',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'qt')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'qt', N'video/quicktime',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'qtl')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'qtl', N'application/x-quicktimeplayer',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ra')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ra', N'audio/x-pn-realaudio',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ram')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ram', N'audio/x-pn-realaudio',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'rar')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'rar', N'application/rar',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ras')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ras', N'image/x-cmu-raster',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'rb')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'rb', N'application/x-ruby',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'rd')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'rd', N'chemical/x-mdl-rdfile',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'rdf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'rdf', N'application/rdf+xml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'rgb')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'rgb', N'image/x-rgb',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'rhtml')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'rhtml', N'application/x-httpd-eruby',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'rm')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'rm', N'audio/x-pn-realaudio',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'roff')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'roff', N'application/x-troff',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ros')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ros', N'chemical/x-rosdal',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'rpm')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'rpm', N'application/x-redhat-package-manager',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'rss')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'rss', N'application/rss+xml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'rtf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'rtf', N'application/rtf',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'rtx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'rtx', N'text/richtext',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'rxn')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'rxn', N'chemical/x-mdl-rxnfile',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'scala')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'scala', N'text/x-scala',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'scr')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'scr', N'application/x-silverlight',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sct')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sct', N'text/scriptlet',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sd')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sd', N'chemical/x-mdl-sdfile',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sd2')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sd2', N'audio/x-sd2',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sda')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sda', N'application/vnd.stardivision.draw',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sdc')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sdc', N'application/vnd.stardivision.calc',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sdd')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sdd', N'application/vnd.stardivision.impress',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sdf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sdf', N'application/vnd.stardivision.math',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sds')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sds', N'application/vnd.stardivision.chart',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sdw')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sdw', N'application/vnd.stardivision.writer',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ser')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ser', N'application/java-serialized-object',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sgf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sgf', N'application/x-go-sgf',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sgl')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sgl', N'application/vnd.stardivision.writer-global',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sh')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sh', N'application/x-sh',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'shar')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'shar', N'application/x-shar',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'shp')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'shp', N'application/x-qgis',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'shtml')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'shtml', N'text/html',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'shx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'shx', N'application/x-qgis',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sid')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sid', N'audio/prs.sid',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sik')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sik', N'application/x-trash',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'silo')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'silo', N'model/mesh',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sis')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sis', N'application/vnd.symbian.install',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sisx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sisx', N'x-epoc/x-sisx-app',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sit')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sit', N'application/x-stuffit',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sitx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sitx', N'application/x-stuffit',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'skd')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'skd', N'application/x-koan',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'skm')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'skm', N'application/x-koan',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'skp')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'skp', N'application/x-koan',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'skt')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'skt', N'application/x-koan',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'smi')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'smi', N'application/smil',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'smil')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'smil', N'application/smil',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'snd')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'snd', N'audio/basic',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'spc')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'spc', N'chemical/x-galactic-spc',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'spl')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'spl', N'application/futuresplash',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'spx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'spx', N'audio/ogg',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sql')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sql', N'application/octet-stream',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'src')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'src', N'application/x-wais-source',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'stc')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'stc', N'application/vnd.sun.xml.calc.template',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'std')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'std', N'application/vnd.sun.xml.draw.template',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sti')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sti', N'application/vnd.sun.xml.impress.template',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'stl')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'stl', N'application/vnd.ms-pki.stl',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'stw')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'stw', N'application/vnd.sun.xml.writer.template',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sty')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sty', N'text/x-tex',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sv4cpio')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sv4cpio', N'application/x-sv4cpio',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sv4crc')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sv4crc', N'application/x-sv4crc',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'svg')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'svg', N'image/svg+xml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'svgz')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'svgz', N'image/svg+xml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sw')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sw', N'chemical/x-swissprot',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'swf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'swf', N'application/x-shockwave-flash',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'swfl')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'swfl', N'application/x-shockwave-flash',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sxc')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sxc', N'application/vnd.sun.xml.calc',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sxd')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sxd', N'application/vnd.sun.xml.draw',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sxg')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sxg', N'application/vnd.sun.xml.writer.global',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sxi')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sxi', N'application/vnd.sun.xml.impress',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sxm')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sxm', N'application/vnd.sun.xml.math',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'sxw')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'sxw', N'application/vnd.sun.xml.writer',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N't')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N't', N'application/x-troff',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'tar')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'tar', N'application/x-tar',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'taz')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'taz', N'application/x-gtar',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'tcl')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'tcl', N'application/x-tcl',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'tex')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'tex', N'text/x-tex',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'texi')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'texi', N'application/x-texinfo',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'texinfo')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'texinfo', N'application/x-texinfo',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'text')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'text', N'text/plain',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'tgf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'tgf', N'chemical/x-mdl-tgf',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'tgz')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'tgz', N'application/x-gtar',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'tif')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'tif', N'image/tiff',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'tiff')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'tiff', N'image/tiff',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'tk')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'tk', N'text/x-tcl',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'tm')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'tm', N'text/texmacs',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'torrent')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'torrent', N'application/x-bittorrent',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'tr')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'tr', N'application/x-troff',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ts')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ts', N'text/texmacs',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'tsp')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'tsp', N'application/dsptype',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'tsv')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'tsv', N'text/tab-separated-values',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'txt')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'txt', N'text/plain',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'udeb')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'udeb', N'application/x-debian-package',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'uls')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'uls', N'text/iuls',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ustar')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ustar', N'application/x-ustar',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'val')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'val', N'chemical/x-ncbi-asn1-binary',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'vcd')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'vcd', N'application/x-cdlink',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'vcf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'vcf', N'text/x-vcard',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'vcs')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'vcs', N'text/x-vcalendar',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'vmd')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'vmd', N'chemical/x-vmd',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'vms')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'vms', N'chemical/x-vamas-iso14976',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'vrm')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'vrm', N'x-world/x-vrml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'vrml')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'vrml', N'model/vrml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'vsd')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'vsd', N'application/vnd.visio',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'wad')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'wad', N'application/x-doom',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'wav')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'wav', N'audio/x-wav',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'wax')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'wax', N'audio/x-ms-wax',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'wbmp')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'wbmp', N'image/vnd.wap.wbmp',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'wbxml')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'wbxml', N'application/vnd.wap.wbxml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'wk')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'wk', N'application/x-123',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'wm')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'wm', N'video/x-ms-wm',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'wma')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'wma', N'audio/x-ms-wma',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'wmd')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'wmd', N'application/x-ms-wmd',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'wml')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'wml', N'text/vnd.wap.wml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'wmlc')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'wmlc', N'application/vnd.wap.wmlc',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'wmls')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'wmls', N'text/vnd.wap.wmlscript',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'wmlsc')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'wmlsc', N'application/vnd.wap.wmlscriptc',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'wmv')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'wmv', N'video/x-ms-wmv',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'wmx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'wmx', N'video/x-ms-wmx',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'wmz')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'wmz', N'application/x-ms-wmz',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'wp5')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'wp5', N'application/vnd.wordperfect5.1',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'wpd')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'wpd', N'application/vnd.wordperfect',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'wrl')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'wrl', N'model/vrml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'wsc')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'wsc', N'text/scriptlet',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'wvx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'wvx', N'video/x-ms-wvx',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'wz')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'wz', N'application/x-wingz',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'x3d')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'x3d', N'model/x3d+xml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'x3db')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'x3db', N'model/x3d+binary',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'x3dv')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'x3dv', N'model/x3d+vrml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'xbm')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'xbm', N'image/x-xbitmap',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'xcf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'xcf', N'application/x-xcf',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'xht')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'xht', N'application/xhtml+xml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'xhtml')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'xhtml', N'application/xhtml+xml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'xlb')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'xlb', N'application/vnd.ms-excel',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'xls')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'xls', N'application/vnd.ms-excel',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'xlsx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'xlsx', N'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'xlt')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'xlt', N'application/vnd.ms-excel',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'xltx')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'xltx', N'application/vnd.openxmlformats-officedocument.spreadsheetml.template',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'xml')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'xml', N'application/xml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'xpi')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'xpi', N'application/x-xpinstall',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'xpm')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'xpm', N'image/x-xpixmap',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'xsd')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'xsd', N'application/xml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'xsl')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'xsl', N'application/xml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'xspf')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'xspf', N'application/xspf+xml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'xtel')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'xtel', N'chemical/x-xtel',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'xul')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'xul', N'application/vnd.mozilla.xul+xml',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'xwd')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'xwd', N'image/x-xwindowdump',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'xyz')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'xyz', N'chemical/x-xyz',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'zip')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'zip', N'application/zip',1)
 
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'zmt')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'zmt', N'chemical/x-mopac-input',1)

--types needed by Mongoose
IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'iac')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'iac', N'application/octet-stream',1)

IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'iads')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'iads', N'application/octet-stream',1)

IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'iap')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'iap', N'application/octet-stream',1)

IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'component')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'component', N'application/octet-stream',1)

IF NOT EXISTS (SELECT 1 FROM MediaType WHERE DocumentExtension = N'ionapi')
INSERT INTO MediaType (DocumentExtension, MediaType, Active) VALUES (N'ionapi', N'application/octet-stream',1)


--Update BLOB Format
--BLOB Format is by default Document Extension
UPDATE MediaType SET BlobFormat = DocumentExtension
UPDATE MediaType SET BlobFormat = 'JPEG' WHERE DocumentExtension IN ('JPEG', 'JPG', 'JPE', 'JFIF')
UPDATE MediaType SET BlobFormat = 'BMP'  WHERE DocumentExtension IN ('BMP', 'DIB')
UPDATE MediaType SET BlobFormat = 'TIFF' WHERE DocumentExtension IN ('TIFF', 'TIF')
UPDATE MediaType SET BlobFormat = 'ICON' WHERE DocumentExtension IN ('ICON', 'ICO')

--Update AllowUpload
--Allow file types EXCEPT the "dangerous" ones
--For a list of "dangerous" types, check out FileValidation.cs
DECLARE @FORBIDDEN TABLE (name NVARCHAR(32));
INSERT @FORBIDDEN(name) VALUES ('%'),('~');                 -- x-trash
INSERT @FORBIDDEN(name) VALUES ('exe'),('dll'),('com');
INSERT @FORBIDDEN(name) VALUES ('sys'),('drv'),('pif');
INSERT @FORBIDDEN(name) VALUES ('ocx'),('cab'),('msi'),('msc'),('iso');
INSERT @FORBIDDEN(name) values ('so'), ('elf'),('dmg');
INSERT @FORBIDDEN(name) VALUES ('manifest'),('website'),('local');
INSERT @FORBIDDEN(name) VALUES ('url'),('hta');
INSERT @FORBIDDEN(name) VALUES ('swf'),('swfl'),('spl');
INSERT @FORBIDDEN(name) VALUES ('php'),('php3'),('php3p'),('php4'),('php5'),('phps'),('phpt'),('phtml');

UPDATE [MediaType] SET [AllowUpload] = 0 WHERE DocumentExtension     IN (SELECT * FROM @FORBIDDEN)
UPDATE [MediaType] SET [AllowUpload] = 1 WHERE DocumentExtension NOT IN (SELECT * FROM @FORBIDDEN)

GO


