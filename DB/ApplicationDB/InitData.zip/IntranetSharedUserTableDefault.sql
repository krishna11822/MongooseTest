/* $Header: /Tools/SQLScripts/ApplicationDB/Init Data/IntranetSharedUserTableDefault.sql 10    7/23/13 2:12p Djohnson $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
*************************************************************** 
*/
-- Shareable tables
IF NOT EXISTS (SELECT 1 FROM IntranetSharedUserTableDefault WHERE TableName = 'GroupNames')
INSERT INTO IntranetSharedUserTableDefault 
  (TableName, UserIdColumnName, GroupIdColumnName, Shareable, UpdateRefId)
   VALUES ('GroupNames', NULL, 'GroupId', 1, 0) 
   
IF NOT EXISTS (SELECT 1 FROM IntranetSharedUserTableDefault WHERE TableName = 'UserGroupMap_mst')
INSERT INTO IntranetSharedUserTableDefault 
  (TableName, UserIdColumnName, GroupIdColumnName, Shareable, UpdateRefId)
   VALUES ('UserGroupMap_mst', 'UserId', 'GroupId', 1, 1) 
   
IF NOT EXISTS (SELECT 1 FROM IntranetSharedUserTableDefault WHERE TableName = 'UserNames')
INSERT INTO IntranetSharedUserTableDefault 
  (TableName, UserIdColumnName, GroupIdColumnName, Shareable, UpdateRefId)
  VALUES ('UserNames', 'UserId', NULL, 1, 0)

IF NOT EXISTS (SELECT 1 FROM IntranetSharedUserTableDefault WHERE TableName = 'UserModules')
INSERT INTO IntranetSharedUserTableDefault 
  (TableName, UserIdColumnName, GroupIdColumnName, Shareable, UpdateRefId)
  VALUES ('UserModules', 'UserId', NULL, 1, 1)

IF NOT EXISTS (SELECT 1 FROM IntranetSharedUserTableDefault WHERE TableName = 'AccountAuthorizations_mst')
INSERT INTO IntranetSharedUserTableDefault 
  (TableName, UserIdColumnName, GroupIdColumnName, Shareable, UpdateRefId)
  VALUES ('AccountAuthorizations_mst', 'Id', 'Id', 1, 1)
  
IF NOT EXISTS (SELECT 1 FROM IntranetSharedUserTableDefault WHERE TableName = 'UserEmail')
INSERT INTO IntranetSharedUserTableDefault 
  (TableName, UserIdColumnName, GroupIdColumnName, Shareable, UpdateRefId)
   VALUES ('UserEmail', NULL, Null, 1, 0) 

IF NOT EXISTS (SELECT 1 FROM IntranetSharedUserTableDefault WHERE TableName = 'UserPasswordHistory')
INSERT INTO IntranetSharedUserTableDefault 
  (TableName, UserIdColumnName, GroupIdColumnName, Shareable, UpdateRefId)
   VALUES ('UserPasswordHistory', NULL, Null, 1, 0) 
IF NOT EXISTS (SELECT 1 FROM IntranetSharedUserTableDefault WHERE TableName = 'UserTask')
INSERT INTO IntranetSharedUserTableDefault 
  (TableName, UserIdColumnName, GroupIdColumnName, Shareable, UpdateRefId)
  VALUES ('UserTask', 'UserId', NULL, 1, 1)
  
IF NOT EXISTS (SELECT 1 FROM IntranetSharedUserTableDefault WHERE TableName = 'UserCalendar')
INSERT INTO IntranetSharedUserTableDefault 
  (TableName, UserIdColumnName, GroupIdColumnName, Shareable, UpdateRefId)
  VALUES ('UserCalendar', 'UserId', NULL, 1, 1)

-- Non Shareable tables
IF NOT EXISTS (SELECT 1 FROM IntranetSharedUserTableDefault WHERE TableName = 'EventMessage')
INSERT INTO IntranetSharedUserTableDefault 
  (TableName, UserIdColumnName, GroupIdColumnName, Shareable, UpdateRefId)
  VALUES ('EventMessage', 'UserId', NULL, 0, 0) 
  
IF NOT EXISTS (SELECT 1 FROM IntranetSharedUserTableDefault WHERE TableName = 'SiteUserMap')
INSERT INTO IntranetSharedUserTableDefault 
  (TableName, UserIdColumnName, GroupIdColumnName, Shareable, UpdateRefId)
  VALUES ('SiteUserMap', 'UserId', NULL, 0, 0)  

IF NOT EXISTS (SELECT 1 FROM IntranetSharedUserTableDefault WHERE TableName = 'rpt_opt')
INSERT INTO IntranetSharedUserTableDefault 
  (TableName, UserIdColumnName, GroupIdColumnName, Shareable, UpdateRefId)
  VALUES ('rpt_opt', 'UserId', NULL, 0, 0)  
  
IF NOT EXISTS (SELECT 1 FROM IntranetSharedUserTableDefault WHERE TableName = 'rpt_opt_values')
INSERT INTO IntranetSharedUserTableDefault 
  (TableName, UserIdColumnName, GroupIdColumnName, Shareable, UpdateRefId)
  VALUES ('rpt_opt_values', 'UserId', NULL, 0, 0)

GO                            