/* $Header: /Tools/SQLScripts/ApplicationDB/Init Data/LanguageIds.sql 10    6/09/17 2:55p tblosser $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2015 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
*************************************************************** 
*/
/* LanguageIds */

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'ar-SA') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'ARA')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('ar-SA','ARA','Arabic (Saudi Arabia)','ArabicStrings','ar-SA','ar-SA',1025)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'bg-BG') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'BGR')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('bg-BG','BGR','Bulgarian (Bulgaria)','BulgarianStrings','bg-BG','en-US',1026)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'cs-CZ') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'CSY')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('cs-CZ','CSY','Czech (Czech Republic)','CzechStrings','cs-CZ','en-US',1029)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'da-DK') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'DAN')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('da-DK','DAN','Danish (Denmark)','DanishStrings','da-DK','en-US',1030)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'de-DE') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'DEU')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('de-DE','DEU','German (Germany)','GermanStrings','de-DE','de-DE',1031)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'en-AU') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'AUS')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('en-AU','AUS','English (Australia)','Strings','en-AU','en-US',3081)
	
IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'en-GB') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'ENG')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('en-GB','ENG','English (United Kingdom)','Strings','en-GB','en-US',2057)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'en-NZ') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'NZD')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('en-NZ','NZD','English (New Zealand)','Strings','en-NZ','en-US',5129)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'en-US') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'ENU')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('en-US','ENU','English (United States)','Strings','en-US','en-US',1033)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'es-AR') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'ESS')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('es-AR','ESS','Spanish (Argentina)','ArgentineanStrings','es-AR','es-AR',11274)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'es-CL') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'ESL')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('es-CL','ESL','Spanish (Chile)','ChileanStrings','es-CL','es-CL',13322)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'es-CO') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'ESO')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('es-CO','ESO','Spanish (Colombia)','ColombianStrings','es-CO','es-CO',9226)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'es-EC') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'ESC')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('es-EC','ESC','Spanish (Ecuador)','EcuadorianStrings','es-EC','es-EC',12298)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'es-ES') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'ESP')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('es-ES','ESP','Spanish (Spain)','SpainStrings','es-ES','es-ES',1034)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'es-MX') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'ESM')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('es-MX','ESM','Spanish (Mexico)','MexicanStrings','es-MX','es-MX',2058)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'es-VE') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'ESE')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('es-VE','ESE','Spanish (Venezuela)','VenezuelanStrings','es-VE','es-VE',8202)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'fi-FI') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'FIN')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('fi-FI','FIN','Finnish (Finland)','FinnishStrings','fi-FI','en-US',1035)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'fr-CA') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'FRC')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('fr-CA','FRC','French (Canada)','CanadianStrings','fr-CA','fr-CA',3084)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'fr-FR') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'FRA')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('fr-FR','FRA','French (France)','FrenchStrings','fr-FR','fr-FR',1036)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'he-IL') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'HEB')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('he-IL','HEB','Hebrew (Israel)','HebrewStrings','he-IL','en-US',1037)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'hi-IN') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'HIN')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('hi-IN','HIN','Hindi (India)','Strings','hi-IN','en-US',1081)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'hu-HU') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'HUN')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('hu-HU','HUN','Hungarian (Hungary)','HungarianStrings','hu-HU','en-US',1038)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'it-IT') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'ITA')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('it-IT','ITA','Italian (Italy)','ItalianStrings','it-IT','en-US',1040)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'ja-JP') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'JPN')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('ja-JP','JPN','Japanese (Japan)','JapaneseStrings','ja-JP','ja-JP',1041)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'ko-KR') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'KOR')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('ko-KR','KOR','Korean (Korea)','KoreanStrings','ko-KR','en-US',1042)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'ms-MY') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'MSL')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('ms-MY','MSL','Malay (Malaysia)','Strings','ms-MY','en-US',1086)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'nb-NO') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'NOR')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('nb-NO','NOR','Norwegian, Bokmal (Norway)','NorwegianStrings','nb-NO','en-US',1044)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'nl-NL') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'NLD')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('nl-NL','NLD','Dutch (Netherlands)','DutchStrings','nl-NL','en-US',1043)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'pl-PL') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'PLK')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('pl-PL','PLK','Polish (Poland)','PolishStrings','pl-PL','en-US',1045)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'pt-BR') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'PTB')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('pt-BR','PTB','Portuguese (Brazil)','BrazilianStrings','pt-BR','en-US',1046)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'pt-PT') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'PTG')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('pt-PT','PTG','Portuguese (Portugal)','PortugalStrings','pt-PT','en-US',2070)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'ro-RO') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'ROM')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('ro-RO','ROM','Romanian (Romania)','RomanianStrings','ro-RO','ro-RO',1048)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'ru-RU') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'RUS')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('ru-RU','RUS','Russian (Russia)','RussianStrings','ru-RU','en-US',1049)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'sl-SI') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'SLV')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('sl-SI','SLV','Slovenian (Slovenia)','SlovenianStrings','sl-SI','en-US',1060)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'sk-SK') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'SVK')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('sk-SK','SVK','Slovak (Slovakia)','SlovakStrings','sk-SK','en-US',1051)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'sv-SE') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'SVE')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('sv-SE','SVE','Swedish (Sweden)','SwedishStrings','sv-SE','en-US',1053)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'th-TH') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'THA')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('th-TH','THA','Thai (Thailand)','ThaiStrings','th-TH','en-US',1054)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'tr-TR') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'TRK')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('tr-TR','TRK','Turkish (Turkey)','TurkishStrings','tr-TR','en-US',1055)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'vi-VN') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'VNM')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('vi-VN','VNM','Vietnamese (Vietnam)','VietnameseStrings','vi-VN','en-US',1066)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'zh-CN') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'CHS')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('zh-CN','CHS','Chinese (People''s Republic of China)','SimplifiedChineseStrings','zh-CN','zh-CN',2052)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'zh-SG') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'ZHI')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('zh-SG','ZHI','Chinese (Singapore)','Strings','zh-SG','zh-SG',4100)

IF NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageID = 'zh-TW') AND NOT EXISTS (SELECT 1 FROM LanguageIds WHERE LanguageCode = 'CHT')
	INSERT LanguageIds (LanguageID, LanguageCode, LanguageDesc, StringTableName, LanguageSubdir, HelpSubdir, LocaleID) VALUES('zh-TW','CHT','Chinese (Taiwan)','TraditionalChineseStrings','zh-TW','zh-TW',1028)

UPDATE dbo.LanguageIDs
SET OverrideMidHelpURL = 'en-us';

GO
