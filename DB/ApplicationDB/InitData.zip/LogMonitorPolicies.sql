/* $Header: /Tools/SQLScripts/ApplicationDB/Init Data/LogMonitorPolicies.sql 2     3/08/10 9:08a Dahn $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2020 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
*************************************************************** 
*/
/* LogMonitorPolicies */
IF NOT EXISTS (SELECT 1 FROM LogMonitorPolicies)
INSERT INTO LogMonitorPolicies (PolicyId, LogTypeFilter, LogRetentionDays, LogUntilDateTime)
VALUES (1,'Audit|Error|General|Performance|Security|SQL|Trace|UserDefined0|UserDefined1|UserDefined2|UserDefined3', 30, DATEADD(MINUTE, 30, SYSDATETIME()))
GO
