/* $Header: /Tools/SQLScripts/ApplicationDB/Init Data/EventTrigger.sql 4     5/02/13 12:37p Ltaylor2 $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
*************************************************************** 
*/
IF NOT EXISTS (SELECT 1
  FROM EventTrigger
  WHERE EventTriggerId = 'BE21ABA2-AC91-45CE-B3C2-4DFA85E644B9')
INSERT INTO EventTrigger (EventName, EventTriggerId, AccessAs, RequestedBy, ConfigurationName, Active, Condition, FailureRetestInterval, SuccessRetestInterval, Transactional)
VALUES (N'TaskListCheck', 'BE21ABA2-AC91-45CE-B3C2-4DFA85E644B9', N'Core', N'sa', NULL, 1, 'CONDITION(TRUE)', 60, 60, 1)
GO

IF NOT EXISTS (SELECT 1
  FROM EventTrigger
  WHERE EventTriggerId = 'B8429D4E-E3D1-4F97-83F7-5470CB829C5E')
INSERT INTO EventTrigger (EventName, EventTriggerId, AccessAs, RequestedBy, ConfigurationName, Active, Condition, FailureRetestInterval, SuccessRetestInterval, Transactional)
VALUES (N'ClearServiceSessions', 'B8429D4E-E3D1-4F97-83F7-5470CB829C5E', N'Core', N'sa', NULL, 1, 'CONDITION(TRUE)', 1800, 86400, 1)
GO

-- PurgeHistoryData Event State
DECLARE @EventTriggerId uniqueidentifier
SET @EventTriggerId = 'FF58ED59-61D3-481F-A50E-71362931D280'
DECLARE @ETRP RowPointerType
SET @ETRP = NEWID()

--delete old data that was created using @EventTriggerId 'FF58ED59-61D3-481F-A50E-71362931D280'
DELETE FROM EventTrigger where RowPointer =@EventTriggerId 
		 
IF NOT EXISTS (SELECT 1
  FROM EventTrigger
  WHERE EventTriggerId = @EventTriggerId)
INSERT INTO EventTrigger (EventName, EventTriggerId, RowPointer, AccessAs, RequestedBy, ConfigurationName, Active, Condition, FailureRetestInterval, SuccessRetestInterval, Transactional)
VALUES (N'PurgeHistoryData', @EventTriggerId, @ETRP, N'Core', N'sa', NULL, 0, 'CONDITION(TRUE)', 86400, 86400, 1)
ELSE
	SELECT @ETRP = RowPointer FROM EventTrigger WHERE EventTriggerId = @EventTriggerId 

--delete old data that was created using @EventTriggerId 'FF58ED59-61D3-481F-A50E-71362931D280'
DELETE FROM EventTriggerParameter where EventTriggerRowPointer =@EventTriggerId 
		
--Event parameters PurgeDBMethodToCall
IF NOT EXISTS (SELECT 1
  FROM EventTriggerParameter
  WHERE EventTriggerRowPointer = @ETRP AND [Name] = N'PurgeDBMethodToCall')
INSERT INTO EventTriggerParameter (EventTriggerRowPointer, [Name], [Value], NoteExistsFlag )
VALUES (@ETRP, N'PurgeDBMethodToCall', N'PurgeEventDataSp', 0)
 
--Event parameters DaysOld
IF NOT EXISTS (SELECT 1
  FROM EventTriggerParameter
  WHERE EventTriggerRowPointer = @ETRP AND [Name] = N'DaysOld')
INSERT INTO EventTriggerParameter (EventTriggerRowPointer, [Name], [Value], NoteExistsFlag )
VALUES (@ETRP, N'DaysOld', N'30', 0)

GO
