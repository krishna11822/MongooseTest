/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2019 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
*************************************************************** 
*/
/* DefaultTypes */
-- =============================================================================================
--  Default Type:
--    19:   Non-unicode literal
--    20:   Report output obfuscation
--    21:   Objects metadata linkage
--    23:   IDO checkout disabled
--    24:   Keep successful event states
--    26:   Persist Winstudio metadata cache
--    30:   Collection read mode
--    31:   Report paper size
--    34:   TaskMan options
--    35:   Enable audit logging
--    36:   WinStudio max record cap
--    38:   Client minutes to ping session
--    39:   Minutes to close orphan sessions
--    40:   Default script language (when not specified, it is Visual Basic)
--    41:   Allow script language selection
--    42:   NUMSORTCHAR numeric pad  (Pad(x) - where x is pad character. Default: Pad(0))
--    43:   ION pulse interface.
--    44:   Asterisk as required indicator
--    45:   Disable record cap override save
--    46:   Logical IDs aliased in BOD.
--    47:   User inactivity threshold.
--    48:   Allow saving form runtime changes
--    49:   Browser inactivity lock minutes
--    50:   Enforce prefix from Access As
--    51:   Service AES Originator
--    52:   Remote WinStudio Sessions (Allow, Deny, Per User)
--    52:   Remote WinStudio Sessions (Allow, Deny, Per User)
--    54:   Send Context Message on Form Focus
--    55:   Optional Context Message Form Prefix
--    56:   Filter validation (Low, Medium, High)
--    57:   Admin License Module Name
--    58:   Prune Explorer Folder Callout
--    59:   Browser Component Background Render Interval
--    60:   Framework Event Maximum Recursion Depth
--    61:   Disallow Underdefined AES Handlers
--    62:   FormSync notifications email address
--    63:   Round Robin Polling Interval (In Milliseconds)
--    64:   No delete Group on SecurityUserMaster BOD (null/0 = delete all groups for this user)
--    65:   No delete Module on SecurityUserMaster BOD (null/0 = delete all modules for this user)
--    66:   Round Robin Batch Size
--    67:   Enable Remote Logging
--    68:   DateTime in Client Time Zone
--    69:   Report max record cap
--    70:   MG Version
--    71:   Datalake prefix
--    72:   TaskMan CLM Exclusive Work Time Threshold ("Unprocessed Task Timeout (ms)")
--    73:   Ignore LogicalID in SUM Security Role
--    74:   Outbound SecurityUserMaster and SecurityRoleMaster Role LID Override
--    75:   Inbound SecurityUserMaster Assign Admin License (reference number 57)
--    76:   Enable Inbound BOD Prioritization
--    77:   REST Token Lifetime (sec)
--    78:   Conditional actions case sensitive
--    79 :  Component Name as HTML Attribute
--    80:   Report Batch Size
--    81:   Check for New Message Interval
--    82:   Use AES Intranet's from email
-- =============================================================================================

IF NOT EXISTS (SELECT 1 FROM DefaultTypes WHERE DefaultType = 19)
insert into DefaultTypes (DefaultType, DefaultTypeDesc, AllowUserDfltFlag, DefaultRegEx)
values (19, N'Non unicode literal', 0, '^(?:Default|Ansi|Smart)$')

if NOT EXISTS(SELECT 1 from DefaultTypes where DefaultType = 20)
insert into DefaultTypes (DefaultType, DefaultTypeDesc, AllowUserDfltFlag, NoteExistsFlag, DefaultRegEx)
values (20, 'Report output obfuscation', 0, 0, '^(?:0|1)$')

if NOT EXISTS(SELECT 1 from DefaultTypes where DefaultType = 21)
insert into DefaultTypes (DefaultType, DefaultTypeDesc, AllowUserDfltFlag, NoteExistsFlag)
values (21, 'Objects metadata linkage', 0, 0)

if NOT EXISTS(SELECT 1 from DefaultTypes where DefaultType = 23)
insert into DefaultTypes (DefaultType, DefaultTypeDesc, AllowUserDfltFlag, NoteExistsFlag, DefaultRegEx)
values (23, 'IDO checkout disabled', 0, 0, '^(?:0|1)$')

IF NOT EXISTS(SELECT 1 from DefaultTypes where DefaultType = 24)
insert into DefaultTypes (DefaultType, DefaultTypeDesc, AllowUserDfltFlag, NoteExistsFlag, DefaultRegEx)
values (24, 'Keep successful event states', 0, 0, '^(?:0|1)$')

if NOT EXISTS(SELECT 1 from DefaultTypes where DefaultType = 26)
insert into DefaultTypes (DefaultType, DefaultTypeDesc, AllowUserDfltFlag, NoteExistsFlag, DefaultRegEx)
values (26, 'Persist WinStudio metadata cache', 0, 0, '^(?:0|1)$')

if NOT EXISTS(SELECT 1 from DefaultTypes where DefaultType = 30)
insert into DefaultTypes (DefaultType, DefaultTypeDesc, AllowUserDfltFlag, NoteExistsFlag, DefaultRegEx)
values (30, 'Collection read mode', 0, 0, '^(?:COMMITTED|UNCOMMITTED)$')

if NOT EXISTS(SELECT 1 from DefaultTypes where DefaultType = 31)
insert into DefaultTypes (DefaultType, DefaultTypeDesc, AllowUserDfltFlag, NoteExistsFlag, DefaultRegEx)
values (31, 'Report paper size', 0, 0, '^[^\^\$\+\=\<\>\`\~]+$')

if NOT EXISTS(SELECT 1 from DefaultTypes where DefaultType = 34)
insert into DefaultTypes (DefaultType, DefaultTypeDesc, AllowUserDfltFlag, NoteExistsFlag)
values (34,'TaskMan options', 0, 0)

if NOT EXISTS(SELECT 1 from DefaultTypes where DefaultType = 35)
insert into DefaultTypes (DefaultType, DefaultTypeDesc, AllowUserDfltFlag, NoteExistsFlag, DefaultRegEx)
values (35,'Enable audit logging', 0, 0, '^(?:0|1)$')

if NOT EXISTS(SELECT 1 from DefaultTypes where DefaultType = 36)
insert into DefaultTypes (DefaultType, DefaultTypeDesc, AllowUserDfltFlag, NoteExistsFlag, DefaultRegEx)
values (36,'User Preferences Max Record Cap', 0, 0, '^[0-9]+$')

if NOT EXISTS(SELECT 1 from DefaultTypes where DefaultType = 38)
insert into DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (38, N'Client minutes to ping session', '^[0-9]+$')

if NOT EXISTS(SELECT 1 from DefaultTypes where DefaultType = 39)
insert into DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (39, N'Minutes to close orphan sessions', '^[0-9]+$')

if NOT EXISTS(SELECT 1 from DefaultTypes where DefaultType = 40)
insert into DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (40, N'Default script language', '^(?:Visual Basic|Visual C#)$')

if NOT EXISTS(SELECT 1 from DefaultTypes where DefaultType = 41)
insert into DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (41, N'Allow script language selection', '^(?:0|1)$')

if NOT EXISTS(SELECT 1 from DefaultTypes where DefaultType = 42)
insert into DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (42, N'NUMSORTCHAR numeric pad', '^[^\^\$\+\=\<\>\`\~]+$')

if NOT EXISTS(SELECT 1 from DefaultTypes where DefaultType = 43)
insert into DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (43, N'ION pulse interface', '^(?:0|1)$')

if NOT EXISTS(SELECT 1 from DefaultTypes where DefaultType = 44)
insert into DefaultTypes (DefaultType, DefaultTypeDesc) VALUES (44, N'Asterisk as required indicator')

if NOT EXISTS(SELECT 1 from DefaultTypes where DefaultType = 45)
insert into DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (45, N'Save record cap override', '^(?:0|1)$')

if NOT EXISTS(SELECT 1 from DefaultTypes where DefaultType = 46)
insert into DefaultTypes (DefaultType, DefaultTypeDesc) VALUES (46, N'Logical IDs aliased in BOD')

if NOT EXISTS(SELECT 1 from DefaultTypes where DefaultType = 47)
insert into DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (47, N'User inactivity threshold', '^[0-9]+$')

if NOT EXISTS(SELECT 1 from DefaultTypes where DefaultType = 48)
insert into DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (48, N'Allow saving form runtime changes', '^(?:0|1)$')

if NOT EXISTS(SELECT 1 from DefaultTypes where DefaultType = 49)
insert into DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (49, N'Browser inactivity lock minutes', '^[0-9]+$')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 50)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (50, N'Enforce prefix from Access As', '^(?:0|1)$')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 51)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc) VALUES (51, N'Service AES Originator')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 52)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (52, N'Remote WinStudio Sessions', '^(?:Allow|Deny|PerUser)$')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 53)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc) VALUES (53, N'Site Reference Column Name')

if NOT EXISTS(SELECT 1 from DefaultTypes where DefaultType = 54)
insert into DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (54, N'Send Context Message on Form Focus', '^(?:0|1)$')

if NOT EXISTS(SELECT 1 from DefaultTypes where DefaultType = 55)
insert into DefaultTypes (DefaultType, DefaultTypeDesc) VALUES (55, N'Optional Context Message Form Prefix')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 56)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (56, N'Filter validation', '^(?:High|Medium|Low)$')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 57)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (57, N'Admin License Module Name', '^[^\^\$\+\=\<\>\`\~]+$')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 58)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (58, N'Prune Explorer Folder Callout', '^[^\^\$\+\=\<\>\`\~]+$')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 59)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (59, N'Browser Component BG Render Interval', '^(?:0|1)$')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 60)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc) VALUES (60, N'Framework Event Max. Recursion Depth')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 61)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc) VALUES (61, N'Disallow Underdefined AES Handlers')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 62)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (62, N'FormSync notifications email address', '^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 63)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (63, N'Round Robin Polling Interval (ms)', '^[0-9]+$')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 64)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (64, N'Keep Groups in SecurityUserMaster', '^(?:0|1)$')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 65)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (65, N'Keep Modules in SecurityUserMaster', '^(?:0|1)$')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 66)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (66, N'Round Robin Batch Size', '^[0-9]+$')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 67)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (67, N'Enable Remote Logging', '^(?:0|1)$')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 68)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (68, N'DateTime in Client Time Zone', '^(?:0|1)$')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 69)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (69, N'Report max record cap', '^[0-9]+$')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 70)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc) VALUES (70, N'MG Version')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 71)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (71, N'Datalake Prefix', '^[^\^\$\+\=\<\>\`\~]+$')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 72)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc) VALUES (72, N'Unprocessed Task Timeout (ms)')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 73)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (73, N'Ignore LogicalID in SUM SecurityRole', '^(?:0|1)$')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 74)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc) VALUES (74, N'Outbound SUM Role LID Override')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 75)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (75, N'Inbound SUM Assign Admin License', '^(?:0|1)$')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 76)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (76, N'Enable Inbound BOD Prioritization', '^(?:0|1)$')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 77)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (77, N'REST Token Lifetime (sec)', '^[0-9]+$')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 78)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (78, N'Conditional actions case sensitive', '^(?:0|1)$')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 79)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (79, N'Component Name as HTML Attribute', '^(?:0|1|2|3)$')


IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 80)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc) VALUES (80, N'Report Batch Size')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 81)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (81, N'Check for New Message Interval', '^[1-9]+[0-9]*$')

IF NOT EXISTS(SELECT 1 FROM DefaultTypes WHERE DefaultType = 82)
INSERT INTO DefaultTypes (DefaultType, DefaultTypeDesc, DefaultRegEx) VALUES (82, N'Use AES Intranet''s from email', '^(?:0|1)$')
-- =============================================================================================
--  SystemProcessDefaults:
-- =============================================================================================

if NOT EXISTS(SELECT 1 from SystemProcessDefaults where DefaultType = 30)
insert into SystemProcessDefaults (DefaultType, DefaultValue, NoteExistsFlag, InWorkflow)
values (30, 'UNCOMMITTED', 0, 0 )

if NOT EXISTS(SELECT 1 from SystemProcessDefaults where DefaultType = 31)
insert into SystemProcessDefaults (DefaultType, DefaultValue, NoteExistsFlag, InWorkflow)
values (31, 'DEFAULT', 0, 0 )

if NOT EXISTS(SELECT 1 from SystemProcessDefaults where DefaultType = 35)
INSERT SystemProcessDefaults(DefaultType,DefaultValue, NoteExistsFlag, InWorkflow )
VALUES(35,'0', 0, 0)

IF NOT EXISTS(SELECT 1 FROM SystemProcessDefaults WHERE DefaultType = 51)
INSERT SystemProcessDefaults(DefaultType,DefaultValue, NoteExistsFlag, InWorkflow )
VALUES (51,'sa', 0, 0)

IF NOT EXISTS(SELECT 1 FROM SystemProcessDefaults WHERE DefaultType = 53)
INSERT SystemProcessDefaults(DefaultType,DefaultValue, NoteExistsFlag, InWorkflow )
VALUES (53,'SiteRef', 0, 0)

IF NOT EXISTS(SELECT 1 FROM SystemProcessDefaults WHERE DefaultType = 54)
INSERT SystemProcessDefaults(DefaultType,DefaultValue, NoteExistsFlag, InWorkflow )
VALUES (54,'1', 0, 0)

IF NOT EXISTS(SELECT 1 FROM SystemProcessDefaults WHERE DefaultType = 55)
INSERT SystemProcessDefaults(DefaultType,DefaultValue, NoteExistsFlag, InWorkflow )
VALUES (55,'mongoose_', 0, 0)
ELSE IF EXISTS(SELECT 1 FROM SystemProcessDefaults WHERE DefaultType = 55 AND (DefaultValue = 'MGCore_' OR DefaultValue = 'mongoose') )
UPDATE SystemProcessDefaults
SET DefaultValue = 'mongoose_'
WHERE DefaultType = 55 AND (DefaultValue = 'MGCore_' OR DefaultValue = 'mongoose')

IF NOT EXISTS(SELECT 1 FROM SystemProcessDefaults WHERE DefaultType = 57)
INSERT SystemProcessDefaults(DefaultType,DefaultValue, NoteExistsFlag, InWorkflow )
VALUES (57,'MGCoreTrans', 0, 0)

-- Default report max record cap from winstudio max record cap if it is set
IF NOT EXISTS(SELECT 1 FROM SystemProcessDefaults WHERE DefaultType = 69)
AND EXISTS (SELECT 1 FROM SystemProcessDefaults WHERE DefaultType = 36)
INSERT INTO SystemProcessDefaults(DefaultType, DefaultValue, NoteExistsFlag, InWorkflow )
SELECT 69, DefaultValue, 0, 0
FROM SystemProcessDefaults
WHERE DefaultType = 36

IF NOT EXISTS(SELECT 1 FROM SystemProcessDefaults WHERE DefaultType = 71)
INSERT SystemProcessDefaults(DefaultType,DefaultValue, NoteExistsFlag, InWorkflow )
VALUES (71,'Mongoose', 0, 0)

IF NOT EXISTS(SELECT 1 FROM SystemProcessDefaults WHERE DefaultType = 73)
INSERT SystemProcessDefaults(DefaultType,DefaultValue, NoteExistsFlag, InWorkflow )
VALUES (73,'0', 0, 0)

IF NOT EXISTS(SELECT 1 FROM SystemProcessDefaults WHERE DefaultType = 75)
INSERT SystemProcessDefaults(DefaultType,DefaultValue, NoteExistsFlag, InWorkflow )
VALUES (75,'1', 0, 0)

GO