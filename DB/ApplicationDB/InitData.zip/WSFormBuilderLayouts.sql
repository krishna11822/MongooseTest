
IF EXISTS (SELECT 1 FROM WSFormBuilderLayouts WHERE LayoutName = 'Graph' AND FormType = 'Widget')
DELETE FROM WSFormBuilderLayouts WHERE LayoutName = 'Graph' AND FormType = 'Widget'

INSERT INTO WSFormBuilderLayouts (
LayoutName
,FormType
,Description
,FormName
,MasterFormName
,NumberOfProperties
,Sequence
,HasTileFlag
,TileHasImageFlag
,TileFormName
,TileMasterFormName
,AccessAs
,ImageName
,LayoutType
,MaxNumberOfCards
) VALUES (
'Graph'
,'Widget'
,'mFormBuilder_Graph'  -----Graph data using FusionCharts
,'WSFormBuilderGraph'
,'WSFormBuilderGraphTemplate'
,2
,1
,0
,0
,NULL
,NULL
,'Core'
,'fb_widget_graph.svg'
,0,
NULL
)
GO

IF EXISTS (SELECT 1 FROM WSFormBuilderLayouts WHERE LayoutName = 'List' AND FormType = 'Widget')
DELETE FROM WSFormBuilderLayouts WHERE LayoutName = 'List' AND FormType = 'Widget'

INSERT INTO WSFormBuilderLayouts (
LayoutName
,FormType
,Description
,FormName
,MasterFormName
,NumberOfProperties
,Sequence
,HasTileFlag
,TileHasImageFlag
,TileFormName
,TileMasterFormName
,AccessAs
,ImageName
,LayoutType
,MaxNumberOfCards
) VALUES (
'List'
,'Widget'
,'mWidgetList'  -----Lists data vertically in a list
,'WSFormBuilderList'
,'WSFormBuilderListTemplate'
,2
,2
,1
,0
,'WSFormBuilderListTile'
,'WSFormBuilderListTileTemplate'
,'Core'
,'fb_widget_list.svg'
,0
,NULL
)
GO

IF EXISTS (SELECT 1 FROM WSFormBuilderLayouts WHERE LayoutName = 'ListWithIcons' AND FormType = 'Widget')
DELETE FROM WSFormBuilderLayouts WHERE LayoutName = 'ListWithIcons' AND FormType = 'Widget'

INSERT INTO WSFormBuilderLayouts (
LayoutName
,FormType
,Description
,FormName
,MasterFormName
,NumberOfProperties
,Sequence
,HasTileFlag
,TileHasImageFlag
,TileFormName
,TileMasterFormName
,AccessAs
,ImageName
,LayoutType
,MaxNumberOfCards
) VALUES (
'ListWithIcons'
,'Widget'
,'mFormBuilder_ListWithIcons'  -----List data vertically in a list along with the image alligned on tile
,'WSFormBuilderListWithIcons'
,'WSFormBuilderListWithIconsTemplate'
,3
,3
,1
,1
,'WSFormBuilderListWithIconsTile'
,'WSFormBuilderListWithIconsTileTemplate'
,'Core'
,'fb_widget_listwithicons.svg'
,0
,NULL
)
GO

IF EXISTS (SELECT 1 FROM WSFormBuilderLayouts WHERE LayoutName = 'WidgetInput' AND FormType = 'Widget')
DELETE FROM WSFormBuilderLayouts WHERE LayoutName = 'WidgetInput' AND FormType = 'Widget'

INSERT INTO WSFormBuilderLayouts (
LayoutName
,FormType
,Description
,FormName
,MasterFormName
,NumberOfProperties
,Sequence
,HasTileFlag
,TileHasImageFlag
,TileFormName
,TileMasterFormName
,AccessAs
,ImageName
,LayoutType
,MaxNumberOfCards
) VALUES (
'WidgetInput'
,'Widget'
,'mFormBuilder_WidgetInput'  -----5-Fields to add data to a collection
,'WSFormBuilderWidgetInput'
,'WSFormBuilderWidgetInputTemplate'
,5
,4
,0
,0
,NULL
,NULL
,'Core'
,'fb_widget_widgetinput.svg'
,0
,NULL
)
GO

IF EXISTS (SELECT 1 FROM WSFormBuilderLayouts WHERE LayoutName = 'Responsive' AND FormType = 'FullForm')
DELETE FROM WSFormBuilderLayouts WHERE LayoutName = 'Responsive' AND FormType = 'FullForm'

INSERT INTO WSFormBuilderLayouts (
LayoutName
,FormType
,Description
,FormName
,MasterFormName
,NumberOfProperties
,Sequence
,HasTileFlag
,TileHasImageFlag
,TileFormName
,TileMasterFormName
,AccessAs
,ImageName
,LayoutType
,MaxNumberOfCards
) VALUES (
'Responsive'
,'FullForm'
,'mFormBuilder_Responsive'  -----Form with 10 Fields to add and view data of a collection
,'WSFormBuilderResponsive'
,'WSFormBuilderResponsiveTemplate'
,10
,1
,0
,0
,NULL
,NULL
,'Core'
,'fb_fullform_responsive.svg'
,0
,NULL
)
GO

IF EXISTS (SELECT 1 FROM WSFormBuilderLayouts WHERE LayoutName = 'FormWithGrid' AND FormType = 'FullForm')
DELETE FROM WSFormBuilderLayouts WHERE LayoutName = 'FormWithGrid' AND FormType = 'FullForm'

INSERT INTO WSFormBuilderLayouts (
LayoutName
,FormType
,Description
,FormName
,MasterFormName
,NumberOfProperties
,Sequence
,HasTileFlag
,TileHasImageFlag
,TileFormName
,TileMasterFormName
,AccessAs
,ImageName
,LayoutType
,MaxNumberOfCards
) VALUES (
'FormWithGrid'
,'FullForm'
,'mFormBuilder_FormWithGrid'  -----Form with 20 Fields to add and navigate through data from a grid of a collection
,'WSFormBuilderFormWithGrid'
,'WSFormBuilderFormWithGridTemplate'
,20
,1
,1
,0
,'WSFormBuilderFormWithGridTile'
,'WSFormBuilderFormWithGridTileTemplate'
,'Core'
,'fb_fullform_formwithgrid.svg'
,0
,NULL
)
GO


-----------------------------------------RS9122 - Form Builder Wizard Phase 2-----------------------------------------
--Widget--
 
IF EXISTS (SELECT 1 FROM WSFormBuilderLayouts WHERE LayoutName = 'Grid' AND FormType = 'Widget')
DELETE FROM WSFormBuilderLayouts WHERE LayoutName = 'Grid' AND FormType = 'Widget'

INSERT INTO WSFormBuilderLayouts (
LayoutName
,FormType
,Description
,FormName
,MasterFormName
,NumberOfProperties
,Sequence
,HasTileFlag
,TileHasImageFlag
,TileFormName
,TileMasterFormName
,AccessAs
,ImageName
,LayoutType
,MaxNumberOfCards
) VALUES (
'Grid'
,'Widget'
,'mWidgetGrid'
,'WSFormBuilderTemplateWidgetGrid'
,'WSFormBuilderTemplateWidgetGrid'
,2
,3
,0
,0
,NULL
,NULL
,'Core'
,'FB_WidGrid.png'
,0
,NULL
)
GO

IF EXISTS (SELECT 1 FROM WSFormBuilderLayouts WHERE LayoutName = 'Grid with Header' AND FormType = 'Widget')
DELETE FROM WSFormBuilderLayouts WHERE LayoutName = 'Grid with Header' AND FormType = 'Widget'

INSERT INTO WSFormBuilderLayouts (
LayoutName
,FormType
,Description
,FormName
,MasterFormName
,NumberOfProperties
,Sequence
,HasTileFlag
,TileHasImageFlag
,TileFormName
,TileMasterFormName
,AccessAs
,ImageName
,LayoutType
,MaxNumberOfCards
) VALUES (
'Grid with Header'
,'Widget'
,'mWidgetGridHeader'
,'WSFormBuilderTemplateWidgetGridHeader'
,'WSFormBuilderTemplateWidgetGridHeader'
,2
,5
,0
,0
,NULL
,NULL
,'Core'
,'FB_WidGridHeader.png'
,0
,NULL
)
GO

IF EXISTS (SELECT 1 FROM WSFormBuilderLayouts WHERE LayoutName = 'Grid with Header and Actions' AND FormType = 'Widget')
DELETE FROM WSFormBuilderLayouts WHERE LayoutName = 'Grid with Header and Actions' AND FormType = 'Widget'

INSERT INTO WSFormBuilderLayouts (
LayoutName
,FormType
,Description
,FormName
,MasterFormName
,NumberOfProperties
,Sequence
,HasTileFlag
,TileHasImageFlag
,TileFormName
,TileMasterFormName
,AccessAs
,ImageName
,LayoutType
,MaxNumberOfCards
) VALUES (
'Grid with Header and Actions'
,'Widget'
,'mWidgetGridHeaderActions'
,'WSFormBuilderTemplateWidgetGridHeaderActions'
,'WSFormBuilderTemplateWidgetGridHeaderActions'
,2
,6
,0
,0
,NULL
,NULL
,'Core'
,'FB_WidGridHeaderAct.png'
,0
,NULL
)
GO

IF EXISTS (SELECT 1 FROM WSFormBuilderLayouts WHERE LayoutName = 'Grid with Search' AND FormType = 'Widget')
DELETE FROM WSFormBuilderLayouts WHERE LayoutName = 'Grid with Search' AND FormType = 'Widget'

INSERT INTO WSFormBuilderLayouts (
LayoutName
,FormType
,Description
,FormName
,MasterFormName
,NumberOfProperties
,Sequence
,HasTileFlag
,TileHasImageFlag
,TileFormName
,TileMasterFormName
,AccessAs
,ImageName
,LayoutType
,MaxNumberOfCards
) VALUES (
'Grid with Search'
,'Widget'
,'mWidgetGridSearch'
,'WSFormBuilderTemplateWidgetGridSearch'
,'WSFormBuilderTemplateWidgetGridSearch'
,2
,4
,0
,0
,NULL
,NULL
,'Core'
,'FB_WidGridSearch.png'
,0
,NULL
)
GO

IF EXISTS (SELECT 1 FROM WSFormBuilderLayouts WHERE LayoutName = 'List v2' AND FormType = 'Widget')
DELETE FROM WSFormBuilderLayouts WHERE LayoutName = 'List V2' AND FormType = 'Widget'

INSERT INTO WSFormBuilderLayouts (
LayoutName
,FormType
,Description
,FormName
,MasterFormName
,NumberOfProperties
,Sequence
,HasTileFlag
,TileHasImageFlag
,TileFormName
,TileMasterFormName
,AccessAs
,ImageName
,LayoutType
,MaxNumberOfCards
) VALUES (
'List v2'
,'Widget'
,'mWidgetList'
,'WSFormBuilderTemplateWidgetList'
,'WSFormBuilderTemplateWidgetList'
,2
,1
,1
,0
,'WSFormBuilderWidListTileTemplate'
,'WSFormBuilderWidListTileTemplate'
,'Core'
,'FB_WidList.png'
,0
,NULL
)
GO

IF EXISTS (SELECT 1 FROM WSFormBuilderLayouts WHERE LayoutName = 'List with Icons' AND FormType = 'Widget')
DELETE FROM WSFormBuilderLayouts WHERE LayoutName = 'List with Icons' AND FormType = 'Widget'

INSERT INTO WSFormBuilderLayouts (
LayoutName
,FormType
,Description
,FormName
,MasterFormName
,NumberOfProperties
,Sequence
,HasTileFlag
,TileHasImageFlag
,TileFormName
,TileMasterFormName
,AccessAs
,ImageName
,LayoutType
,MaxNumberOfCards
) VALUES (
'List with Icons'
,'Widget'
,'mWidgetListIcons'
,'WSFormBuilderTemplateWidgetListIcon'
,'WSFormBuilderTemplateWidgetListIcon'
,3
,2
,1
,1
,'WSFormBuilderTemplateWidgetListIconTile'
,'WSFormBuilderTemplateWidgetListIconTile'
,'Core'
,'FB_WidListIcon.png'
,0
,NULL
)
GO

IF EXISTS (SELECT 1 FROM WSFormBuilderLayouts WHERE LayoutName = 'Non-Data Menu with Actions' AND FormType = 'Non-Data')
DELETE FROM WSFormBuilderLayouts WHERE LayoutName = 'Non-Data Menu with Actions' AND FormType = 'Non-Data'

INSERT INTO WSFormBuilderLayouts (
LayoutName
,FormType
,Description
,FormName
,MasterFormName
,NumberOfProperties
,Sequence
,HasTileFlag
,TileHasImageFlag
,TileFormName
,TileMasterFormName
,AccessAs
,ImageName
,LayoutType
,MaxNumberOfCards
) VALUES (
'Non-Data Menu with Actions'
,'Non-Data'
,'mNonDataMenuActions'
,'WSFormBuilderTemplateNonDataMenu'
,'WSFormBuilderTemplateNonDataMenu'
,0
,2
,0
,0
,NULL
,NULL
,'Core'
,'FB_NonDataMenuAct.png'
,0
,NULL
)
GO

IF EXISTS (SELECT 1 FROM WSFormBuilderLayouts WHERE LayoutName = 'Responsive v2' AND FormType = 'FullForm')
DELETE FROM WSFormBuilderLayouts WHERE LayoutName = 'Responsive v2' AND FormType = 'FullForm'

INSERT INTO WSFormBuilderLayouts (
LayoutName
,FormType
,Description
,FormName
,MasterFormName
,NumberOfProperties
,Sequence
,HasTileFlag
,TileHasImageFlag
,TileFormName
,TileMasterFormName
,AccessAs
,ImageName
,LayoutType
,MaxNumberOfCards
) VALUES (
'Responsive v2'
,'FullForm'
,'mResponsive'
,'WSFormBuilderTemplateResponsive'
,'WSFormBuilderTemplateResponsive'
,20
,4
,0
,0
,NULL
,NULL
,'Core'
,'FB_Responsive.png'
,0
,NULL
)
GO

IF EXISTS (SELECT 1 FROM WSFormBuilderLayouts WHERE LayoutName = 'Responsive with Navigation' AND FormType = 'FullForm')
DELETE FROM WSFormBuilderLayouts WHERE LayoutName = 'Responsive with Navigation' AND FormType = 'FullForm'

INSERT INTO WSFormBuilderLayouts (
LayoutName
,FormType
,Description
,FormName
,MasterFormName
,NumberOfProperties
,Sequence
,HasTileFlag
,TileHasImageFlag
,TileFormName
,TileMasterFormName
,AccessAs
,ImageName
,LayoutType
,MaxNumberOfCards
) VALUES (
'Responsive with Navigation'
,'FullForm'
,'mResponsiveNav'
,'WSFormBuilderTemplateResponsiveNav'
,'WSFormBuilderTemplateResponsiveNav'
,20
,5
,0
,0
,NULL
,NULL
,'Core'
,'FB_ResponsiveNav.png'
,0
,NULL
)
GO

IF EXISTS (SELECT 1 FROM WSFormBuilderLayouts WHERE LayoutName = 'Responsive with Navigation and Menu' AND FormType = 'FullForm')
DELETE FROM WSFormBuilderLayouts WHERE LayoutName = 'Responsive with Navigation and Menu' AND FormType = 'FullForm'

INSERT INTO WSFormBuilderLayouts (
LayoutName
,FormType
,Description
,FormName
,MasterFormName
,NumberOfProperties
,Sequence
,HasTileFlag
,TileHasImageFlag
,TileFormName
,TileMasterFormName
,AccessAs
,ImageName
,LayoutType
,MaxNumberOfCards
) VALUES (
'Responsive with Navigation and Menu'
,'FullForm'
,'mResponsiveNavMenuActions'
,'WSFormBuilderTemplateResponsiveNavMenu'
,'WSFormBuilderTemplateResponsiveNavMenu'
,20
,7
,0
,0
,NULL
,NULL
,'Core'
,'FB_ResponsiveNavMenu.png'
,0
,NULL
)
GO

IF EXISTS (SELECT 1 FROM WSFormBuilderLayouts WHERE LayoutName = 'Responsive with Navigation, Menu and Subcollection' AND FormType = 'FullForm')
DELETE FROM WSFormBuilderLayouts WHERE LayoutName = 'Responsive with Navigation, Menu and Subcollection' AND FormType = 'FullForm'

INSERT INTO WSFormBuilderLayouts (
LayoutName
,FormType
,Description
,FormName
,MasterFormName
,NumberOfProperties
,Sequence
,HasTileFlag
,TileHasImageFlag
,TileFormName
,TileMasterFormName
,AccessAs
,ImageName
,LayoutType
,MaxNumberOfCards
) VALUES (
'Responsive with Navigation, Menu and Subcollection'
,'FullForm'
,'mResponsiveNavMenuActionsSubCol'
,'WSFormBuilderTemplateResponsiveNavMenuSubCol'
,'WSFormBuilderTemplateResponsiveNavMenuSubCol'
,20
,8
,0
,0
,NULL
,NULL
,'Core'
,'FB_ResponsiveNavMenu.png'
,1
,NULL
)
GO

--FullForm--

IF EXISTS (SELECT 1 FROM WSFormBuilderLayouts WHERE LayoutName = 'Standard Detail' AND FormType = 'FullForm')
DELETE FROM WSFormBuilderLayouts WHERE LayoutName = 'Standard Detail' AND FormType = 'FullForm'

INSERT INTO WSFormBuilderLayouts (
LayoutName
,FormType
,Description
,FormName
,MasterFormName
,NumberOfProperties
,Sequence
,HasTileFlag
,TileHasImageFlag
,TileFormName
,TileMasterFormName
,AccessAs
,ImageName
,LayoutType
,MaxNumberOfCards
) VALUES (
'Standard Detail'
,'FullForm'
,'mStandardDetailForm'
,'WSFormBuilderTemplateStandardDetail'
,'WSFormBuilderTemplateStandardDetail'
,20
,3
,0
,0
,NULL
,NULL
,'Core'
,'FB_StandardDetail.png'
,0
,NULL
)
GO

IF EXISTS (SELECT 1 FROM WSFormBuilderLayouts WHERE LayoutName = 'Standard Form' AND FormType = 'FullForm')
DELETE FROM WSFormBuilderLayouts WHERE LayoutName = 'Standard Form' AND FormType = 'FullForm'

INSERT INTO WSFormBuilderLayouts (
LayoutName
,FormType
,Description
,FormName
,MasterFormName
,NumberOfProperties
,Sequence
,HasTileFlag
,TileHasImageFlag
,TileFormName
,TileMasterFormName
,AccessAs
,ImageName
,LayoutType
,MaxNumberOfCards
) VALUES (
'Standard Form'
,'FullForm'
,'mStandardForm'
,'WSFormBuilderTemplateStandardForm'
,'WSFormBuilderTemplateStandardForm'
,20
,1
,0
,0
,NULL
,NULL
,'Core'
,'FB_StandardForm.png'
,0
,NULL
)
GO

IF EXISTS (SELECT 1 FROM WSFormBuilderLayouts WHERE LayoutName = 'Standard Grid' AND FormType = 'FullForm')
DELETE FROM WSFormBuilderLayouts WHERE LayoutName = 'Standard Grid' AND FormType = 'FullForm'

INSERT INTO WSFormBuilderLayouts (
LayoutName
,FormType
,Description
,FormName
,MasterFormName
,NumberOfProperties
,Sequence
,HasTileFlag
,TileHasImageFlag
,TileFormName
,TileMasterFormName
,AccessAs
,ImageName
,LayoutType
,MaxNumberOfCards
) VALUES (
'Standard Grid'
,'FullForm'
,'mStandardGrid'
,'WSFormBuilderTemplateStandardGrid'
,'WSFormBuilderTemplateStandardGrid'
,20
,2
,0
,0
,NULL
,NULL
,'Core'
,'FB_StandardGrid.png'
,0
,NULL
)
GO

IF EXISTS (SELECT 1 FROM WSFormBuilderLayouts WHERE LayoutName = 'ION Workflow' AND FormType = 'FullForm')
DELETE FROM WSFormBuilderLayouts WHERE LayoutName = 'ION Workflow' AND FormType = 'FullForm'

INSERT INTO WSFormBuilderLayouts (
LayoutName
,FormType
,Description
,FormName
,MasterFormName
,NumberOfProperties
,Sequence
,HasTileFlag
,TileHasImageFlag
,TileFormName
,TileMasterFormName
,AccessAs
,ImageName
,LayoutType
,MaxNumberOfCards
) VALUES (
'ION Workflow'
,'FullForm'
,'mIONWorkflowTemplate'
,'WSFormBuilderTemplateION'
,'WSFormBuilderTemplateION'
,20
,8
,0
,0
,NULL
,NULL
,'Core'
,'FB_ResponsiveNavMenu.png'
,0
,NULL
)
GO

--FormType--

IF EXISTS (SELECT 1 FROM WSFormBuilderLayouts WHERE LayoutName = 'FullForm' AND FormType = 'FormType')
DELETE FROM WSFormBuilderLayouts WHERE LayoutName = 'FullForm' AND FormType = 'FormType'

INSERT INTO WSFormBuilderLayouts (
LayoutName
,FormType
,Description
,FormName
,MasterFormName
,NumberOfProperties
,Sequence
,HasTileFlag
,TileHasImageFlag
,TileFormName
,TileMasterFormName
,AccessAs
,ImageName
,LayoutType
,MaxNumberOfCards
) VALUES (
'FullForm'
,'FormType'
,'mFullForm'
,'N/A'
,'N/A'
,1
,6
,0
,0
,NULL
,NULL
,'Core'
,'FB_RespNav.png'
,0
,NULL
)
GO

IF EXISTS (SELECT 1 FROM WSFormBuilderLayouts WHERE LayoutName = 'Non-Data' AND FormType = 'FormType')
DELETE FROM WSFormBuilderLayouts WHERE LayoutName = 'Non-Data' AND FormType = 'FormType'

INSERT INTO WSFormBuilderLayouts (
LayoutName
,FormType
,Description
,FormName
,MasterFormName
,NumberOfProperties
,Sequence
,HasTileFlag
,TileHasImageFlag
,TileFormName
,TileMasterFormName
,AccessAs
,ImageName
,LayoutType
,MaxNumberOfCards
) VALUES (
'Non-Data'
,'FormType'
,'mNonData'
,'N/A'
,'N/A'
,0
,3
,0
,0
,NULL
,NULL
,'Core'
,'FB_NonDataMenu.png'
,0
,NULL
)
GO

IF EXISTS (SELECT 1 FROM WSFormBuilderLayouts WHERE LayoutName = 'Widget' AND FormType = 'FormType')
DELETE FROM WSFormBuilderLayouts WHERE LayoutName = 'Widget' AND FormType = 'FormType'

INSERT INTO WSFormBuilderLayouts (
LayoutName
,FormType
,Description
,FormName
,MasterFormName
,NumberOfProperties
,Sequence
,HasTileFlag
,TileHasImageFlag
,TileFormName
,TileMasterFormName
,AccessAs
,ImageName
,LayoutType
,MaxNumberOfCards
) VALUES (
'Widget'
,'FormType'
,'mWidget'
,'N/A'
,'N/A'
,1
,2
,0
,0
,NULL
,NULL
,'Core'
,'FB_Widget.png'
,0
,NULL
)
GO