/* $Header: /Tools/SQLScripts/ApplicationDB/Init Data/Event.sql 19   20-11-2019 20:24 R.Shilts $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2017 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
*************************************************************** 
*/
/*  Events  */

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'IdoOnItemInsert')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'IdoOnItemInsert', N'Core', 1, 1, 1, N'Occurs when an IDO inserts a row')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'IdoOnItemUpdate')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'IdoOnItemUpdate', N'Core', 1, 1, 1, N'Occurs when an IDO updates a row')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'IdoOnItemDelete')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'IdoOnItemDelete', N'Core', 1, 1, 1, N'Occurs when an IDO deletes a row')


IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'IdoOnLoadCollection')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'IdoOnLoadCollection', N'Core', 1, 1, 0, N'Occurs when an IDO loads a collection')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'IdoPostLoadCollection')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'IdoPostLoadCollection', N'Core', 1, 1, 0, N'Occurs after an IDO loads a collection')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'IdoOnUpdateCollection')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'IdoOnUpdateCollection', N'Core', 1, 1, 0, N'Occurs when an IDO updates a collection')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'IdoOnPersistFailed')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'IdoOnPersistFailed', N'Core', 1, 1, 0, N'Occurs when an IDO update request fails')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'IdoPostUpdateCollection')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'IdoPostUpdateCollection', N'Core', 1, 1, 0, N'Occurs after an IDO updates a collection')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'IdoPostItemInsert')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'IdoPostItemInsert', N'Core', 1, 1, 0, N'Occurs after an IDO inserts a row')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'IdoPostItemUpdate')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'IdoPostItemUpdate', N'Core', 1, 1, 0, N'Occurs after an IDO updates a row')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'IdoPostItemDelete')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'IdoPostItemDelete', N'Core', 1, 1, 0, N'Occurs after an IDO deletes a row')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'IdoOnInvoke')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'IdoOnInvoke', N'Core', 1, 1, 0, N'Occurs when an IDO calls a method')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'IdoPostInvoke')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'IdoPostInvoke', N'Core', 1, 1, 0, N'Occurs after an IDO calls a method')


IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'SessionOnLogin')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'SessionOnLogin', N'Core', 1, 0, 0, N'Occurs when a login session is created')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'SessionOnLoginFailed')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'SessionOnLoginFailed', N'Core', 1, 0, 0, N'Occurs when a login attempt fails')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'SessionOnLogout')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'SessionOnLogout', N'Core', 1, 0, 0, N'Occurs when a login session is closed')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'SessionOnVarChanged')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'SessionOnVarChanged', N'Core', 1, 0, 0, N'Occurs when a session variable is set')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'SessionPostVarChanged')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'SessionPostVarChanged', N'Core', 1, 0, 0, N'Occurs after a session variable is set')


IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'TaskOnPerform')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'TaskOnPerform', N'Core', 1, 0, 0, N'Occurs when a Task is performed')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'TaskPostPerform')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'TaskPostPerform', N'Core', 1, 0, 0, N'Occurs after a Task is performed')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'TaskOnPerformFailed')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'TaskOnPerformFailed', N'Core', 1, 0, 0, N'Occurs when a Task fails to be performed')


IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'GenericNotify')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'GenericNotify', N'Core', 0, 0, 0, N'Sends a message based on parameters')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'TaskListCheck')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'TaskListCheck', N'Core', 0, 0, 0, N'Reminds users of their tasks and appts.')
   -- "Notifies all users of their tasks and appointments whose Remind Date has passed"


IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'GenericSendEmail')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'GenericSendEmail', N'Core', 0, 0, 0,  N'Sends an e-mail based on parameters')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'ProcessNewDataMaintenance')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'ProcessNewDataMaintenance', N'Core', 0, 0, 0, N'Creates a new table and IDO.')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'BodOnReceive')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'BodOnReceive', N'Core', 1, 0, 0, N'Occurs when any inbound BOD is received')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'GenericNotifyWithAttachments')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'GenericNotifyWithAttachments', N'Core', 0, 0, 0, N'Sends a message with attachments')

-- A feature to send alert into ION
IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'GenericSendPulseAlertBOD')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'GenericSendPulseAlertBOD', N'Core', 0, 0, 0, N'Send an alert to ION')   

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'AssignUserToAdminLicenseModule')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'AssignUserToAdminLicenseModule', N'Core', 0, 0, 0, N'Event to assign admin licence module')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'AssignUserToLicenseModule')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'AssignUserToLicenseModule', N'Core', 0, 0, 0, N'Assign named user to named module')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'AssignRandomPasswordToUser')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'AssignRandomPasswordToUser', N'Core', 0, 0, 0, N'Assign random encrypted password to user')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'ClearServiceSessions')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'ClearServiceSessions', N'Core', 0, 0, 0, N'Clears out old service sessions.')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'LazyDeleteLicenseModuleExecute')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'LazyDeleteLicenseModuleExecute', N'Core', 0, 0, 0, N'Execute the user-modules lazy delete.')

IF NOT EXISTS (SELECT 1 FROM Event WHERE EventName = N'PurgeHistoryData')
INSERT INTO Event (EventName, AccessAs, IsFrameworkEvent, IsFrameworkIDOEvent, IsFrameworkIDOSuspendableEvent, Description)
   VALUES (N'PurgeHistoryData', N'Core', 0, 0, 0, N'Execute Purge History Data module.')
