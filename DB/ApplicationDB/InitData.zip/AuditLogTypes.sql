/* $Header: /Tools/SQLScripts/ApplicationDB/Init Data/AuditLogTypes.sql 3     5/20/11 5:31p Djohnson $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
*************************************************************** 
*/
/* AuditLogTypes */
IF NOT EXISTS(SELECT 1 FROM AuditLogTypes WHERE MessageType = 1)
INSERT INTO AuditLogTypes
  (MessageType,MessageDesc,Category,FieldName)
  VALUES
  (1,'User Login','S',NULL)

IF NOT EXISTS(SELECT 1 FROM AuditLogTypes WHERE MessageType = 2)
INSERT INTO AuditLogTypes
  (MessageType,MessageDesc,Category,FieldName)
  VALUES
  (2,'Open Form','S',NULL)

IF NOT EXISTS(SELECT 1 FROM AuditLogTypes WHERE MessageType = 3)
INSERT INTO AuditLogTypes
  (MessageType,MessageDesc,Category,FieldName)
  VALUES
  (3,'Modify Form/Object','S',NULL)

IF NOT EXISTS(SELECT 1 FROM AuditLogTypes WHERE MessageType = 4)
INSERT INTO AuditLogTypes
  (MessageType,MessageDesc,Category,FieldName)
  VALUES
  (4,'Event Audit','S',NULL)

IF NOT EXISTS(SELECT 1 FROM AuditLogTypes WHERE MessageType = 5)
INSERT INTO AuditLogTypes
  (MessageType,MessageDesc,Category,FieldName)
  VALUES
  (5,'User Login Failure','S',NULL)

IF NOT EXISTS(SELECT 1 FROM AuditLogTypes WHERE MessageType = 6)
INSERT INTO AuditLogTypes
  (MessageType,MessageDesc,Category,FieldName)
  VALUES
  (6,'User Logout','S',NULL)


GO
