SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

/* $Header: /Tools/SQLScripts/ApplicationDB/Init Data/CoreGroupNames.sql 2     22-03-17 9:43 Rshilts $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/

IF NOT EXISTS(SELECT 1 FROM GroupNames
   where GroupName = 'CoreFormsAdmin')
INSERT GroupNames
   (GroupName, GroupDesc)
VALUES ('CoreFormsAdmin', 'Administration Group')

IF NOT EXISTS(SELECT 1 FROM GroupNames
   where GroupName = 'CoreFormsDeveloper')
INSERT GroupNames
   (GroupName, GroupDesc)
VALUES ('CoreFormsDeveloper', 'Developer Group')

IF NOT EXISTS(SELECT 1 FROM GroupNames
   where GroupName = 'CoreFormsEndUser')
INSERT GroupNames
   (GroupName, GroupDesc)
VALUES ('CoreFormsEndUser', 'End User Group')

IF NOT EXISTS(SELECT 1 FROM GroupNames
   WHERE GroupName = 'CoreIDOs')
INSERT GroupNames
   (GroupName, GroupDesc)
VALUES ('CoreIDOs', 'Mongoose IDO Group')

IF NOT EXISTS(SELECT 1 FROM GroupNames
   WHERE GroupName = 'Infor-SystemAdministrator')
INSERT GroupNames
   (GroupName, GroupDesc)
VALUES ('Infor-SystemAdministrator', 'Infor Administration Group')

IF NOT EXISTS(SELECT 1 FROM GroupNames
   WHERE GroupName = 'APPBUILDER-Administrator')
INSERT GroupNames
   (GroupName, GroupDesc)
VALUES ('APPBUILDER-Administrator', 'AppBuilder Administrator Group')

IF NOT EXISTS(SELECT 1 FROM GroupNames
   WHERE GroupName = 'APPBUILDER-Designer')
INSERT GroupNames
   (GroupName, GroupDesc)
VALUES ('APPBUILDER-Designer', 'AppBuilder Designer Group')

IF NOT EXISTS(SELECT 1 FROM GroupNames
   WHERE GroupName = 'APPBUILDER-User')
INSERT GroupNames
   (GroupName, GroupDesc)
VALUES ('APPBUILDER-User', 'AppBuilder User Group')