/* RS-8305 "External Role Aliases"
 * Default values to emulate legacy "prefix" concept
 * Reference old Jira: COMPANYON-16061 (https://jira.infor.com/browse/COMPANYON-16061)
 *
 * Issue 244980 - R.Shilts  26-Apr-2018
 * No longer require the ModuleNames.ModuleName to exist before assigning here.
 * This requires an extra check whenever we dereference a module (to make sure it really exists), but 
 * it solves the chicken-egg problem for license modules.
 *
 * Issue 250752 - R.Shilts  26-Apr-2018
 * Should not contain an entry for module MGPAAS since that role should not be assigned to any human (ever).
 */

----------------------------------------------------
-- Mongoose standard GROUPS
----------------------------------------------------
IF EXISTS(SELECT 1 FROM [GroupNames] WHERE [GroupName] = N'CoreFormsAdmin')
BEGIN
   IF  NOT EXISTS(SELECT 1 FROM [ExternalRoleAlias] WHERE [ExternalRoleName] = N'MONGOOSE-UG-CoreFormsAdmin')
   AND NOT EXISTS(SELECT 1 FROM [ExternalRoleAlias] WHERE [GroupName] = N'CoreFormsAdmin')
      INSERT INTO [ExternalRoleAlias]  ([ExternalRoleName], [GroupName]) VALUES (N'MONGOOSE-UG-CoreFormsAdmin', N'CoreFormsAdmin')
END

IF EXISTS(SELECT 1 FROM [GroupNames] WHERE [GroupName] = N'CoreFormsDeveloper')
BEGIN
   IF  NOT EXISTS(SELECT 1 FROM [ExternalRoleAlias] WHERE [ExternalRoleName] = N'MONGOOSE-UG-CoreFormsDeveloper')
   AND NOT EXISTS(SELECT 1 FROM [ExternalRoleAlias] WHERE [GroupName] = N'CoreFormsDeveloper')
      INSERT INTO [ExternalRoleAlias]  ([ExternalRoleName], [GroupName]) VALUES (N'MONGOOSE-UG-CoreFormsDeveloper', N'CoreFormsDeveloper')
END

IF EXISTS(SELECT 1 FROM [GroupNames] WHERE [GroupName] = N'CoreFormsEndUser')
BEGIN
   IF  NOT EXISTS(SELECT 1 FROM [ExternalRoleAlias] WHERE [ExternalRoleName] = N'MONGOOSE-UG-CoreFormsEndUser')
   AND NOT EXISTS(SELECT 1 FROM [ExternalRoleAlias] WHERE [GroupName] = N'CoreFormsEndUser')
      INSERT INTO [ExternalRoleAlias]  ([ExternalRoleName], [GroupName]) VALUES (N'MONGOOSE-UG-CoreFormsEndUser', N'CoreFormsEndUser')
END

IF EXISTS(SELECT 1 FROM [GroupNames] WHERE [GroupName] = N'CoreIDOs')
BEGIN
   IF  NOT EXISTS(SELECT 1 FROM [ExternalRoleAlias] WHERE [ExternalRoleName] = N'MONGOOSE-UG-CoreIDOs')
   AND NOT EXISTS(SELECT 1 FROM [ExternalRoleAlias] WHERE [GroupName] = N'CoreIDOs')
      INSERT INTO [ExternalRoleAlias]  ([ExternalRoleName], [GroupName]) VALUES (N'MONGOOSE-UG-CoreIDOs', N'CoreIDOs')
END


----------------------------------------------------
-- Mongoose standard LICENSE MODULES
-- No check to see if it's really in the ModuleName table.
----------------------------------------------------
IF  NOT EXISTS(SELECT 1 FROM [ExternalRoleAlias] WHERE [ExternalRoleName] = N'MONGOOSE-LM-MGCoreAutomation')
AND NOT EXISTS(SELECT 1 FROM [ExternalRoleAlias] WHERE [ModuleName] = N'MGCoreAutomation')
BEGIN
   INSERT INTO [ExternalRoleAlias]  ([ExternalRoleName], [ModuleName]) VALUES (N'MONGOOSE-LM-MGCoreAutomation', N'MGCoreAutomation')
END

IF  NOT EXISTS(SELECT 1 FROM [ExternalRoleAlias] WHERE [ExternalRoleName] = N'MONGOOSE-LM-MGCoreTrans')
AND NOT EXISTS(SELECT 1 FROM [ExternalRoleAlias] WHERE [ModuleName] = N'MGCoreTrans')
BEGIN
   INSERT INTO [ExternalRoleAlias]  ([ExternalRoleName], [ModuleName]) VALUES (N'MONGOOSE-LM-MGCoreTrans', N'MGCoreTrans')
END

IF  NOT EXISTS(SELECT 1 FROM [ExternalRoleAlias] WHERE [ExternalRoleName] = N'MONGOOSE-LM-MGDataViews')
AND NOT EXISTS(SELECT 1 FROM [ExternalRoleAlias] WHERE [ModuleName] = N'MGDataViews')
BEGIN
   INSERT INTO [ExternalRoleAlias]  ([ExternalRoleName], [ModuleName]) VALUES (N'MONGOOSE-LM-MGDataViews', N'MGDataViews')
END

IF  NOT EXISTS(SELECT 1 FROM [ExternalRoleAlias] WHERE [ExternalRoleName] = N'MONGOOSE-LM-MGDeveloper')
AND NOT EXISTS(SELECT 1 FROM [ExternalRoleAlias] WHERE [ModuleName] = N'MGDeveloper')
BEGIN
   INSERT INTO [ExternalRoleAlias]  ([ExternalRoleName], [ModuleName]) VALUES (N'MONGOOSE-LM-MGDeveloper', N'MGDeveloper')
END

IF  NOT EXISTS(SELECT 1 FROM [ExternalRoleAlias] WHERE [ExternalRoleName] = N'MONGOOSE-LM-MGUserCreatedForms')
AND NOT EXISTS(SELECT 1 FROM [ExternalRoleAlias] WHERE [ModuleName] = N'MGUserCreatedForms')
BEGIN
   INSERT INTO [ExternalRoleAlias]  ([ExternalRoleName], [ModuleName]) VALUES (N'MONGOOSE-LM-MGUserCreatedForms', N'MGUserCreatedForms')
END

IF  NOT EXISTS(SELECT 1 FROM [ExternalRoleAlias] WHERE [ExternalRoleName] = N'MONGOOSE-LM-MGUserCreatedIDOs')
AND NOT EXISTS(SELECT 1 FROM [ExternalRoleAlias] WHERE [ModuleName] = N'MGUserCreatedIDOs')
BEGIN
   INSERT INTO [ExternalRoleAlias]  ([ExternalRoleName], [ModuleName]) VALUES (N'MONGOOSE-LM-MGUserCreatedIDOs', N'MGUserCreatedIDOs')
END

IF  NOT EXISTS(SELECT 1 FROM [ExternalRoleAlias] WHERE [ExternalRoleName] = N'MONGOOSE-LM-MGAppBuilder')
AND NOT EXISTS(SELECT 1 FROM [ExternalRoleAlias] WHERE [ModuleName] = N'MGAppBuilder')
BEGIN
   INSERT INTO [ExternalRoleAlias]  ([ExternalRoleName], [ModuleName]) VALUES (N'MONGOOSE-LM-MGAppBuilder', N'MGAppBuilder')
END

