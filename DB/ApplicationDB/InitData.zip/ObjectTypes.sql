/* $Header: /Tools/SQLScripts/ApplicationDB/Init Data/ObjectTypes.sql 3     3/08/10 9:08a Dahn $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
*************************************************************** 
*/
/* ObjectTypes */
IF NOT EXISTS(SELECT 1 FROM ObjectTypes WHERE ObjectType = 0)
INSERT INTO ObjectTypes (ObjectType, ObjectCode, ObjectDesc)
   VALUES (0, 'TABLE', 'Table Object')

IF NOT EXISTS(SELECT 1 FROM ObjectTypes WHERE ObjectType = 1)
INSERT INTO ObjectTypes (ObjectType, ObjectCode, ObjectDesc)
   VALUES (1, 'COLUMN', 'Column Object')

IF NOT EXISTS(SELECT 1 FROM ObjectTypes WHERE ObjectType = 2)
INSERT INTO ObjectTypes (ObjectType, ObjectCode, ObjectDesc)
   VALUES (2, 'SP', 'Stored Procedure Object')

IF NOT EXISTS(SELECT 1 FROM ObjectTypes WHERE ObjectType = 3)
INSERT INTO ObjectTypes (ObjectType, ObjectCode, ObjectDesc)
   VALUES (3, 'TRIGER', 'Trigger Object')

