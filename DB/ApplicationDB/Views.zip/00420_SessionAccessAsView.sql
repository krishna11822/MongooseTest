SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON 
GO

IF object_id('dbo.SessionAccessAsView') IS NOT NULL
   DROP VIEW dbo.SessionAccessAsView
GO
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/SessionAccessAsView.sql 2     3/08/10 9:03a Dahn $ */

/*

***************************************************************

*                                                             *

*                           NOTICE                            *

*                                                             *

*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *

*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *

*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *

*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *

*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *

*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *

*   ALL OTHER RIGHTS RESERVED.                                *

*                                                             *

*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *

*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *

*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *

*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *

*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *

*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *

*                                                             *

***************************************************************

*/

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/SessionAccessAsView.sql $
 *
 * CoreDev 2 rs4588 Dahn Mon Mar 08 09:03:22 2010
 * rs4588 copyright header changes.
 *
 * CoreDev 1 105144 Nthurn Mon Jan 05 10:10:41 2009
 * Session Access As does not work
 * Returns the current SessionAccessAs values.
 *
 * 03/06/2020 - dartiaga - Issue 260253: added row pointer
 * 09/15/2020 - dartiaga - MGD-548: remove rowpointer (undo)
 *
 * $NoKeywords: $
 */
CREATE VIEW SessionAccessAsView
AS
   SELECT
      SessionAccessAsInUse
      , IncludeAccessAs
      , ExcludeAccessAs
      , ExcludeBlankAccessAs
   FROM dbo.GetSessionAccessAs()

GO
