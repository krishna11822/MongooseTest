IF OBJECT_ID('dbo.SLTables') IS NOT NULL
   DROP VIEW SLTables
GO
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/SLTables.sql 6     3/08/10 9:03a Dahn $ */

/*

***************************************************************

*                                                             *

*                           NOTICE                            *

*                                                             *

*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *

*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *

*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *

*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *

*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *

*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *

*   ALL OTHER RIGHTS RESERVED.                                *

*                                                             *

*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *

*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *

*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *

*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *

*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *

*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *

*                                                             *

***************************************************************

*/

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/SLTables.sql $
 *
 * CoreDev 6 rs4588 Dahn Mon Mar 08 09:03:23 2010
 * rs4588 copyright header changes.
 *
 * CoreDev 5 rs3953 Dahn Tue Aug 26 15:51:58 2008
 * changing copyright header (rs3953)
 * $NoKeywords: $
 */
CREATE VIEW SLTables
AS

SELECT tab.name AS TableName, dbo.StringOf('@' + tab.name) As RecordDesc
   , ModuleName AS AreaName
FROM sysobjects AS tab
INNER JOIN syscolumns AS col
   ON col.id = tab.id AND col.name = 'NoteExistsFlag'
LEFT OUTER JOIN AppTable
   ON AppTable.TableName = tab.name
WHERE tab.type = 'U'
AND tab.name NOT LIKE '%[_]all'
AND tab.name NOT LIKE '%[_]committed'
AND tab.name NOT LIKE '%[_]impacted'
AND tab.name NOT LIKE 'tt[_]%'
AND tab.name NOT LIKE 'tmp[_]%'

GO
