IF OBJECT_ID(N'EventCurrentPromptVotingTallyView') IS NOT NULL
   DROP VIEW EventCurrentPromptVotingTallyView
GO

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/EventCurrentPromptVotingTallyView.sql $
 *
 * CoreDev 2 RS5077 Djohnson Fri Oct 17 09:23:52 2014
 * RS5077 - changes to remove sqlclr for tally calculation.
 *
 * CoreDev 1 project Nthurn Tue Mar 20 18:59:11 2012
 * Shows voting information about current Prompts.
 *
 * $NoKeywords: $
 */
CREATE view EventCurrentPromptVotingTallyView
AS
SELECT EventStateRowPointer, EventHandlerStateRowPointer, ActionSequence, Choices, Result, FormattedResult, Choice, Votes, FrontRunner, Tied, Margin, VotesToWin, Status
FROM EventSessionTally
WHERE SessionID = dbo.SessionIDSp()

GO
