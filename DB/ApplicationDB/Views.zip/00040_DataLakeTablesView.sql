SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[DataLakeTablesView]'))
DROP VIEW [dbo].[DataLakeTablesView]
GO

/* $Header: /Tools/SQLScripts/ApplicationDB/Views/DataLakeTablesView.sql 1     3/12/18 2:35p johndou $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/ESBSecurityRoleMasterView.sql $
 *
 * CoreDev 2 RS8716 Djohnson Mon Mar 25 2019
 * Table prefixes for datalake
 *
 * CoreDev 1 RS8189 johndou Mar 12 14:35:10 2018
*/
CREATE VIEW [dbo].[DataLakeTablesView]
AS

SELECT
  DISTINCT ISNULL(DefaultValue, N'Mongoose') + roc.object_name AS object_name, site2.site AS TargetSite
FROM rep_object_category AS roc
INNER JOIN rep_rule AS rr ON
  rr.category = roc.category
INNER JOIN sysobjects so ON
  so.name = roc.object_name
INNER JOIN site site1 ON
  site1.site = rr.source_site
INNER JOIN site site2 ON
  site2.site = rr.target_site
INNER JOIN intranet it2 ON
  it2.intranet_name = site2.intranet_name
LEFT OUTER JOIN SystemProcessDefaults spd ON
  spd.DefaultType = 71
WHERE roc.object_type = 1
AND it2.ION_transfer_type = 2 -- ION messaging
AND roc.object_name = roc.object_name
AND so.type = 'U' --  Exclude views which might be used for transactional
                  -- replication.
AND rr.source_site IN (
  SELECT site
  FROM site
  WHERE app_db_name = DB_NAME()
)
GO
