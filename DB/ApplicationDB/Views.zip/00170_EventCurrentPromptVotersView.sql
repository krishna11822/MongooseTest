IF OBJECT_ID(N'EventCurrentPromptVotersView') IS NOT NULL
   DROP VIEW EventCurrentPromptVotersView
GO
-- See also EventCurrentPromptUnvotedChoicesView (number of columns must match!)

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/EventCurrentPromptVotersView.sql $
 *
 * CoreDev 1 project Nthurn Tue Mar 20 18:59:45 2012
 * Shows information about votes made on current Prompts.
 *
 * $NoKeywords: $
 */
CREATE VIEW EventCurrentPromptVotersView
AS
-- Votes & non-Votes (one row per Voter):
SELECT
es.EventName,
er.EventRevision,
es.RowPointer AS EventStateRowPointer,
eh.Sequence AS HandlerSequence,
ehs.RowPointer AS EventHandlerStateRowPointer,
ea.Sequence AS ActionSequence,
-- A zero Iteration indicates a row created before MG8!
CASE eas.Iteration WHEN 0 THEN TimesExecuted + 1 ELSE eas.Iteration END AS Iteration,
eas.MessageRecipientList,
em.Subject,
em.Question,
em.Choices,
eas.VotingRule,
eas.PreferredChoice,
eas.VotingMinimum,
(SELECT COUNT(*) FROM EventMessage votes
   WHERE votes.EventActionStateRowPointer = em.EventActionStateRowPointer
   -- A zero ActionIteration indicates a row created before MG8!
   AND (em.ActionIteration = 0 AND votes.CreateDate = em.CreateDate
      OR em.ActionIteration > 0 AND votes.ActionIteration = em.ActionIteration)
   ) AS Voters,
eas.Quorum,
ehs.VotingOpen,
(SELECT COUNT(*) FROM EventMessage votes
   WHERE votes.EventActionStateRowPointer = em.EventActionStateRowPointer
   -- A zero ActionIteration indicates a row created before MG8!
   AND (em.ActionIteration = 0 AND votes.CreateDate = em.CreateDate
      OR em.ActionIteration > 0 AND votes.ActionIteration = em.ActionIteration)
   AND votes.SelectedChoice IS NOT NULL) AS VotesCounted,
Username,
em.HasBeenRead,
CASE WHEN SelectedChoice IS NOT NULL THEN 1 ELSE 0 END AS Voted,
SelectedChoice,
CASE dbo.LookupTrimmed(SelectedChoice, em.Choices, N',') WHEN 0 THEN NULL ELSE N'FORMAT(' + LTRIM(RTRIM(dbo.Entry(1 + dbo.LookupTrimmed(SelectedChoice, em.Choices, N','), em.Choices, N','))) + N')' END AS FormattedChoice,
CASE WHEN SelectedChoice IS NULL AND dbo.GetSiteDate(GETDATE()) > em.ExpiresAfterDate THEN 1 ELSE 0 END
   AS Expired,
em.SentDate,
em.ResponseDate,
DATEDIFF(SECOND, em.SentDate, em.ResponseDate) / 86400 AS ResponseTimeDays,
DATEDIFF(SECOND, em.SentDate, em.ResponseDate) % 86400 AS ResponseTimeSecondsUnder1Day,
DATEADD(SECOND, DATEDIFF(SECOND, em.SentDate, em.ResponseDate) % 86400, '1900-01-01') AS ResponseTimeUnder1Day,
CONVERT(NVARCHAR(8), DATEADD(SECOND, DATEDIFF(SECOND, em.SentDate, em.ResponseDate) % 86400, '1900-01-01'), 108) AS ResponseTimeUnder1DayString,
-- We don't worry too much about the execution time of dbo.GetSiteDate(), because:
-- a) We call it only for unvoted Messages (which shouldn't be a large number, given that this view is meant to be used long after the Prompt);
-- b) This view is meant to be restricted to a single EventHandlerStateRowPointer;
-- c) SQL Server evaluates only those columns that are requested in the SELECT from this View.
CASE WHEN SelectedChoice IS NULL THEN DATEDIFF(SECOND, em.SentDate, dbo.MinDate(em.ExpiresAfterDate, dbo.GetSiteDate(GETDATE()))) / 86400 ELSE NULL END AS WaitTimeDays,
CASE WHEN SelectedChoice IS NULL THEN DATEDIFF(SECOND, em.SentDate, dbo.MinDate(em.ExpiresAfterDate, dbo.GetSiteDate(GETDATE()))) % 86400 ELSE NULL END AS WaitTimeSecondsUnder1Day,
CASE WHEN SelectedChoice IS NULL THEN DATEADD(SECOND, DATEDIFF(SECOND, em.SentDate, dbo.MinDate(em.ExpiresAfterDate, dbo.GetSiteDate(GETDATE()))) % 86400, '1900-01-01') ELSE NULL END AS WaitTimeUnder1Day,
CASE WHEN SelectedChoice IS NULL THEN CONVERT(NVARCHAR(8), DATEADD(SECOND, DATEDIFF(SECOND, em.SentDate, dbo.MinDate(em.ExpiresAfterDate, dbo.GetSiteDate(GETDATE()))) % 86400, '1900-01-01'), 108) ELSE NULL END AS WaitTimeUnder1DayString,
em.ExpiresAfterDate,
em.RowPointer AS EventMessageRowPointer
FROM EventState es
INNER JOIN EventHandlerState ehs ON ehs.EventStateRowPointer = es.RowPointer
INNER JOIN EventHandlerRevision eh ON eh.RowPointer = ehs.EventHandlerRowPointer
INNER JOIN EventRevision er ON er.RowPointer = eh.EventRevisionRowPointer
INNER JOIN EventActionState eas ON eas.EventHandlerStateRowPointer = ehs.RowPointer
INNER JOIN EventAction ea ON ea.RowPointer = eas.EventActionRowPointer
INNER JOIN EventMessage em ON em.EventActionStateRowPointer = eas.RowPointer
INNER JOIN Usernames u ON u.Userid = em.Userid
-- Current Action:
WHERE eas.EventActionRowPointer = ehs.CurrentEventActionRowPointer
-- Prompts only (not Notifies nor SendMessages):
AND em.Choices IS NOT NULL
-- Ignore (Unvotable) Originator's Saved Message copy:
AND em.IsSavedMessage = 0
-- Just the "last" Votable EventMessage group for this EventAction (in case of Action looping):
AND NOT EXISTS(SELECT 1 FROM EventMessage em2
WHERE em2.EventActionStateRowPointer = eas.RowPointer
AND em2.Choices IS NOT NULL
AND em2.IsSavedMessage = 0
AND em2.CreateDate > em.CreateDate)
-- Ignore special non-Votable signal from EventSendMessageSp:
AND (em.SelectedChoice IS NULL OR em.SelectedChoice <> N',')

GO

/** Testing:

select voters.* from EventCurrentPromptVotersView voters
where eventhandlerstaterowpointer in
(
--'E9ACC146-7377-41EB-90E7-4E8941711AD2'
--,'7CA5BC37-1B5A-4456-8DF6-3F322DFF72DE'
--,'7C8D4A3D-BFA5-418E-82D2-1C6A877E6E27'
--,'28FBB523-66FB-4D43-BE0A-AB85834378CE'
--,'03BF8F49-A794-46E2-9777-1A48D138EE04'
--,'EAAAF641-C332-457D-8F03-B4ACB391F38C'
--,'F43BB47D-6F59-4ADD-9689-F05351652605'
'1B5DA1CC-98C0-476E-8FB2-0C92AC719E70'
--,'5216E85C-A4C7-4C91-B4ED-4A162C3C7CBB'
--,'C357AADF-DBB5-434D-A0E7-82DEAA2BC37A'
)
order by 1,2,4,6,7,3,5
 **/


/** Testing

SELECT TOP 200 cpv.EventHandlerStateRowPointer [EventHandlerStateRowPointer], cpv.Username [Username]
FROM EventCurrentPromptVotersView cpv
WHERE cpv.SelectedChoice IS NOT NULL AND cpv.EventHandlerStateRowPointer= N'f43bb47d-6f59-4add-9689-f05351652605' 
ORDER BY cpv.Username

SELECT TOP 200 cpv.EventHandlerStateRowPointer [EventHandlerStateRowPointer], cpv.Username [Username]
FROM EventCurrentPromptVotersView cpv
WHERE cpv.SelectedChoice IS NULL AND cpv.EventHandlerStateRowPointer= N'f43bb47d-6f59-4add-9689-f05351652605' 
ORDER BY cpv.Username
 **/
