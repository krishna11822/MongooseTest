SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON 
GO

IF object_id('dbo.JMSOurIntranetView') IS NOT NULL
   DROP VIEW dbo.JMSOurIntranetView
GO
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/JMSOurIntranetView.sql 4     3/08/10 9:03a Dahn $ */

/*

***************************************************************

*                                                             *

*                           NOTICE                            *

*                                                             *

*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *

*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *

*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *

*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *

*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *

*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *

*   ALL OTHER RIGHTS RESERVED.                                *

*                                                             *

*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *

*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *

*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *

*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *

*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *

*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *

*                                                             *

***************************************************************

*/

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/JMSOurIntranetView.sql $
 *
 * CoreDev 4 rs4588 Dahn Mon Mar 08 09:03:14 2010
 * rs4588 copyright header changes.
 *
 * CoreDev 3 rs3953 Dahn Tue Aug 26 15:51:55 2008
 * changing copyright header (rs3953)
 *
 * $NoKeywords: $
 */
CREATE VIEW JMSOurIntranetView
AS
-- Return the name of this Site's Intranet's Queue Server
-- (to which InboundBus.exe will append "\Inbound" and push messages to that MSMQ):
SELECT
   intranet.intranet_name,
   intranet.queue_server
FROM parms
INNER JOIN site ON site.site = parms.site
INNER JOIN intranet ON intranet.intranet_name = site.intranet_name
WHERE parms.parm_key = 0
-- InboundBus.exe won't work on a JMS Intranet!
AND intranet.Transport = N'H'
/* Potential short-cut if we want to skip JMSIntranetsView
 * on a Site that does not need to run InboundBus:
AND EXISTS(SELECT 1 FROM intranet
   WHERE intranet_name <> @IntranetName
   AND Transport = N'J'
   )
 */
-- If no rows are returned, InboundBus.exe has nothing to do!

GO
