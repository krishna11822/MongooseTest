IF OBJECT_ID('dbo.SLHighKeys') IS NOT NULL
   DROP VIEW SLHighKeys
GO

/* $Header: /Tools/SQLScripts/ApplicationDB/Views/SLHighKeys.sql 3     1/11/16 3:12p Djohnson $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/
/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/SLHighKeys.sql $
 * CoreDev 4 256700 Djohnson Thu Sep 19 2019
 * Add Table.Column to result set.
 *
 * CoreDev 3 205571 Djohnson Mon Jan 11 15:12:44 2016
 * For Synchronize Next keys we need to either adjust the view under the form to allow it to work with get more rows or override the record cap to return all rows on this form.
 * Issue #205571 - Add RowPointer so bunching can be used.
 *
 * CoreDev 2 204093 Djohnson Thu Nov 05 14:43:53 2015
 * Synchronize Next Keys does not show table and column for user tables
 * Issue #204093 - if the label for a table or column is an empty string, just returnt he table or column name directly.
 *
 * CoreDev 1 153968 Mbair1 Thu Nov 01 13:35:21 2012
 * Unable to Add New Employee
 * Issue 153968
 *
 * SL8.02 8 rs4588 Dahn Fri Mar 05 08:29:57 2010
 * rs4588 copyright header changes.
 *
 * SL8.01 7 rs3953 Dahn Tue Aug 26 14:58:01 2008
 * changing copyright header(rs3953)
 *
 * SL8.01 6 rs3953 Dahn Mon Aug 18 14:42:49 2008
 * changing copyright information(RS3953)
 *
 * SL8.00 5 RS2968 nkaleel Fri Feb 23 08:27:06 2007
 * changing copyright information(RS2968)
 *
 * SL8.00 4 RS2968 prahaladarao.hs Thu Jul 13 00:52:07 2006
 * RS 2968, Name change CopyRight Update.
 *
 * SL8.00 3 RS2968 prahaladarao.hs Mon Jul 10 10:10:31 2006
 * RS 2968
 * Name change CopyRight Update.
 *
 * $NoKeywords: $
 */
CREATE VIEW SLHighKeys
AS
SELECT 
   TableColumnName,
   CASE WHEN dbo.GetLabel('@' + substring(TableColumnName, 1, charindex('.', TableColumnName) - 1)) != ''
THEN dbo.GetLabel('@' + substring(TableColumnName, 1, charindex('.', TableColumnName) - 1))
ELSE dbo.entry(1,tablecolumnname,'.')
END
      AS [TableLabel]
   , CASE WHEN dbo.GetLabel('@' + TableColumnName) != ''
    THEN dbo.GetLabel('@' + TableColumnName)
ELSE dbo.entry(2,tablecolumnname,'.')
END
      AS [ColumnLabel]
   , SubKey
   , KeyPrefix AS Prefix
   , CASE WHEN KeyID < 0 THEN KeyPrefix
      ELSE dbo.ExpandKyByTableCol (
         substring(TableColumnName, 1, charindex('.', TableColumnName) - 1)
         , substring(TableColumnName, charindex('.', TableColumnName) + 1, len(TableColumnName))
         , KeyPrefix + cast(KeyID as NVARCHAR)
         )
      END AS HighKey
   , RowPointer
FROM NextKeys AS nk1

--  First get rid of all non-max rows.
WHERE KeyID = (SELECT MAX(nk2.KeyID)
  FROM NextKeys AS nk2
  WHERE nk2.TableColumnName = nk1.TableColumnName
  AND   nk2.KeyPrefix = nk1.KeyPrefix
  AND   ISNULL(nk2.SubKey, NCHAR(1)) = ISNULL(nk1.SubKey, NCHAR(1)))

-- Next get rid of all but 1 of duplicates.
AND RowPointer = (SELECT TOP 1 nk3.RowPointer
  FROM NextKeys AS nk3
  WHERE nk3.TableColumnName = nk1.TableColumnName
  AND   nk3.KeyPrefix = nk1.KeyPrefix
  AND   nk3.KeyID = nk1.KeyID
  AND   ISNULL(nk3.SubKey, NCHAR(1)) = ISNULL(nk1.SubKey, NCHAR(1)))

--ORDER BY TableColumnName, KeyPrefix, KeyID, SubKey

