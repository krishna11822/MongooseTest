SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO

IF EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[ESBSecurityPermissionsMasterView]'))
DROP VIEW [dbo].[ESBSecurityPermissionsMasterView]
GO

/* $Header: /Tools/SQLScripts/ApplicationDB/Views/ESBSecurityPermissionsMasterView.sql 3     9/25/17 1:49p Djackson1 $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2021 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/


/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/ESBSecurityPermissionsMasterView.sql $
 * MGD-3246 - djohnson Oct 28 2021
 * Add a DerParentID so that all form components can be brought in for a form.
 *
 * Core90310 3 234080 Djackson1 Mon Sep 25 13:49:05 2017
 * ESBSecurityPermissionsMasterView userflag
 * 234080 userflag = 0 for groupid and userflag = 1 for useri
 *
 * CoreDev 2 226620 Djackson1 Wed Apr 05 15:55:42 2017
 * Approva ID elements exceed the 100 char limit
 * 226620 - IDs over 100 char
 *
 * CoreDev 1 RS6090 Djackson1 Tue Jan 10 10:28:08 2017
 * 6090 - Approva integration
 *
 *
 * $NoKeywords: $
 */
 
CREATE VIEW [dbo].[ESBSecurityPermissionsMasterView]
AS

SELECT DISTINCT
  DerBODID = 
      CASE WHEN NOT un.WorkStationLogin IS NULL THEN 'U' 
           WHEN NOT un.UserId IS NULL THEN 'U'  
           WHEN NOT GroupName IS NULL THEN 'G'
           ELSE ''
      END
      + '~' +       
       COALESCE(un.WorkStationLogin, LTRIM(STR(UserId)), GroupName, '') + '~' + CAST(aa.RowPointer AS NVARCHAR(36))
  , Id = 
      CASE WHEN NOT un.WorkStationLogin IS NULL THEN 'U' 
           WHEN NOT un.UserId IS NULL THEN 'U'  
           WHEN NOT GroupName IS NULL THEN 'G'
           ELSE ''
      END
      + '~' +       
      COALESCE(un.WorkStationLogin, LTRIM(STR(UserId)), GroupName, '') + '~' + CAST(ISNULL(ac.RowPointer, aa.RowPointer) AS NVARCHAR(36))
  , ObjectName1 = aa.ObjectName1
  , ObjectName2 = aa.ObjectName2
  , Groupid = gn.groupid
  , GroupName = gn.GroupName
  , GroupDesc = gn.GroupDesc
  , Userid = un.userid
  , Username = un.username
  , WorkstationLogin = ISNULL(un.WorkstationLogin, un.UserId)
  , DeletePrivilege = ISNULL(aa.DeletePrivilege,0) 
  , EditPrivilege = ISNULL(aa.EditPrivilege, 0)    
  , ExecutePrivilege = ISNULL(aa.ExecutePrivilege, 0)    
  , InsertPrivilege = ISNULL(aa.InsertPrivilege, 0)    
  , ReadPrivilege = ISNULL(aa.ReadPrivilege, 0)    
  , UpdatePrivilege = ISNULL(aa.UpdatePrivilege, 0)    
  , BulkUpdatePrivilege = ISNULL(aa.BulkUpdatePrivilege, 0)
  , CreateDate = aa.CreateDate
  , RecordDate = ISNULL(un.RecordDate, aa.RecordDate)
  , ObjectType = aa.ObjectType
  , DerParentID = 
      CASE WHEN NOT un.WorkStationLogin IS NULL THEN 'U' 
           WHEN NOT un.UserId IS NULL THEN 'U'  
           WHEN NOT GroupName IS NULL THEN 'G'
           ELSE ''
      END
      + '~' +       
       COALESCE(un.WorkStationLogin, LTRIM(STR(UserId)), GroupName, '') + '~' + aa.ObjectName1
  FROM AccountAuthorizations aa 
  LEFT JOIN GroupNames gn ON gn.Groupid = aa.id AND aa.userflag = 0 
  LEFT JOIN UserNames un ON aa.id = un.userid AND aa.userflag = 1
  OUTER APPLY (SELECT TOP 1 RowPointer FROM AccountAuthorizations WHERE ObjectName1 = aa.ObjectName1 AND objecttype = 0
               AND ((id = gn.Groupid AND userflag = 0) OR (id = un.userid AND userflag = 1))
  ) ac
  WHERE NOT (gn.groupid is null 
             and un.userid is null)
                       
go
