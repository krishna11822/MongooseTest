SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON 
GO

IF object_id('dbo.ReservedTableAndViewNamesView') IS NOT NULL
   DROP VIEW dbo.ReservedTableAndViewNamesView
GO
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/ReservedTableAndViewNamesView.sql 1     9/17/15 10:18a Gmalakar */
/*
 *
 * CoreDev 1 RS7212 Gmalakar Thu Sep 17 10:18:36 2015
 * RS 7212
 *
 * $NoKeywords: $
 */
CREATE VIEW dbo.ReservedTableAndViewNamesView
AS
	SELECT AO.name AS Name, SC.name AS [Schema]
	FROM [sys].[all_objects] AO INNER JOIN [sys].[schemas] SC
	ON AO.schema_id = SC.schema_id
	WHERE TYPE in ('U', 'V')
	UNION 
	SELECT ViewName as Name, N'dbo' AS [Schema]
	FROM IdoLinkedTable

GO
