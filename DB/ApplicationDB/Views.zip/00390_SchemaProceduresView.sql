SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

IF EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SchemaProceduresView]'))
DROP VIEW [dbo].[SchemaProceduresView]
GO
-- =================================================================================
-- Stored Procedure: SchemaProceduresView
-- This view retrieves user stored procedure information for the current database.
-- The data is retrieved from the INFORMATION_SCHEMA.ROUTINES system view and is
-- filtered to exclude user-defined functions.
-- =================================================================================
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/SchemaProceduresView.sql 6     3/08/10 9:03a Dahn $ */

/*

***************************************************************

*                                                             *

*                           NOTICE                            *

*                                                             *

*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *

*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *

*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *

*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *

*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *

*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *

*   ALL OTHER RIGHTS RESERVED.                                *

*                                                             *

*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *

*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *

*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *

*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *

*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *

*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *

*                                                             *

***************************************************************

*/

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/SchemaProceduresView.sql $
 *
 * CoreDev 6 rs4588 Dahn Mon Mar 08 09:03:20 2010
 * rs4588 copyright header changes.
 *
 * CoreDev 5 rs3953 Dahn Tue Aug 26 15:51:57 2008
 * changing copyright header (rs3953)
 *
 * $NoKeywords: $
 */
CREATE VIEW [dbo].[SchemaProceduresView]
AS
SELECT [ROUTINE_NAME]
FROM [INFORMATION_SCHEMA].[ROUTINES]
WHERE [ROUTINE_TYPE] = 'PROCEDURE'
GO
