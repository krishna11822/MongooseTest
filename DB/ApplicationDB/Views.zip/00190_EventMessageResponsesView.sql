SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON 
GO

IF object_id('dbo.EventMessageResponsesView') IS NOT NULL
   DROP VIEW dbo.EventMessageResponsesView
GO
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/EventMessageResponsesView.sql 9     8/17/16 10:50a Nthurn $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2016 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/
/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/EventMessageResponsesView.sql $
 *
 * CoreDev 9 215775 Nthurn Wed Aug 17 10:50:02 2016
 * AES: Votes submitted after reminder email are submitted as null rather than selected choice.
 * Ignore Reminder messages.  (Issue 215775)
 *
 * CoreDev 8 project Nthurn Tue Mar 20 18:58:39 2012
 * Also return Choices.  (RS5085)
 *
 * CoreDev 6 115752 Nthurn Tue Jan 13 09:04:21 2009
 * If I save a copy of a Prompt to myself, then Vote, the suspended update does not unsuspend (regardless of whether the choice was positive or negative)
 * Ignore Saved Messages.  (Issue 115752)
 *
 * $NoKeywords: $
 */
CREATE VIEW EventMessageResponsesView
AS
SELECT
   ehs.RowPointer as EventHandlerStateRowPointer,
   ea.Sequence,
   Username,
   SelectedChoice,
   ResponseDate,
   ExpiresAfterDate,
   Choices
FROM EventHandlerState ehs
INNER JOIN EventActionState eas
   ON eas.EventHandlerStateRowPointer = ehs.RowPointer
INNER JOIN EventAction ea
   ON ea.RowPointer = eas.EventActionRowPointer
INNER JOIN EventMessage em
   ON em.EventActionStateRowPointer = eas.RowPointer
INNER JOIN Usernames u
   ON u.Userid = em.Userid
-- Ignore (Unvotable) Originator's Saved Message copy:
WHERE em.IsSavedMessage = 0
-- Ignore Reminder messages:
AND em.Choices IS NOT NULL
-- Just the "last" Votable EventMessage group for this EventAction:
AND NOT EXISTS(SELECT 1 FROM EventMessage em2
   WHERE em2.EventActionStateRowPointer = eas.RowPointer
   AND em2.IsSavedMessage = 0
   AND em2.Choices IS NOT NULL 
   AND em2.CreateDate > em.CreateDate)


GO
