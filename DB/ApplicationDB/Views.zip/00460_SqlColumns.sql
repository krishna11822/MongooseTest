SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

IF EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SqlColumns]'))
DROP VIEW [dbo].[SqlColumns]
GO
-- =================================================================================
-- View: SqlColumns
-- This view retrieves column information for the current database.
-- =================================================================================
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/SqlColumns.sql 5     8/09/13 5:29p Djohnson $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/SqlColumns.sql $
 *
 * CoreDev 5 166807 Djohnson Fri Aug 09 17:29:27 2013
 * Varbinary types on the SQL Columns form show no length
 * Issue #166807 - return lengths for binary and varbinary types.
 *
 * CoreDev 4 128675 Mewing Tue Apr 27 18:10:35 2010
 * COPYRIGHT UPDATE
 *
 * CoreDev 3 RS4458 Bpettit Fri Mar 26 13:18:28 2010
 * RS4458- Add Table Editor Forms
 *
 * CoreDev 1 RS4458 Rvannett Mon Mar 08 14:31:20 2010
 *
 * $NoKeywords: $
 */
CREATE VIEW [dbo].[SqlColumns]
AS
SELECT
  t.TABLE_NAME                   AS table_name_key
, c.COLUMN_NAME                  AS column_name_key
, t.TABLE_NAME                   AS table_name
, c.TABLE_SCHEMA                 AS table_schema
, c.COLUMN_NAME                  AS column_name
, c.DATA_TYPE                    AS system_data_type
, ISNULL(DOMAIN_NAME, DATA_TYPE) AS data_type
, CASE
   WHEN c.DATA_TYPE IN (N'text', N'char', N'varchar', N'sysname') THEN CHARACTER_MAXIMUM_LENGTH
   WHEN c.DATA_TYPE IN (N'ntext', N'nchar', N'nvarchar', N'binary', N'varbinary')          THEN CHARACTER_MAXIMUM_LENGTH
   WHEN c.DATA_TYPE IN (N'numeric', N'decimal')                   THEN NUMERIC_PRECISION
   ELSE NULL
 END                             AS DataLength
, CASE
   WHEN c.DATA_TYPE IN (N'numeric', N'decimal') THEN NUMERIC_SCALE
   ELSE NULL
 END                             AS DecimalPos
,c.is_nullable
,CASE 
  WHEN c.COLUMN_DEFAULT    like '(%)' 
  THEN SUBSTRING(c.COLUMN_DEFAULT, 2, LEN(CAST(c.COLUMN_DEFAULT AS nvarchar(max)))-2)
  ELSE c.COLUMN_DEFAULT  
END         AS column_default
,con.ORDINAL_POSITION  AS primary_key_position
,CASE 
  WHEN con.CONSTRAINT_NAME IS NULL
  THEN NULL
  ELSE INDEXPROPERTY(OBJECT_ID(c.TABLE_SCHEMA + '.' + c.TABLE_NAME),con.CONSTRAINT_NAME,'IsClustered')
END                              AS pk_is_clustered
FROM INFORMATION_SCHEMA.COLUMNS c 
   INNER JOIN INFORMATION_SCHEMA.TABLES t ON c.TABLE_NAME = t.TABLE_NAME and c.TABLE_SCHEMA = t.TABLE_SCHEMA
   LEFT OUTER JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS pk ON CONSTRAINT_TYPE = 'PRIMARY KEY' and pk.TABLE_NAME = t.TABLE_NAME
   LEFT OUTER JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE con on con.CONSTRAINT_NAME = pk.CONSTRAINT_NAME and con.TABLE_NAME = pk.TABLE_NAME and con.COLUMN_NAME = c.COLUMN_NAME
WHERE t.TABLE_TYPE = 'BASE TABLE'

