IF OBJECT_ID(N'EventCurrentPromptResultsView') IS NOT NULL
   DROP VIEW EventCurrentPromptResultsView
GO

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/EventCurrentPromptResultsView.sql $
 *
 * CoreDev 1 project Nthurn Tue Mar 20 19:04:55 2012
 * Shows summarized information about each choice on current Prompts.
 *
 * $NoKeywords: $
 */
CREATE VIEW EventCurrentPromptResultsView
AS
WITH EventCurrentPromptResponses (
   EventName,
   EventRevision,
   EventStateRowPointer,
   HandlerSequence,
   EventHandlerStateRowPointer,
   ActionSequence,
   Iteration,
   SentDate,
   ResponseDate,
   MessageRecipientList,
   Subject,
   Question,
   Choices,
   VotingRule,
   PreferredChoice,
   VotingMinimum,
   Voters,
   Quorum,
   VotingOpen,
   VotesCounted,
   Voted,
   SelectedChoice
   )
AS (
   SELECT
   EventName,
   EventRevision,
   EventStateRowPointer,
   HandlerSequence,
   EventHandlerStateRowPointer,
   ActionSequence,
   Iteration,
   SentDate,
   ResponseDate,
   MessageRecipientList,
   Subject,
   Question,
   Choices,
   VotingRule,
   PreferredChoice,
   VotingMinimum,
   Voters,
   Quorum,
   VotingOpen,
   VotesCounted,
   Voted,
   SelectedChoice
   FROM EventCurrentPromptResponsesView cpr
   )
SELECT
   EventName,
   EventRevision,
   cpr.EventStateRowPointer,
   cpr.HandlerSequence,
   cpr.EventHandlerStateRowPointer,
   cpr.ActionSequence,
   Iteration,
   SentDate,
   -- We don't worry too much about the execution time of dbo.GetSiteDate(), because:
   -- This view is meant to be restricted to a single EventStateRowPointer.
   DATEDIFF(SECOND, SentDate, CASE VotingOpen WHEN 1 THEN dbo.GetSiteDate(GETDATE())
      ELSE ISNULL(MAX(ResponseDate), (SELECT MAX(ResponseDate) FROM EventCurrentPromptResponses others
         WHERE others.EventStateRowPointer = cpr.EventStateRowPointer
         AND others.EventHandlerStateRowPointer = cpr.EventHandlerStateRowPointer))
      END) AS VotingTimeSeconds,
   DATEDIFF(SECOND, SentDate, CASE VotingOpen WHEN 1 THEN dbo.GetSiteDate(GETDATE())
      ELSE ISNULL(MAX(ResponseDate), (SELECT MAX(ResponseDate) FROM EventCurrentPromptResponses others
         WHERE others.EventStateRowPointer = cpr.EventStateRowPointer
         AND others.EventHandlerStateRowPointer = cpr.EventHandlerStateRowPointer))
      END) / 86400 AS VotingTimeDays,
   DATEDIFF(SECOND, SentDate, CASE VotingOpen WHEN 1 THEN dbo.GetSiteDate(GETDATE())
      ELSE ISNULL(MAX(ResponseDate), (SELECT MAX(ResponseDate) FROM EventCurrentPromptResponses others
         WHERE others.EventStateRowPointer = cpr.EventStateRowPointer
         AND others.EventHandlerStateRowPointer = cpr.EventHandlerStateRowPointer))
      END) % 86400 AS VotingTimeSecondsUnder1Day,
   DATEADD(SECOND, DATEDIFF(SECOND, SentDate, CASE VotingOpen WHEN 1 THEN dbo.GetSiteDate(GETDATE())
      ELSE ISNULL(MAX(ResponseDate), (SELECT MAX(ResponseDate) FROM EventCurrentPromptResponses others
         WHERE others.EventStateRowPointer = cpr.EventStateRowPointer
         AND others.EventHandlerStateRowPointer = cpr.EventHandlerStateRowPointer))
      END) % 86400, '1900-01-01') AS VotingTimeUnder1Day,
   CONVERT(NVARCHAR(8), DATEADD(SECOND, DATEDIFF(SECOND, SentDate, CASE VotingOpen WHEN 1 THEN dbo.GetSiteDate(GETDATE())
      ELSE ISNULL(MAX(ResponseDate), (SELECT MAX(ResponseDate) FROM EventCurrentPromptResponses others
         WHERE others.EventStateRowPointer = cpr.EventStateRowPointer
         AND others.EventHandlerStateRowPointer = cpr.EventHandlerStateRowPointer))
      END) % 86400, '1900-01-01'), 108) AS VotingTimeUnder1DayString,
   CASE VotingOpen WHEN 1 THEN DATEDIFF(SECOND, ISNULL(MAX(ResponseDate), SentDate), dbo.GetSiteDate(GETDATE())) ELSE NULL END AS IdleTimeSeconds,
   CASE VotingOpen WHEN 1 THEN DATEDIFF(SECOND, ISNULL(MAX(ResponseDate), SentDate), dbo.GetSiteDate(GETDATE())) / 86400 ELSE NULL END AS IdleTimeDays,
   CASE VotingOpen WHEN 1 THEN DATEDIFF(SECOND, ISNULL(MAX(ResponseDate), SentDate), dbo.GetSiteDate(GETDATE())) % 86400 ELSE NULL END AS IdleTimeSecondsUnder1Day,
   CASE VotingOpen WHEN 1 THEN DATEADD(SECOND, DATEDIFF(SECOND, ISNULL(MAX(ResponseDate), SentDate), dbo.GetSiteDate(GETDATE())) % 86400, '1900-01-01') ELSE NULL END AS IdleTimeUnder1Day,
   CASE VotingOpen WHEN 1 THEN CONVERT(NVARCHAR(8), DATEADD(SECOND, DATEDIFF(SECOND, ISNULL(MAX(ResponseDate), SentDate), dbo.GetSiteDate(GETDATE())) % 86400, '1900-01-01'), 108) ELSE NULL END AS IdleTimeUnder1DayString,
   MessageRecipientList,
   Subject,
   Question,
   cpr.Choices,
   VotingRule,
   PreferredChoice,
   VotingMinimum,
   Voters,
   Quorum,
   VotingOpen,
   VotesCounted,
   CASE WHEN VotesCounted < Quorum THEN (Quorum - VotesCounted) ELSE 0 END AS VotesUntilQuorum,
   SelectedChoice AS Choice,
   CASE dbo.LookupTrimmed(SelectedChoice, cpr.Choices, N',') WHEN 0 THEN NULL ELSE N'FORMAT(' + LTRIM(RTRIM(dbo.Entry(1 + dbo.LookupTrimmed(SelectedChoice, cpr.Choices, N','), cpr.Choices, N','))) + N')' END AS FormattedChoice,
   CASE WHEN SelectedChoice IS NULL THEN 0 ELSE /*COUNT(*)*/ SUM(Voted) END AS Votes,
   tally.Result,
   CASE WHEN tally.FormattedResult = N'' THEN NULL ELSE N'FORMAT(' + tally.FormattedResult + N')' END AS FormattedResult,
   tally.Votes as Votes2,
   tally.FrontRunner,
   tally.Tied,
   tally.Margin,
   tally.VotesToWin,
   tally.Status
FROM EventCurrentPromptResponses cpr
LEFT OUTER JOIN EventCurrentPromptVotingTallyView tally
   ON tally.EventStateRowPointer = cpr.EventStateRowPointer
   AND tally.EventHandlerStateRowPointer = cpr.EventHandlerStateRowPointer
   AND tally.Choice = ISNULL(cpr.SelectedChoice, N'')
GROUP BY
   cpr.EventName,
   cpr.EventRevision,
   cpr.EventStateRowPointer,
   cpr.HandlerSequence,
   cpr.EventHandlerStateRowPointer,
   cpr.ActionSequence,
   cpr.Iteration,
   cpr.SentDate,
   cpr.MessageRecipientList,
   cpr.Subject,
   cpr.Question,
   cpr.Choices,
   cpr.VotingRule,
   cpr.PreferredChoice,
   cpr.VotingMinimum,
   cpr.Voters,
   cpr.Quorum,
   cpr.VotingOpen,
   cpr.VotesCounted,
   cpr.SelectedChoice,
   tally.Result,
   tally.FormattedResult,
   tally.Votes,
   tally.FrontRunner,
   tally.Tied,
   tally.Margin,
   tally.VotesToWin,
   tally.Status

GO

/** Testing:
select dbo.Lookup('SelectedChoice', 'Choices', N',')

select dbo.EventAssemblyFileVersion()
select * from eventstate where rowpointer = '45FF4B7B-23F8-4C02-9726-2D05C0F044C6'

SELECT * FROM EventCurrentPromptResultsView
WHERE eventhandlerstaterowpointer in (
--N'bdb5cc30-1c2e-4ea2-a681-7167f4febc16' 
--,'E9ACC146-7377-41EB-90E7-4E8941711AD2'
--,'7CA5BC37-1B5A-4456-8DF6-3F322DFF72DE'
--,'7C8D4A3D-BFA5-418E-82D2-1C6A877E6E27'
--,'28FBB523-66FB-4D43-BE0A-AB85834378CE'
--,'03BF8F49-A794-46E2-9777-1A48D138EE04'
--,'EAAAF641-C332-457D-8F03-B4ACB391F38C'
--,
'F43BB47D-6F59-4ADD-9689-F05351652605'
--,'5216E85C-A4C7-4C91-B4ED-4A162C3C7CBB'
--,'C357AADF-DBB5-434D-A0E7-82DEAA2BC37A'
)


SELECT SentDate, MaxResponseDate
   --TOP 200 cps.ActionSequence [ActionSequence], cps.HandlerSequence [HandlerSequence], cps.EventStateRowPointer [EventStateRowPointer], cps.Iteration [Iteration], cps.SentDate [SentDate], cps.VotingTimeDays [VotingTimeDays], cps.VotingTimeUnder1DayString [VotingTimeUnder1DayString], cps.IdleTimeDays [IdleTimeDays], cps.IdleTimeUnder1DayString [IdleTimeUnder1DayString], cps.Subject [Subject], cps.VotingOpen [VotingOpen], cps.Voters [Voters], cps.VotesCounted [VotesCounted], cps.VotesUntilQuorum [VotesUntilQuorum]
--FROM EventCurrentPromptSummaryView cps
FROM EventCurrentPromptResultsView cps
WHERE cps.EventStateRowPointer= N'0d0abed9-1c07-429e-a035-3b467b2f9e02' 
--ORDER BY cps.EventStateRowPointer, cps.HandlerSequence, cps.ActionSequence
 **/

