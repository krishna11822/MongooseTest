SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[JSONSchemaView]'))
DROP VIEW [dbo].[JSONSchemaView]
GO

/* $Header: /Tools/SQLScripts/ApplicationDB/Views/JSONSchemaView.sql 1     3/12/18 2:35p johndou $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/ESBSecurityRoleMasterView.sql $
 * CoreDev 3 252144 Djohnson Tue Apr 30 2019
 * Prefix added to table name.
 *
 * CoreDev 2 RS8716 Djohnson Mon Mar 25 2019
 * Table prefixes for datalake
 *
 * CoreDev 1 RS8189 johndou Mar 12 14:35:10 2018
*/
CREATE VIEW [dbo].[JSONSchemaView]
AS
SELECT ISNULL(dbo.SystemProcessDefaults.DefaultValue, N'Mongoose') + cc.TABLE_NAME AS TableName, 
cc.COLUMN_NAME AS ColumnName, 
CASE WHEN data_type IN ('nvarchar', 'nchar', 'varchar', 'char', 'text', 'ntext', 'binary', 'varbinary', 'image', 'uniqueidentifier'
, 'datetime', 'datetime2', 'smalldatetime',
'datetimeoffset', 'date', 'time', 'timestamp', 'XML') THEN 'string'
WHEN data_type = 'bit' THEN 'boolean'
WHEN data_type in ('decimal', 'numeric', 'float', 'real', 'money', 'smallmoney') THEN 'number'
WHEN data_type in ('int', 'smallint', 'tinyint', 'bigint') THEN 'integer'
END AS DataType,
CASE WHEN data_type = 'bigint' THEN -9223372036854775808
WHEN data_type = 'int' THEN -2147483648
WHEN data_type = 'smallint' THEN -32768
WHEN data_type = 'tinyint' THEN 0
END AS MinimumValue
, CASE WHEN data_type = 'bigint' THEN N'9223372036854775807'
WHEN data_type = 'int' THEN N'2147483647'
WHEN data_type = 'smallint' THEN N'32767'
WHEN data_type = 'tinyint' THEN N'255'
WHEN data_type in ('nvarchar', 'nchar', 'varchar', 'char', 'varbinary') THEN
CASE WHEN character_maximum_length = -1 THEN N'2147483647'
ELSE CAST(character_maximum_length AS SYSNAME)
END
WHEN data_type = 'uniqueidentifier' THEN N'36'
WHEN data_type in ('decimal', 'numeric', 'float', 'real', 'money', 'smallmoney') THEN 
CASE WHEN numeric_precision = numeric_scale THEN N'1.0'
ELSE replicate('9', numeric_precision - numeric_scale)
END
END AS MaximumValue,
CASE WHEN data_type in ('datetime', 'datetime2', 'smalldatetime') THEN 'date-time' -- 2017-07-04T14:08:43.123Z
WHEN data_type in ('date') THEN 'date' -- 2017-07-04
WHEN data_type in ('time') THEN 'time'
END AS FormatString,
CASE WHEN IS_NULLABLE = 'NO' THEN 1 ELSE 0 END AS IsRequired
, CASE WHEN data_type in ('decimal', 'numeric', 'float', 'real', 'money', 'smallmoney') THEN CAST(POWER(convert(float, 10), -1 * NUMERIC_SCALE) AS NUMERIC(38,28))
ELSE NULL END AS MultipleOf,
CASE when isk.COLUMN_NAME IS NOT NULL THEN 1 ELSE 0 END AS IsPrimaryKey,
isk.ORDINAL_POSITION AS OrdinalPosition
FROM Information_schema.columns cc
LEFT OUTER JOIN information_schema.table_constraints AS ist ON
  ist.table_name = cc.table_name  
AND ist.constraint_type = 'PRIMARY KEY'
LEFT OUTER JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE isk ON
isk.table_name = cc.table_name
and isk.TABLE_SCHEMA = cc.TABLE_SCHEMA
and isk.COLUMN_NAME = cc.COLUMN_NAME
AND ist.constraint_name = isk.constraint_name
LEFT OUTER JOIN SystemProcessDefaults ON
DefaultType = 71