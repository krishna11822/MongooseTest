SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

IF OBJECT_ID('dbo.BusElementsView') IS NOT NULL
   DROP VIEW dbo.BusElementsView
GO

/* $Header: /Tools/SQLScripts/ApplicationDB/Views/BusElementsView.sql 8     3/08/10 9:03a Dahn $ */

/*

***************************************************************

*                                                             *

*                           NOTICE                            *

*                                                             *

*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *

*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *

*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *

*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *

*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *

*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *

*   ALL OTHER RIGHTS RESERVED.                                *

*                                                             *

*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *

*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *

*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *

*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *

*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *

*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *

*                                                             *

***************************************************************

*/

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/BusElementsView.sql $
 *
 * CoreDev 8 rs4588 Dahn Mon Mar 08 09:03:09 2010
 * rs4588 copyright header changes.
 *
 * CoreDev 7 118032 Djohnson Tue Apr 21 15:42:25 2009
 * On BODs with null elements suppress the element in the BOD
 * Issue #118032 - , rde.ExclusionPropertyName
 *
 * CoreDev 6 116691 Djohnson Mon Jan 12 17:55:37 2009
 * Empty elements should not send attributes
 * Issue #116691 - Added the new ReplDocAttribute IncludeForNullValuedElement column to the view.
 *
 * CoreDev 5 113676 Djohnson Wed Sep 17 14:35:28 2008
 * Support sub-collections in the MGBUS where there is no sub-collection property
 * Issue #113676 - Added the new DynamicSubcollectionIDOName column to the view.
 *
 * CoreDev 4 rs3953 Dahn Tue Aug 26 15:51:53 2008
 * changing copyright header (rs3953)
 *
 * CoreDev 3 109521 Djohnson Thu Jun 05 09:54:27 2008
 * A new keyword is being added NIDID to BOD building.
 * Issue #109521 - IsDocumentId is being removed from the ReplDocElement table, so this view had to quit using it.
 *
 * CoreDev 2 RS4033 Djohnson Fri May 09 12:34:06 2008
 * RS4033 - Removed the unused BODHeaderName column which was coming from the ReplDocElement table.
 *
 * CoreDev 1 RS4033 Djohnson Fri May 02 16:58:29 2008
 * RS4033 - a view to retrieve element and attribute information for bus documents.
 *
 * $NoKeywords: $
 */
CREATE VIEW dbo.BusElementsView
AS
SELECT
  rde.DocumentName
, rde.ElementSequence
, rde.IDOPropertyName
, rde.BODTagName
, rde.ValueSourceType
, rde.ValueExpression
, 0 AS IsDocumentID -- rde.IsDocumentID
, rde.IsToLogicalId
, rde.SubColLinkBy
, rde.SubColFilter
, rde.SubColCustomLoadMethod
, rde.SubColInsUpdDelOverride
, rde.ExclusionPropertyName
, rde.DynamicSubcollectionIDOName
, rda.AttributeName
, rda.ValueSourceType AS AttributeValueType
, rda.ValueExpression AS AttributeExpression
, rda.IDOPropertyName AS AttributePropertyName
, rda.IncludeForNullValuedElement AS IncludeForNullValuedElement
FROM ReplDocElement rde
LEFT OUTER JOIN ReplDocAttribute rda ON
  rda.DocumentName = rde.DocumentName
AND rda.ElementRowPointer = rde.RowPointer

GO

