SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

IF OBJECT_ID('dbo.MyEventMessagesView') IS NOT NULL
   DROP VIEW dbo.MyEventMessagesView
GO

/* $Header: /Tools/SQLScripts/ApplicationDB/Views/MyEventMessagesView.sql 6     5/12/17 2:47p Nthurn $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2017 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/
/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/MyEventMessagesView.sql $
 *
 * CoreDev 6 143111 Nthurn Fri May 12 14:47:26 2017
 * Improved performance of current UserName retrieval.  (Issue 143111)
 *
 * CoreDev 4 RS4455 Nthurn Tue Feb 09 15:53:35 2010
 * Also return Category.  (RS4455)
 *
 * $NoKeywords: $
 */
CREATE VIEW dbo.MyEventMessagesView
AS
   SELECT
      em.Userid,
      em.FolderName,
      eas.EventHandlerStateRowPointer,
      em.FromUser,
      em.ToUserList,
      em.CcUserList,
      em.SentDate,
      em.Category,
      em.Subject,
      em.Message,
      em.Question,
      em.Choices,
      em.HasBeenRead,
      em.ExpiresAfterDate,
      em.SelectedChoice,
      em.ResponseDate,
      em.NoteExistsFlag,
      em.CreatedBy,
      em.UpdatedBy,
      em.CreateDate,
      em.RecordDate,
      em.RowPointer,
      em.InWorkflow,
      CASE WHEN dbo.GetSiteDate(getdate()) > em.ExpiresAfterDate THEN 1 ELSE 0 END
         as Expired,
      -- Allow setting the "Read" checkbox on un-Read Messages:
      em.HasBeenRead as ReadOnlyRecord,
      ea.RowPointer as EventActionRowPointer,
      ea.ActionType,
      ea.EventHandlerRowPointer,
      CASE WHEN EXISTS(SELECT 1
         -- Inner Joins copied from CLM_MyEventMessageVariablesSp:
         FROM EventVariable ev
         -- Could be multiple of these, but we'll restrict later by looking at only our EventMessage:
         INNER JOIN EventActionState eas ON eas.EventHandlerStateRowPointer = ev.EventHandlerStateRowPointer
         INNER JOIN EventHandlerState ehs ON ehs.RowPointer = eas.EventHandlerStateRowPointer
         INNER JOIN EventAction ea ON ea.RowPointer = eas.EventActionRowPointer
         INNER JOIN EventHandlerRevision eh ON 
              eh.RowPointer = ea.EventHandlerRowPointer
         WHERE eas.RowPointer = em.EventActionStateRowPointer)
         THEN 1 ELSE 0 END AS HasVariables,
      em.FolderName AS OrigFolderName
   FROM EventMessage em
   INNER JOIN UserNameView u ON 1=1
   INNER JOIN Usernames
      ON Usernames.Userid = em.Userid
      AND Usernames.Username = u.Username
   LEFT OUTER JOIN EventActionState eas
      ON eas.RowPointer = em.EventActionStateRowPointer
   LEFT OUTER JOIN EventAction ea
      ON ea.RowPointer = eas.EventActionRowPointer
--    INNER JOIN EventHandlerState ehs
--       ON ehs.RowPointer = eas.EventHandlerStateRowPointer
--    INNER JOIN EventState es
--       ON es.RowPointer = ehs.EventStateRowPointer

GO

