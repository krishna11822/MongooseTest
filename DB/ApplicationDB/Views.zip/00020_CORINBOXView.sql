SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('dbo.CORINBOXView') IS NOT NULL
    DROP VIEW [dbo].[CORINBOXView]
GO

/* $Header: /Tools/SQLScripts/ApplicationDB/Views/CORINBOXView.sql 1     3/05/14 3:09p Djackson1 $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/
/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/CORINBOXView.sql $
 *
 * CoreDev 1 rs6716 Djackson1 Wed Mar 05 15:09:23 2014
 * RS 6716
 *
 * 03/06/2020 - dartiaga - Issue 260253: added row pointer
 *
 */
CREATE VIEW [dbo].[CORINBOXView]
AS

SELECT 
      CId
      ,CVerb
      ,CNoun
      ,CTenantId 
      ,CToLogicalId 
      ,CFromLogicalId 
      ,CWasProcessed 
      ,CCreatedDateTime
      ,CMessagePriority
      ,CXml 
      ,CLogicalId
      ,RowPointer
FROM
  (SELECT 
      Cid
      ,CVerb
      ,CNoun 
      ,CTenantId
      ,CToLogicalId 
      ,CFromLogicalId 
      ,CWasProcessed 
      ,CCreatedDateTime
      ,CMessagePriority
      ,CXml 
      ,CLogicalId
      ,RowPointer
   FROM
   (SELECT  
        CId = C_INBOX_ID 
      , BODType
      , CTenantId = C_TENANT_ID 
      , CVerb = SUBSTRING(BODType,0,CHARINDEX('.',BODType,0))
      , CNoun = SUBSTRING(BODType,CHARINDEX('.',BODType,0)+ 1, LEN(BODType))
      , CToLogicalId = ToLogicalId
      , CFromLogicalId =FromLogicalId
      , CWasProcessed = coe.C_WAS_PROCESSED
      , CCreatedDateTime = C_CREATED_DATE_TIME  
      , CMessagePriority = coe.C_MESSAGE_PRIORITY
      , CXml = coe.C_XML
      , CLogicalId = coe.C_LOGICAL_ID
      , RowPointer = coe.RowPointer
    FROM  
    (SELECT C_HEADER_KEY ,C_INBOX_ID,  C_HEADER_VALUE  
       FROM [COR_INBOX_HEADERS]) P
     PIVOT
    (
     max(C_header_value) 
     FOR C_HEADER_KEY IN ([BODType], ToLogicalId, FromLogicalId)
    ) as pvt
  JOIN COR_INBOX_ENTRY coe ON coe.C_ID = PVT.C_INBOX_ID 
  ) repldat
) TB

GO
