SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

IF EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SqlTables]'))
DROP VIEW [dbo].[SqlTables]
GO
-- =================================================================================
-- View: SqlTables
-- This view retrieves user table information for the current database.
-- Data is retrieved from sys.tables and excludes some internal-use-only tables.
-- =================================================================================
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/SqlTables.sql 6     9/17/13 9:02a Pgross $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/
/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/SqlTables.sql $
 *
 * CoreDev 6 164271 Pgross Tue Sep 17 09:02:16 2013
 * replaced tt restriction with a call to IsAppHandledRestrictedTable
 *
 * CoreDev 5 133618 Bpettit Tue Oct 19 15:02:29 2010
 * Changes for RS4900 are not in installed code
 * 133618
 *
 * CoreDev 4 RS4900 Bpettit Thu Jul 22 16:31:47 2010
 * RS4900
 *
 * CoreDev 3 128675 Mewing Tue Apr 27 18:10:35 2010
 * COPYRIGHT UPDATE
 *
 * CoreDev 2 RS4458 Bpettit Fri Mar 26 13:20:07 2010
 * RS4458- Add Table Editor Forms
 *
 * CoreDev 1 RS4458 Rvannett Mon Mar 08 14:31:04 2010
 *
 * $NoKeywords: $
 */
CREATE VIEW [dbo].[SqlTables]
AS
SELECT
  t.name AS table_name
, t.object_id
, SCHEMA_NAME(t.schema_id) AS table_schema
,CASE 
  WHEN pk.CONSTRAINT_NAME IS NULL
  THEN 0
  ELSE INDEXPROPERTY(OBJECT_ID(pk.TABLE_SCHEMA + '.' + pk.TABLE_NAME),pk.CONSTRAINT_NAME,'IsClustered'
)
END                              AS pk_is_clustered
,CASE 
  WHEN 
  exists (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS c 
  WHERE c.TABLE_NAME = t.name AND c.TABLE_SCHEMA = SCHEMA_NAME(t.schema_id)
  AND c.COLUMN_NAME = 'RowPointer')
  and exists
  (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS c 
  WHERE c.TABLE_NAME = t.name AND c.TABLE_SCHEMA = SCHEMA_NAME(t.schema_id)
  AND c.COLUMN_NAME = 'RecordDate')
    and exists
  (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS c 
  WHERE c.TABLE_NAME = t.name AND c.TABLE_SCHEMA = SCHEMA_NAME(t.schema_id)
  AND c.COLUMN_NAME = 'UpdatedBy')
  THEN 1
  ELSE 0
END AS framework_rows_exist
FROM sys.tables t
LEFT OUTER JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS pk ON CONSTRAINT_TYPE = 'PRIMARY KEY' and pk.TABLE_NAME = t.name
WHERE name != 'dtproperties'
  AND name NOT LIKE '%[_]committed'
  AND name NOT LIKE '%[_]impacted'
  AND name NOT LIKE '%[_]dd'
  AND name NOT LIKE '%[_]ii'
  and dbo.IsAppHandledRestrictedTable(name) = 0
GO
