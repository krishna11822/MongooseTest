SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

IF OBJECT_ID('dbo.ODTView') IS NOT NULL
   DROP VIEW dbo.ODTView
GO

/* $Header: /Tools/SQLScripts/ApplicationDB/Views/ODTView.sql 1     4/09/10 5:02p Djohnson $ */

/*

***************************************************************

*                                                             *

*                           NOTICE                            *

*                                                             *

*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *

*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *

*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *

*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *

*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *

*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *

*   ALL OTHER RIGHTS RESERVED.                                *

*                                                             *

*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *

*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *

*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *

*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *

*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *

*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *

*                                                             *

***************************************************************

*/

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/ODTView.sql $
 *
 * CoreDev 1 128992 Djohnson Fri Apr 09 17:02:26 2010
 * Tree client does not work on Windows 7.
 * Issue #128992 - a new view used by the Tree2 client.
 *
 * $NoKeywords: $
 */

CREATE view ODTView (ParentObject, ParentType, ChildObject, ChildType)
as
select oo.ObjectName, ood.ParentType, oo2.ObjectName, ood.ChildType
FROM ODTObjectDepends as ood
inner join ODTObjects oo ON
  ood.ParentObjectID = oo.ObjectID
inner join ODTObjects oo2 on
  ood.ChildObjectID = oo2.ObjectID
GO
