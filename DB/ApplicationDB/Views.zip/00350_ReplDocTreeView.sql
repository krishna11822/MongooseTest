SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF exists (SELECT * FROM dbo.sysobjects
   WHERE id = object_id(N'[dbo].[ReplDocTreeView]')
      and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[ReplDocTreeView]
GO
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/ReplDocTreeView.sql 2     3/08/10 9:03a Dahn $ */

/*

***************************************************************

*                                                             *

*                           NOTICE                            *

*                                                             *

*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *

*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *

*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *

*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *

*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *

*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *

*   ALL OTHER RIGHTS RESERVED.                                *

*                                                             *

*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *

*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *

*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *

*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *

*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *

*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *

*                                                             *

***************************************************************

*/

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/ReplDocTreeView.sql $
 *
 * CoreDev 2 rs4588 Dahn Mon Mar 08 09:03:18 2010
 * rs4588 copyright header changes.
 *
 * CoreDev 1 RS4033 Dpalmer Wed Aug 27 11:44:38 2008
 * New View used by IDO ReplDocTreeViews and the BODTree component on ReplDocuments form.
 *
 *
 * $NoKeywords: $
 */


CREATE VIEW [dbo].[ReplDocTreeView]
AS
SELECT
   ElementSequence = ElementSequence ,
   ParentNode      = ParentNode      ,
   ChildNode       = ChildNode       ,
   NodeName        = NodeName        ,
   NodeLevel       = NodeLevel       ,  
   BodTagKey       = BodTagKey       ,
   IsAttribute     = IsAttribute     ,
   RecordDate      = (GETDATE())     ,
   CreateDate      = (GETDATE())     ,
   RowPointer      = RowPointer      ,
   CreatedBy       = (SUSER_SNAME()) ,
   UpdatedBy       = (SUSER_SNAME()) 

FROM dbo.GenerateBODTreeNodes(NULL) tt