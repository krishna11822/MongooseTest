if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[JobQueues]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[JobQueues]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/jobqueues.sql 2     3/08/10 9:03a Dahn $ */

/*

***************************************************************

*                                                             *

*                           NOTICE                            *

*                                                             *

*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *

*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *

*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *

*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *

*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *

*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *

*   ALL OTHER RIGHTS RESERVED.                                *

*                                                             *

*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *

*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *

*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *

*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *

*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *

*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *

*                                                             *

***************************************************************

*/

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/jobqueues.sql $
 *
 * CoreDev 2 rs4588 Dahn Mon Mar 08 09:03:16 2010
 * rs4588 copyright header changes.
 *
 * CoreDev 1 122170 tblosser Wed Jul 01 11:20:47 2009
 * Move WinStudio form BackgroundQueue from SL8.01 to Core601 environment.
 * Issue 122170
 *
 * Core601 1 122170 tblosser Tue Jun 30 16:52:31 2009
 * Move WinStudio form BackgroundQueue from SL8.01 to Core601 environment.
 * Issue 122170
 *
 *
 * $NoKeywords: $
 */
CREATE VIEW dbo.JobQueues
AS
SELECT     *
FROM         msdb.dbo.syscategories
WHERE     (category_class = 1) AND (category_type = 1)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO









































































