SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('dbo.COROUTBOXView') IS NOT NULL
    DROP VIEW [dbo].[COROUTBOXView]
GO

/* $Header: /Tools/SQLScripts/ApplicationDB/Views/COROUTBOXView.sql 1     3/05/14 3:09p Djackson1 $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/
/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/COROUTBOXView.sql $
 *
 * CoreDev 1 rs6716 Djackson1 Wed Mar 05 15:09:28 2014
 * RS 6716
 *
 */
CREATE VIEW [dbo].[COROUTBOXView]
AS

SELECT 
      CId
      ,CVerb
      ,CNoun
      ,CTenantId 
      ,CMediation 
      ,CToLogicalId 
      ,CFromLogicalId 
      ,CMessageId 
      ,CWasProcessed 
      ,CCreatedDateTime
      ,CMessagePriority
      ,CXml 
      ,CLogicalId
FROM
  (SELECT 
      Cid
      ,CVerb
      ,CNoun 
      ,CTenantId
      ,CMediation 
      ,CToLogicalId = ToLogicalId 
      ,CFromLogicalId = FromLogicalID 
      ,CMessageId = MessageID 
      ,CWasProcessed 
      ,CCreatedDateTime
      ,CMessagePriority
      ,CXml
      ,CLogicalId      
   FROM
   (SELECT  
        CId = C_OUTBOX_ID 
      , CMediation = [mediation.outbound] 
      , BODType
      , CVerb = SUBSTRING(BODType,0,CHARINDEX('.',BODType,0))
      , CNoun = SUBSTRING(BODType,CHARINDEX('.',BODType,0)+ 1, LEN(BODType))
      , CTenantId = C_TENANT_ID
      , ToLogicalId
      , FromLogicalId
      , MessageId
      , CWasProcessed = coe.C_WAS_PROCESSED
      , CCreatedDateTime =coe.C_CREATED_DATE_TIME
      , CMessagePriority = coe.C_MESSAGE_PRIORITY
      , CXml = coe.C_XML
      , CLogicalId = coe.C_LOGICAL_ID      
    FROM  
    (SELECT C_HEADER_KEY ,C_OUTBOX_ID,  C_HEADER_VALUE  
       FROM [COR_OUTBOX_HEADERS]) P
     PIVOT
    (
     max(C_header_value) 
     FOR C_HEADER_KEY IN ([mediation.outbound], [BODType], ToLogicalId, FromLogicalId,[Messageid])
    ) as pvt
  JOIN COR_OUTBOX_ENTRY coe ON coe.C_ID = PVT.C_OUTBOX_ID 
  ) repldat  
) TB
