SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON 
GO

IF object_id('dbo.JMSIntranetsView') IS NOT NULL
   DROP VIEW dbo.JMSIntranetsView
GO
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/JMSIntranetsView.sql 4     3/08/10 9:03a Dahn $ */

/*

***************************************************************

*                                                             *

*                           NOTICE                            *

*                                                             *

*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *

*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *

*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *

*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *

*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *

*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *

*   ALL OTHER RIGHTS RESERVED.                                *

*                                                             *

*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *

*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *

*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *

*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *

*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *

*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *

*                                                             *

***************************************************************

*/

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/JMSIntranetsView.sql $
 *
 * CoreDev 4 rs4588 Dahn Mon Mar 08 09:03:14 2010
 * rs4588 copyright header changes.
 *
 * CoreDev 3 rs3953 Dahn Tue Aug 26 15:51:55 2008
 * changing copyright header (rs3953)
 *
 * $NoKeywords: $
 */
CREATE VIEW JMSIntranetsView
AS
-- Return a list of JMS Intranets visible to (i.e. potentially communicable with) this Site,
-- along with the URL of the JMS Broker hosting the Infor Bus,
-- and the Username and Password which InboundBus.exe will use to connect to it.
SELECT /* TOP 1 */
   intranet_name,
   Url,
   SMTPUsername as Username,
   SMTPPassword as Password
FROM intranet
WHERE Transport = N'J'
-- If no rows are returned, InboundBus.exe has nothing to do!

GO
