SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON 
GO

IF object_id('dbo.UserNameView') IS NOT NULL
   DROP VIEW dbo.UserNameView
GO
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/UserNameView.sql 1     5/12/17 2:46p Nthurn $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2017 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/
/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/UserNameView.sql $
 *
 * CoreDev 1 143111 Nthurn Fri May 12 14:46:01 2017
 * IdoPropertyClassesView performance is non-optimal when retrieving all
 * Inline replacement for dbo.UserNameSp().
 *
 * $NoKeywords: $
 */
CREATE VIEW UserNameView
AS
-- Simulate dbo.UserNameSp() without the overhead of a function call:
-- WARNING! This algorithm is also encoded in dbo.UserNameBySessionId()
-- Please maintain in concert!
SELECT COALESCE(ci.ImpersonatingUserName, ci.UserName, scn.CreatedBy, SUSER_SNAME() )
   AS UserName
FROM parms
LEFT OUTER JOIN SessionContextNames scn WITH (NOLOCK)
   ON scn.ProcessID = @@spid
LEFT OUTER JOIN ConnectionInformation ci
   ON ci.ConnectionID = ISNULL(scn.SessionID, '00000000-0000-0000-0000-000000000000')
WHERE parm_key = 0
GO

-- Test:
--setsitesp 'LA', ''
--select * from UserNameView
