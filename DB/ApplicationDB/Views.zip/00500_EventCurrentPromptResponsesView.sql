IF OBJECT_ID(N'EventCurrentPromptResponsesView') IS NOT NULL
   DROP VIEW EventCurrentPromptResponsesView
GO

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/EventCurrentPromptResponsesView.sql $
 *
 * CoreDev 1 project Nthurn Tue Mar 20 19:04:29 2012
 * Shows information about votes and unvoted choices on current Prompts.
 *
 * $NoKeywords: $
 */
CREATE VIEW EventCurrentPromptResponsesView
AS
-- Votes & non-Votes (one row per Voter):
SELECT * FROM EventCurrentPromptVotersView

UNION ALL

-- Unvoted Choices (one row per Choice):
SELECT * FROM EventCurrentPromptUnvotedChoicesView

GO

/** Testing:
select top 25 votes.* from EventActionState eas
inner join EventAction ea on ea.rowpointer = eas.eventactionrowpointer
inner join EventCurrentPromptResponsesView votes on votes.EventHandlerStateRowPointer = eas.EventHandlerStateRowPointer
where ea.actiontype = dbo.eventactiontypecode('Prompt')
--and selectedchoice is null
and timesexecuted > 1
order by eas.CreateDate desc

declare @r datetime, @now datetime
set @r = '2011-11/06 16:28:28.277'
set @now = '2011-11-07 16:28:27.287'  --dbo.GetSiteDate(getdate())
select @r, @now, DATEDIFF(SECOND, @r, @now) AS [Total (s)]
   --, DATEDIFF(DAY, @r, @now) - 1 AS Days
   , DATEDIFF(SECOND, @r, @now) / 86400 AS Days
   , DATEDIFF(SECOND, @r, @now) % 86400 AS SecondsUnder1Day

select votes.* from EventCurrentPromptResponsesView votes
where eventhandlerstaterowpointer in
('E9ACC146-7377-41EB-90E7-4E8941711AD2'
,'7CA5BC37-1B5A-4456-8DF6-3F322DFF72DE'
,'7C8D4A3D-BFA5-418E-82D2-1C6A877E6E27'
,'28FBB523-66FB-4D43-BE0A-AB85834378CE'
,'03BF8F49-A794-46E2-9777-1A48D138EE04'
,'EAAAF641-C332-457D-8F03-B4ACB391F38C'
,'F43BB47D-6F59-4ADD-9689-F05351652605'
,'5216E85C-A4C7-4C91-B4ED-4A162C3C7CBB'
,'C357AADF-DBB5-434D-A0E7-82DEAA2BC37A')
order by 1,2,4,6,7,3,5
 **/
