SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON 
GO

IF object_id('dbo.DocumentObjectAndRefView') IS NOT NULL
   DROP VIEW dbo.DocumentObjectAndRefView
GO
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/DocumentObjectAndRefView.sql 17    1/29/16 12:35p Gmalakar $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2015 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/
/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/DocumentObjectAndRefView.sql $
 *
 * CoreDev 17 RS7561 Gmalakar Fri Jan 29 12:35:18 2016
 * RS7561 Phase 1
 *
 * CoreDev 16 199663 Rsantos Thu Jul 30 21:19:06 2015
 * Unable to Delete a link to an Attached Document that is InWorkflow(Related to issue142731)
 * 199663 Unable to Delete a link to an Attached Document that is InWorkflow(Related to issue142731)
 * Use InWorkflow column name
 *
 * CoreDev 15 142731 Rsantos Tue Jul 28 22:35:05 2015
 * Unable to Delete a link to an Attached Document that is InWorkflow
 * 142731 Unable to Delete a link to an Attached Document that is InWorkflow
 * �	Expose/Add DocumentObject.InWorkflow and DocumentObjectReference.InWorkflow columns to DocumentObjectAndRefView
 * �	Remove InWorkflow column
 *
 * CoreDev 14 190931 Nthurn Thu Feb 05 09:00:32 2015
 * Attaching a document to an Event Message does not enable the [View]/[Export] buttons when viewing the Attached Document from the Inbox form
 * Consider EventDocumentObject in DocumentExists expression.  (Issue 190931)
 *
 * CoreDev 13 RS6487 Gmalakar Mon Nov 24 11:17:41 2014
 * RS6487
 *
 * CoreDev 12 RS5354 Djohnson Thu Apr 05 11:54:50 2012
 * RS5354
 *
 * CoreDev 11 143932 Djohnson Wed Oct 19 13:53:46 2011
 * Newly Attached or Linked Documents during a Prompt disappear until Bequeath
 * Issue #143932 - rename the new event handler state rowpointer column and cast it as a guid.
 *
 * CoreDev 10 143932 Djohnson Tue Oct 18 17:15:48 2011
 * Newly Attached or Linked Documents during a Prompt disappear until Bequeath
 * Issue #143932 - add the event handler state rowpointer to the view for use by the form as a client input to the view trigger.
 *
 * CoreDev 9 143470 Djohnson Mon Oct 17 14:22:00 2011
 * Error updating a Suspended document from the Inbox
 * Issue #143470 - EventDoc is now needed as an output value from the view, not just input to the view triggers.
 *
 * CoreDev 8 rs5310 Nthurn Mon Sep 05 23:25:01 2011
 * Use DocumentObjectReference.InWorkflow to ascertain which EventState has control of an Attachment.
 *
 * CoreDev 7 RS5310 Djohnson Mon Sep 05 15:03:56 2011
 * RS5310 - Special Inbox/EventState InWOrkflow handling.
 *
 * CoreDev 6 RS5310 Djohnson Mon Aug 29 15:33:40 2011
 * RS5310 - The view now retrieves document data from either the DocumentObject or the EventDocumentObject table.
 *
 * CoreDev 5 RS5310 Djohnson Mon Aug 01 15:13:50 2011
 * Added MediaType column.
 *
 * CoreDev 4 RS5310 Djohnson Wed Jul 13 17:29:58 2011
 * RS5310 - added Suspend from DocumentObjectReference table.
 *
 * CoreDev 3 139784 Djohnson Thu Jul 07 12:54:14 2011
 * When a DocumentObjectReference.InWorkflow = 1, the row in Object Documents is not disabled
 * Issue #139784 - add an InWorkflow column that comes from either base table.
 *
 * CoreDev 2 139650 Djackson1 Thu Jun 23 10:06:58 2011
 * DocumentObjectReference.DocumentRowPointer is now DocumentObjectReference.DocumentObjectRowPointer
 * Issue 139650 - Naming - DocumentObjectRowPointer
 *
 * CoreDev 1 RS4521 Djohnson Mon May 23 11:46:08 2011
 * RS4521
 *
 * $NoKeywords: $
 */
CREATE VIEW dbo.DocumentObjectAndRefView
AS
SELECT
  dor.TableName
, dor.TableRowPointer
, dor.RefSequence
, dor.DocumentObjectRowPointer
, dor.NoteExistsFlag
, dor.CreatedBy
, dor.UpdatedBy
, dor.CreateDate
, dor.RecordDate
, dor.RowPointer
, ISNULL(edo.DocumentName, do.DocumentName) AS DocumentName
, ISNULL (edo.Sequence, do.Sequence) AS Sequence
, ISNULL(edo.Description, do.Description) AS Description
, ISNULL(edo.DocumentType, do.DocumentType) AS DocumentType
, ISNULL(edo.DocumentExtension, do.DocumentExtension) AS DocumentExtension
, ISNULL(edo.Internal, do.Internal) AS Internal
, ISNULL(edo.DocumentObject, do.DocumentObject) AS DocumentObject
, ISNULL(edo.MediaType, do.MediaType) AS MediaType
--, CASE WHEN dor.TableName = N'EventState' AND edo.DocumentName IS NOT NULL
--   THEN dor.InWorkflow  -- Set by EventSpawnEventAttachmentsSp
--   WHEN dor.InWorkflow = 1 OR do.InWorkflow = 1 THEN 1
--   ELSE 0
--  END AS InWorkflow
, do.InWorkflow AS InWorkflow
, dor.Suspend
, CASE WHEN edo.DocumentName IS NOT NULL THEN 1 ELSE 0 END AS EventDoc
, CASE WHEN dor.TableName IN (N'ObjectSentEmail',N'EmailTemplate') THEN 1 ELSE 0 END AS EmailDoc
, CAST (NULL AS uniqueidentifier) AS EventHandlerStateRowPointer -- Set the EventHandlerStateRowPointer from the client.
, CAST('03lkc' AS NVARCHAR(450)) AS UnmappedRowPointer
, CASE WHEN ISNULL(edo.DocumentObject, do.DocumentObject) IS NOT NULL THEN N'D' ELSE dt.StorageMethod END StorageMethod 
, do.FileSpec
, dor.FormName
, CAST(1 AS TINYINT) AS RecordExists
, do.FileImported
, CASE WHEN ( dt.StorageMethod = N'L' AND ( do.FileImported = 1 OR do.SharedFile = 1 ) ) OR 
            ( ISNULL(edo.DocumentObject, do.DocumentObject) IS NOT NULL) 
		 THEN 1 
		 ELSE 0 
  END DocumentExists
, dt.FileServer
, FS.ServerType
, do.SharedFile
, dor.EmbedInEmail
, dor.InWorkflow AS DocumentObjectReference_InWorkflow
, dt.UseServerPathAsRootPath
, CASE WHEN dt.StorageMethod <> N'L' OR ( ISNULL(edo.DocumentObject, do.DocumentObject) IS NOT NULL) THEN dt.FileSpec
       WHEN ISNULL(dt.LogicalFolderName,'') IN ( N'Default', '') AND FSL.FolderTemplate NOT IN ('*','\','/') THEN DBO.FormatFileSpec(N'L', 2, dt.FileSpec, FSL.FolderTemplate ) 
       WHEN dt.LogicalFolderName IS NOT NULL AND FSL.FolderTemplate NOT IN ('*','\','/') THEN FSL.FolderTemplate 
	   ELSE  dt.FileSpec 
  END FileSpecRootPath
, fs.SharedPath ServerRootPath
, dt.LogicalFolderName LogicalFolderName
, dt.CreateFolderIfNotExists CreateFolderIfNotExists
, CASE WHEN ISNULL(dt.PopulationDepth, 0) > 0  THEN dt.PopulationDepth
	   ELSE ISNULL(FSL.FolderAccessDepth,0) 
  END PopulationDepth
  FROM dbo.DocumentObjectReference dor
LEFT OUTER JOIN dbo.DocumentObject do 
	LEFT OUTER JOIN dbo.DocumentType dt 
		LEFT OUTER JOIN dbo.FileServer FS ON dt.FileServer = FS.ServerName
		LEFT OUTER JOIN dbo.FileServerLogicalFolder FSL ON dt.LogicalFolderName = FSL.LogicalFolderName
	ON do.DocumentType = dt.DocumentType
ON do.RowPointer = dor.DocumentObjectRowPointer
LEFT OUTER JOIN dbo.EventDocumentObject edo ON
	edo.RowPointer = dor.DocumentObjectRowPointer
GO
