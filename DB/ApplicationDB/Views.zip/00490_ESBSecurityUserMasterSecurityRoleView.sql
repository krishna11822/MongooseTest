SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ESBSecurityUserMasterSecurityRoleView') IS NOT NULL
   DROP VIEW dbo.ESBSecurityUserMasterSecurityRoleView
GO

/* $Header: /Tools/SQLScripts/ApplicationDB/Views/ESBSecurityUserMasterSecurityRoleView.sql 1     6/03/15 3:32p Tcecere $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/


/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/ESBSecurityUserMasterSecurityRoleView.sql $
 *
 * Purpose: Return "roles" for this particular user - Mongoose GroupNames and ModuleNames
 *
 * RS-8793 & Issue 256475 R.Shilts 12-Sept-2019
 * Add a column with the message bus logical ID all roles so it can be part of the outbound BOD.
 *
 * RS-8305 & Issue 244696 R.Shilts 12-Apr-2018
 * Extend a 'Role' from original GroupName to include ModuleNames for this user.
 * Note: this is assuming GroupNames are distinct from ModuleNames (also from ERA ReqSet 8305)
 *
 * RS-8305 R.Shilts 14-Mar-2018
 * Replace GroupName with possible external group name
 *
 * CoreDev 1 195814 Tcecere Wed Jun 03 15:32:11 2015
 * Additional files for RS7309
 * Issue 195814 - New View
 * $NoKeywords: $
 */
CREATE VIEW [dbo].[ESBSecurityUserMasterSecurityRoleView]
AS

-- Groups
SELECT 
   UserGroupMap.UserId AS 'UserId',
   COALESCE( ERA.ExternalRoleName, GroupNames.GroupName) AS 'GroupName',        -- external role name
   GroupNames.GroupDesc AS 'GroupDesc',
   (SELECT message_bus_logical_id FROM dbo.LocalSite) AS 'message_bus_logical_id'
FROM UserGroupMap
JOIN GroupNames on GroupNames.GroupId = UserGroupMap.GroupId
LEFT OUTER JOIN ExternalRoleAlias ERA
ON (ERA.GroupName = GroupNames.GroupName)
-- add Modules
UNION
SELECT 
   UserModules.UserId AS 'UserId',
   COALESCE( ERA.ExternalRoleName, Modules.ModuleName) AS 'GroupName',           -- external role name
   COALESCE( Modules.ModuleDescription, 'Module') AS 'GroupDesc',
   (SELECT message_bus_logical_id FROM dbo.LocalSite) AS 'message_bus_logical_id'
FROM UserModules
JOIN Modules on Modules.ModuleName = UserModules.ModuleName
LEFT OUTER JOIN ExternalRoleAlias ERA
ON (ERA.ModuleName = Modules.ModuleName)

GO

/***
select * from dbo.LocalSite

declare @bar nvarchar(10)
declare @foo varbinary(128)
set @bar = 'DEFAULT'
set @foo = convert(varbinary(128), @bar, 0)
set CONTEXT_INFO @foo
select * from dbo.LocalSite

-- simple test --
SELECT CONTEXT_INFO()       -- CONTEXT_INFO must be set
DECLARE @TestUserId INT
SET @TestUserId = 4
SELECT * FROM [ESBSecurityUserMasterSecurityRoleView] WHERE UserId = @TestUserId
***/


