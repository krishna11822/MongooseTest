SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON 
GO

IF object_id('dbo.EventStateView') IS NOT NULL
   DROP VIEW dbo.EventStateView
GO
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/EventStateView.sql 7     8/12/11 5:30p Nthurn $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/
/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/EventStateView.sql $
 *
 * CoreDev 7 project Nthurn Fri Aug 12 17:30:38 2011
 * Added EventStateId.  (RS5310)
 *
 * CoreDev 6 rs4588 Dahn Mon Mar 08 09:03:12 2010
 * rs4588 copyright header changes.
 *
 * CoreDev 5 rs3953 Dahn Tue Aug 26 15:51:54 2008
 * changing copyright header (rs3953)
 *
 * $NoKeywords: $
 */
CREATE VIEW EventStateView
AS
SELECT
   es.EventName,
   es.EventTitle,
   es.Originator,
   dbo.UserPassword(es.Originator) as EncryptedPassword,
   es.ConfigurationName,
   es.SessionID,
   es.BeginDate,
   es.EventParmId,
   es.EventState,
   es.AnyHandlersFailed,
   ehs.RowPointer as EventHandlerStateRowPointer,
   es.RowPointer as EventStateId
FROM EventHandlerState ehs
INNER JOIN EventState es
   ON es.RowPointer = ehs.EventStateRowPointer

GO
