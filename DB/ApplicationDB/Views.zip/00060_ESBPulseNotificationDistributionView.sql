SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON 
GO

IF object_id('dbo.ESBPulseNotificationDistributionView') IS NOT NULL
   DROP VIEW dbo.ESBPulseNotificationDistributionView
GO

/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2012 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
*************************************************************** 
*/


/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/ESBPulseNotificationDistributionView.sql $
 *
 * CoreDev 1 RS5345 Gmalakar Mon Mar 12 10:28:25 2012
 * RS 5345: Send Event Notification / Prompts to ION Pulse
 *
 * $NoKeywords: $
 */
CREATE VIEW dbo.ESBPulseNotificationDistributionView
AS
SELECT
	CAST('USERID' AS NVARCHAR(MAX)) UserID,
	CAST('USERNAME' AS NVARCHAR(MAX)) UserName,
	CAST('FULLNAME' AS NVARCHAR(MAX)) UserDesc
GO
