SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON 
GO

IF object_id('dbo.EventActionStateView') IS NOT NULL
   DROP VIEW dbo.EventActionStateView
GO
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/EventActionStateView.sql 7     4/27/10 6:10p Mewing $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/
/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/EventActionStateView.sql $
 *
 * CoreDev 7 128675 Mewing Tue Apr 27 18:10:29 2010
 * COPYRIGHT UPDATE
 *
 * CoreDev 6 RS4562 Lobkrom Mon Mar 08 09:19:16 2010
 * Implementing the QUORUM keyword required a schema change (RS4562)
 *
 * CoreDev 5 rs3953 Dahn Tue Aug 26 15:51:53 2008
 * changing copyright header (rs3953)
 *
 * CoreDev 4 107242 Nthurn Fri Feb 29 14:24:28 2008
 * Event Action Prompt to noone stops the Handler
 * Use (new) EventActionState.MessageRecipientList rather than EventMessage.ToUserList as the true Recipient List.  (Issue 107242)
 *
 * $NoKeywords: $
 */

CREATE VIEW EventActionStateView
AS
SELECT
   ehs.RowPointer as EventHandlerStateRowPointer,
   ea.Sequence,
   eas.MessageRecipientList as RecipientList,
   CASE WHEN eas.FirstBeginDate IS NOT NULL THEN 1 ELSE 0 END AS HasBegun,
   CASE WHEN eas.LastFinishDate IS NOT NULL THEN 1 ELSE 0 END AS HasFinished,
   eas.VotingRule,
   eas.VotingMinimum,
   eas.PreferredChoice,
   eas.Quorum
FROM EventHandlerState ehs
INNER JOIN EventActionState eas
   ON eas.EventHandlerStateRowPointer = ehs.RowPointer
INNER JOIN EventAction ea
   ON ea.RowPointer = eas.EventActionRowPointer

GO

