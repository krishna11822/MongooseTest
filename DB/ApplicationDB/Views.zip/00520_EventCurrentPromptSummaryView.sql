IF OBJECT_ID(N'EventCurrentPromptSummaryView') IS NOT NULL
   DROP VIEW EventCurrentPromptSummaryView
GO

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/EventCurrentPromptSummaryView.sql $
 *
 * CoreDev 1 project Nthurn Tue Mar 20 19:05:21 2012
 * Shows summarized information about current Prompts.
 *
 * $NoKeywords: $
 */
CREATE VIEW EventCurrentPromptSummaryView
AS
WITH EventCurrentPromptResults (
   EventName,
   EventRevision,
   EventStateRowPointer,
   HandlerSequence,
   EventHandlerStateRowPointer,
   ActionSequence,
   Iteration,
   SentDate,
   VotingTimeSeconds,
   IdleTimeSeconds,
   MessageRecipientList,
   Subject,
   Question,
   Choices,
   VotingRule,
   PreferredChoice,
   VotingMinimum,
   Voters,
   Quorum,
   VotingOpen,
   VotesCounted,
   VotesUntilQuorum
   )
AS (
   SELECT
   EventName,
   EventRevision,
   EventStateRowPointer,
   HandlerSequence,
   EventHandlerStateRowPointer,
   ActionSequence,
   Iteration,
   SentDate,
   VotingTimeSeconds,
   IdleTimeSeconds,
   MessageRecipientList,
   Subject,
   Question,
   Choices,
   VotingRule,
   PreferredChoice,
   VotingMinimum,
   Voters,
   Quorum,
   VotingOpen,
   VotesCounted,
   VotesUntilQuorum
   FROM EventCurrentPromptResultsView
   )
SELECT
   EventName,
   EventRevision,
   EventStateRowPointer,
   HandlerSequence,
   EventHandlerStateRowPointer,
   ActionSequence,
   Iteration,
   SentDate,
   MAX(VotingTimeSeconds) / 86400 AS VotingTimeDays,
   MAX(VotingTimeSeconds) % 86400 AS VotingTimeSecondsUnder1Day,
   DATEADD(SECOND, MAX(VotingTimeSeconds) % 86400, '1900-01-01') AS VotingTimeUnder1Day,
   CONVERT(NVARCHAR(8), DATEADD(SECOND, MAX(VotingTimeSeconds) % 86400, '1900-01-01'), 108) AS VotingTimeUnder1DayString,
   MIN(IdleTimeSeconds) / 86400 AS IdleTimeDays,
   MIN(IdleTimeSeconds) % 86400 AS IdleTimeSecondsUnder1Day,
   DATEADD(SECOND, MIN(IdleTimeSeconds) % 86400, '1900-01-01') AS IdleTimeUnder1Day,
   CONVERT(NVARCHAR(8), DATEADD(SECOND, MAX(IdleTimeSeconds) % 86400, '1900-01-01'), 108) AS IdleTimeUnder1DayString,
   MessageRecipientList,
   Subject,
   Question,
   Choices,
   VotingRule,
   PreferredChoice,
   VotingMinimum,
   Voters,
   Quorum,
   VotingOpen,
   VotesCounted,
   VotesUntilQuorum
FROM EventCurrentPromptResults
GROUP BY
   EventName,
   EventRevision,
   EventStateRowPointer,
   HandlerSequence,
   EventHandlerStateRowPointer,
   ActionSequence,
   Iteration,
   SentDate,
   MessageRecipientList,
   Subject,
   Question,
   Choices,
   VotingRule,
   PreferredChoice,
   VotingMinimum,
   Voters,
   Quorum,
   VotingOpen,
   VotesCounted,
   VotesUntilQuorum

GO

/** Testing:

SELECT * FROM EventCurrentPromptSummaryView
WHERE eventhandlerstaterowpointer in
('E9ACC146-7377-41EB-90E7-4E8941711AD2'
,'7CA5BC37-1B5A-4456-8DF6-3F322DFF72DE'
,'7C8D4A3D-BFA5-418E-82D2-1C6A877E6E27'
,'28FBB523-66FB-4D43-BE0A-AB85834378CE'
,'03BF8F49-A794-46E2-9777-1A48D138EE04'
,'EAAAF641-C332-457D-8F03-B4ACB391F38C'
,'F43BB47D-6F59-4ADD-9689-F05351652605'
,'5216E85C-A4C7-4C91-B4ED-4A162C3C7CBB'
,'C357AADF-DBB5-434D-A0E7-82DEAA2BC37A')
 **/

