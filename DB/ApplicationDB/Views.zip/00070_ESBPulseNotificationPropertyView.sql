SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON 
GO

IF object_id('dbo.ESBPulseNotificationPropertyView') IS NOT NULL
   DROP VIEW dbo.ESBPulseNotificationPropertyView
GO

/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2012 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
*************************************************************** 
*/


/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/ESBPulseNotificationPropertyView.sql $
 *
 * CoreDev 1 RS5345 Gmalakar Mon Mar 12 10:28:48 2012
 * RS 5345: Send Event Notification / Prompts to ION Pulse
 *
 * $NoKeywords: $
 */
CREATE VIEW dbo.ESBPulseNotificationPropertyView
AS
SELECT
	CAST('00000000-0000-0000-0000-000000000000' AS NVARCHAR(MAX)) ID,
	CAST('NAME' AS NVARCHAR(MAX)) Name,
	CAST('VALUE' AS NVARCHAR(MAX)) Value,
	CAST('STRING' AS NVARCHAR(MAX)) DataType,
	CAST('LABEL' AS NVARCHAR(MAX)) Label
GO
