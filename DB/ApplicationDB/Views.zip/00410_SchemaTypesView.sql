SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

IF EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SchemaTypesView]'))
DROP VIEW [dbo].[SchemaTypesView]
GO
-- =================================================================================
-- Stored Procedure: SchemaTypesView
-- This view retrieves system and user type information for the current database.
-- The data is retrieved from the sys.types system view.
-- =================================================================================
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/SchemaTypesView.sql 7     8/31/12 9:39a Djohnson $ */

/*

***************************************************************

*                                                             *

*                           NOTICE                            *

*                                                             *

*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *

*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *

*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *

*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *

*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *

*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *

*   ALL OTHER RIGHTS RESERVED.                                *

*                                                             *

*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *

*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *

*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *

*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *

*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *

*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *

*                                                             *

***************************************************************

*/

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/SchemaTypesView.sql $
 *
 * CoreDev 7 152770 Djohnson Fri Aug 31 09:39:21 2012
 * object not defined error
 * Issue #152770 - add a bogus RowPointer column.
 *
 * CoreDev 6 RS5348 Djohnson Fri Mar 30 10:08:37 2012
 * RS5348 - Return more columns about the datatype.
 *
 * CoreDev 5 rs4588 Dahn Mon Mar 08 09:03:21 2010
 * rs4588 copyright header changes.
 *
 * CoreDev 4 rs3953 Dahn Tue Aug 26 15:51:57 2008
 * changing copyright header (rs3953)
 *
 * $NoKeywords: $
 */
CREATE VIEW [dbo].[SchemaTypesView]
AS
select domain_name AS TypeName
, data_type
, character_maximum_length
, numeric_precision
, numeric_scale
, domain_schema
, newid() as RowPointer
from information_schema.domains
UNION
select st.name, st.name, NULL, precision, scale, ss.name
, newid() as RowPointer
from sys.types st
inner join sys.schemas ss on
  ss.schema_id = st.schema_id
where system_type_id = user_type_id

GO

