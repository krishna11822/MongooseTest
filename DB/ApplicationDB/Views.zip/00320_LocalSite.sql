SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

IF OBJECT_ID('dbo.LocalSite') IS NOT NULL
   DROP VIEW dbo.LocalSite
GO
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/LocalSite.sql 6     4/25/17 10:50a Djohnson $ */

/*

***************************************************************

*                                                             *

*                           NOTICE                            *

*                                                             *

*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *

*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *

*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *

*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *

*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *

*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *

*   ALL OTHER RIGHTS RESERVED.                                *

*                                                             *

*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *

*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *

*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *

*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *

*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *

*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *

*                                                             *

***************************************************************

*/

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/LocalSite.sql $
 *
 * Core90310 6 227662 Djohnson Tue Apr 25 10:50:08 2017
 * Groups not being updated in Ming.le
 *
 * CoreDev 5 rs4588 Dahn Mon Mar 08 09:03:16 2010
 * rs4588 copyright header changes.
 *
 * CoreDev 3 115425 Djohnson Tue Nov 11 10:54:27 2008
 * LocalSite view not returning languageId
 * Issue #115425 - use specific column names instead of * to avoid query plan confusion.
 *
 * CoreDev 2 rs3953 Dahn Tue Aug 26 15:51:56 2008
 * changing copyright header (rs3953)
 *
 * CoreDev 1 RS4033 Djohnson Thu Mar 27 09:15:27 2008
 * This view returns site table information only for the parms site.  It also returns the language ID.
 *
 * $NoKeywords: $
 */
CREATE VIEW dbo.LocalSite AS
SELECT site.site, site.site_name, site.lang_code, site.type, site.reports_to_site, site.last_consolidated, site.NoteExistsFlag, site.RecordDate, site.RowPointer, site.intranet_name, site.system_type, site.description, site.app_db_name, site.time_zone, site.CreatedBy, site.UpdatedBy, site.CreateDate, site.strings_table, site.InWorkflow, site.message_bus_logical_id, site.IntranetLicensing, ISNULL(LanguageIDs.LanguageID, 'en-US') AS LanguageID
FROM site
INNER JOIN parms ON
  parms.site = site.site
LEFT OUTER JOIN LanguageIDs ON
  LanguageIDs.LanguageCode = site.lang_code

GO


