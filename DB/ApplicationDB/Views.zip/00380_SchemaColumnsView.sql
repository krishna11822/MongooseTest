SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

IF EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SchemaColumnsView]'))
DROP VIEW [dbo].[SchemaColumnsView]
GO
-- =================================================================================
-- Stored Procedure: SchemaColumnsView
-- This view retrieves column information for user tables and views in the current
-- database. The data is retrieved from the INFORMATION_SCHEMA.COLUMNS system view.
-- =================================================================================
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/SchemaColumnsView.sql 7     3/08/10 9:03a Dahn $ */

/*

***************************************************************

*                                                             *

*                           NOTICE                            *

*                                                             *

*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *

*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *

*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *

*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *

*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *

*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *

*   ALL OTHER RIGHTS RESERVED.                                *

*                                                             *

*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *

*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *

*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *

*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *

*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *

*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *

*                                                             *

***************************************************************

*/

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/SchemaColumnsView.sql $
 *
 * CoreDev 7 rs4588 Dahn Mon Mar 08 09:03:19 2010
 * rs4588 copyright header changes.
 *
 * CoreDev 6 rs3953 Dahn Tue Aug 26 15:51:57 2008
 * changing copyright header (rs3953)
 *
 * 03/06/2020 - dartiaga - Issue 260253: added row pointer
 *
 * $NoKeywords: $
 */
CREATE VIEW [dbo].[SchemaColumnsView]
AS
SELECT
  isc.[TABLE_NAME]
, isc.[COLUMN_NAME]
, isc.[ORDINAL_POSITION]
, ISNULL(a.RowPointer, NEWID()) as RowPointer
FROM [INFORMATION_SCHEMA].[COLUMNS] isc
LEFT OUTER JOIN [AppTable] a
ON isc.TABLE_NAME = a.TableName
GO
