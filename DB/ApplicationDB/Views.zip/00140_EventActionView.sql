SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON 
GO

IF object_id('dbo.EventActionView') IS NOT NULL
   DROP VIEW dbo.EventActionView
GO
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/EventActionView.sql 4     3/08/10 9:03a Dahn $ */

/*

***************************************************************

*                                                             *

*                           NOTICE                            *

*                                                             *

*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *

*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *

*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *

*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *

*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *

*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *

*   ALL OTHER RIGHTS RESERVED.                                *

*                                                             *

*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *

*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *

*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *

*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *

*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *

*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *

*                                                             *

***************************************************************

*/

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/EventActionView.sql $
 *
 * CoreDev 4 rs4588 Dahn Mon Mar 08 09:03:09 2010
 * rs4588 copyright header changes.
 *
 * CoreDev 3 rs3953 Dahn Tue Aug 26 15:51:53 2008
 * changing copyright header (rs3953)
 *
 * $NoKeywords: $
 */
CREATE VIEW EventActionView
AS
SELECT
   ehs.RowPointer as EventHandlerStateRowPointer,
   ea.Sequence,
   ea.ActionType,
   dbo.EventActionParmsExpand(eas.RowPointer) as ExpandedParameters
   -- , *
FROM EventHandlerState ehs
INNER JOIN EventActionState eas
   ON eas.EventHandlerStateRowPointer = ehs.RowPointer
INNER JOIN EventAction ea
   ON ea.RowPointer = eas.EventActionRowPointer
GO
