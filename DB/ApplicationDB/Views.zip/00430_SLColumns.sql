if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SLColumns]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[SLColumns]
GO
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/SLColumns.sql 4     3/08/10 9:03a Dahn $ */

/*

***************************************************************

*                                                             *

*                           NOTICE                            *

*                                                             *

*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *

*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *

*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *

*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *

*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *

*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *

*   ALL OTHER RIGHTS RESERVED.                                *

*                                                             *

*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *

*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *

*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *

*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *

*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *

*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *

*                                                             *

***************************************************************

*/

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/SLColumns.sql $
 *
 * CoreDev 4 rs4588 Dahn Mon Mar 08 09:03:22 2010
 * rs4588 copyright header changes.
 *
 * CoreDev 3 rs3953 Dahn Tue Aug 26 15:51:58 2008
 * changing copyright header (rs3953)
 *
 * $NoKeywords: $
 */
CREATE VIEW SLColumns
AS
select tab.name AS TableName, col.name AS ColumnName,
CASE WHEN udt.name = bas.name THEN NULL ELSE udt.name END AS UDT,
bas.name AS BaseType,
CASE WHEN bas.name in ('varchar', 'nvarchar', 'char', 'nchar', 'decimal', 'numeric') then col.prec else null END as [ColumnPrecision], 
CASE WHEN bas.name in ('decimal', 'numeric') then col.scale else null END as [ColumnScale]
from syscolumns as col
inner join systypes as udt
on udt.xusertype = col.xusertype
inner join systypes as bas
on bas.xusertype = col.xtype
inner join sysobjects as tab
on tab.id = col.id
where tab.type = 'U'

GO
