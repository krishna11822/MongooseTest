SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON 
GO

IF object_id('dbo.EventTallyRowsView') IS NOT NULL
   DROP VIEW dbo.EventTallyRowsView
GO
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/EventTallyRowsView.sql 1     10/17/14 9:23a Djohnson $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/
/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/EventTallyRowsView.sql $
 *
 * CoreDev 1 RS5077 Djohnson Fri Oct 17 09:23:26 2014
 * RS5077
 *
 *
 * $NoKeywords: $
 */
CREATE VIEW EventTallyRowsView
AS
   SELECT DISTINCT
   es.RowPointer AS EventStateRowPointer,
   ehs.RowPointer AS EventHandlerStateRowPointer,
   ea.Sequence AS ActionSequence,
   em.Choices
   FROM EventState es
   INNER JOIN EventHandlerState ehs ON ehs.EventStateRowPointer = es.RowPointer
   INNER JOIN EventActionState eas ON eas.EventHandlerStateRowPointer = ehs.RowPointer
   INNER JOIN EventAction ea ON ea.RowPointer = eas.EventActionRowPointer
   INNER JOIN EventMessage em ON em.EventActionStateRowPointer = eas.RowPointer
   -- Current Action:
   WHERE eas.EventActionRowPointer = ehs.CurrentEventActionRowPointer
   -- Prompts only (not Notifies nor SendMessages):
   AND em.Choices IS NOT NULL
   -- Ignore (Unvotable) Originator's Saved Message copy:
   AND em.IsSavedMessage = 0
   -- Just the "last" Votable EventMessage group for this EventAction (in case of Action looping):
   AND NOT EXISTS(SELECT 1 FROM EventMessage em2
   WHERE em2.EventActionStateRowPointer = eas.RowPointer
   AND em2.Choices IS NOT NULL
   AND em2.IsSavedMessage = 0
   AND em2.CreateDate > em.CreateDate)
   -- Ignore special non-Votable signal from EventSendMessageSp:
   AND (em.SelectedChoice IS NULL OR em.SelectedChoice <> N',')
   AND es.RowPointer = dbo.DefinedValue('EventStateRP')



GO
