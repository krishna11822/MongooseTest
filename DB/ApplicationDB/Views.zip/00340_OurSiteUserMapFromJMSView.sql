SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON 
GO

IF object_id('dbo.OurSiteUserMapFromJMSView') IS NOT NULL
   DROP VIEW dbo.OurSiteUserMapFromJMSView
GO
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/OurSiteUserMapFromJMSView.sql 4     3/08/10 9:03a Dahn $ */

/*

***************************************************************

*                                                             *

*                           NOTICE                            *

*                                                             *

*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *

*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *

*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *

*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *

*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *

*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *

*   ALL OTHER RIGHTS RESERVED.                                *

*                                                             *

*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *

*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *

*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *

*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *

*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *

*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *

*                                                             *

***************************************************************

*/

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/OurSiteUserMapFromJMSView.sql $
 *
 * CoreDev 4 rs4588 Dahn Mon Mar 08 09:03:18 2010
 * rs4588 copyright header changes.
 *
 * CoreDev 3 rs3953 Dahn Tue Aug 26 15:51:56 2008
 * changing copyright header (rs3953)
 *
 * $NoKeywords: $
 */
CREATE VIEW OurSiteUserMapFromJMSView
AS
-- Return a list of Usernames to be used to submit IDORequests
-- from Sites on JMS Intranets to Sites on our Intranet:
SELECT
   FromSite, ToSite, Username, UserPassword as Password
FROM intranet JMSIntranet
INNER JOIN site JMSSite ON JMSSite.intranet_name = JMSIntranet.intranet_name
INNER JOIN parms ON parms.parm_key = 0
INNER JOIN site MySite ON MySite.site = parms.site
INNER JOIN site OurSite ON OurSite.intranet_name = MySite.intranet_name
INNER JOIN SiteUserMap
   ON SiteUserMap.FromSite = JMSSite.site
   AND SiteUserMap.ToSite = OurSite.site
INNER JOIN UserNames ON UserNames.Userid = SiteUserMap.Userid
WHERE JMSIntranet.Transport = N'J'
-- If there is no row here for an incoming message, it is not processable.

GO
