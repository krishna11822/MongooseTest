SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON 
GO

IF object_id('dbo.EventAttachmentsView') IS NOT NULL
   DROP VIEW dbo.EventAttachmentsView
GO
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/EventAttachmentsView.sql 3     9/13/11 2:17p Nthurn $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/
/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/EventAttachmentsView.sql $
 *
 * CoreDev 3 142535 Nthurn Tue Sep 13 14:17:09 2011
 * If a Document, that your Row does not Suspend, is InWorkflow by another user or row at the time of your Row's Suspension, then comes out of workflow, you still can't update it from your Suspend Event's Prompt's Inbox Message
 * Let DocumentObject.InWorkflow determine which rows are Read-Only (Issue 142535).
 * Don't use DocumentObjectReference.Suspend for EventState references (completion of Issue 142340).
 *
 * CoreDev 2 RS5310 Djohnson Wed Aug 31 16:15:22 2011
 * RS5310 - put in comments indicating this view should not be changed without looking at AlterEventAttachmentsViewSp.
 *
 * CoreDev 1 project Nthurn Fri Aug 12 17:32:16 2011
 * Documents attached to fired Events
 *
 * $NoKeywords: $
 */
-- DO NOT CHANGE THIS VIEW WITHOUT CHECKING AlterEventAttachmentsViewSp!!!!!!
-- DO NOT CHANGE THIS VIEW WITHOUT CHECKING AlterEventAttachmentsViewSp!!!!!!
-- DO NOT CHANGE THIS VIEW WITHOUT CHECKING AlterEventAttachmentsViewSp!!!!!!
CREATE VIEW dbo.EventAttachmentsView
AS
SELECT
   dor.TableRowPointer AS EventStateId
   , dor.RefSequence
   , ISNULL(ed.AttachmentName,
      REPLACE(ISNULL(edo.DocumentName, do.DocumentName), N',', N'_') + N'.' +
         REPLICATE(N'0', 11 - LEN(CAST(ISNULL(edo.Sequence, do.Sequence) AS nvarchar(11)))) +
         CAST(ISNULL(edo.Sequence, do.Sequence) AS nvarchar(11))
      ) AS AttachmentName
-- DO NOT CHANGE THIS VIEW WITHOUT CHECKING AlterEventAttachmentsViewSp!!!!!!
-- DO NOT CHANGE THIS VIEW WITHOUT CHECKING AlterEventAttachmentsViewSp!!!!!!
-- DO NOT CHANGE THIS VIEW WITHOUT CHECKING AlterEventAttachmentsViewSp!!!!!!
   , ed.EmbedInEmail   
   , ISNULL(ed.Suspended, 0) AS Suspended
   , ISNULL(edo.InWorkflow, do.InWorkflow) AS [ReadOnly]
   , ISNULL(edo.DocumentName, do.DocumentName) AS DocumentName
   , ISNULL(edo.Sequence, do.Sequence) AS Sequence
   , ISNULL(edo.Description, do.Description) AS Description
   , ISNULL(edo.DocumentType, do.DocumentType) AS DocumentType
   , ISNULL(edo.DocumentExtension, do.DocumentExtension) AS DocumentExtension
   , ISNULL(edo.MediaType, do.MediaType) AS MediaType
   , ISNULL(edo.Internal, do.Internal) AS Internal
   , ISNULL(edo.DocumentObject, do.DocumentObject) AS DocumentObject
   , ISNULL(edo.Modified, 0) AS Modified
FROM dbo.DocumentObjectReference dor
LEFT OUTER JOIN dbo.DocumentObject do ON
   do.RowPointer = dor.DocumentObjectRowPointer
LEFT OUTER JOIN dbo.EventDocumentObject edo ON
   edo.RowPointer = dor.DocumentObjectRowPointer
LEFT OUTER JOIN dbo.EventDocument ed
   ON ed.EventStateId = dor.TableRowPointer
   AND ed.RefSequence = dor.RefSequence
WHERE dor.TableName = N'EventState'
GO

/*
-- Testing:
--sp_help SequenceType
--decimal(11)
DECLARE @DocSeq SequenceType
SET @DocSeq = 456
DECLARE @DocumentName DocumentNameType
SET @DocumentName = N'This is a very long Document Name, with a comma!'
SELECT
   REPLACE(@DocumentName, N',', N'_') + N'.' +
   --CAST(@DocSeq AS nvarchar(11)),
   REPLICATE(N'0', 11 - LEN(CAST(@DocSeq AS nvarchar(11)))) +
   CAST(@DocSeq AS nvarchar(11))
 */
