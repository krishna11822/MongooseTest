SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON 
GO

IF object_id('dbo.EventWaitQueueView') IS NOT NULL
   DROP VIEW dbo.EventWaitQueueView
GO
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/EventWaitQueueView.sql $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2020 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/
/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/EventWaitQueueView.sql $
 *
 * DEV  258169 nicthu Feb 20 16:00 2020
 * Moved Site-free guts to (new) EventWaitQueueAllSitesView.sql.
 *
 * DEV  237990 nicthu Aug 12 16:00 2019
 * Consider only Events fired on current Site.
 *
 * $NoKeywords: $
 */
CREATE VIEW EventWaitQueueView
AS
SELECT
   QueueOrderingColumn,
   Id,
   RetestAtDate,
   WaitingObjectType,
   ActionType,
   Parameters,
   HandlerTransactional,
   EventHandlerRowPointer,
   Suspend,
   EventHandlerStateRowPointer,
   EventActionStateRowPointer,
   TimeOutDestSequence,
   EventParmId,
   EventTriggerRowPointer,
   EventName,
   RequestedBy,
   ConfigurationName,
   Transactional,
   Condition,
   FailureRetestInterval,
   SuccessRetestInterval,
   PathToWatch,
   FilesToWatch,
   WatchSubdirectories
FROM EventWaitQueueAllSitesView
INNER JOIN parms WITH (NOLOCK) ON 1=1
WHERE SiteRef = parms.site

GO


