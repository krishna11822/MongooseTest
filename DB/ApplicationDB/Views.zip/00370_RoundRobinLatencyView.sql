SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

IF OBJECT_ID('dbo.RoundRobinLatencyView') IS NOT NULL
   DROP VIEW dbo.RoundRobinLatencyView
GO

/* $Header: /Tools/SQLScripts/ApplicationDB/Views/dbo.RoundRobinLatencyView.sql 8     3/04/20 9:03a Dahn $ */

/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/dbo.RoundRobinLatencyView.sql $
 *
 * CoreDev 1 259688 DJohnson Wedn Mar 04 09:03:09 2020
 *
 * $NoKeywords: $
 */
CREATE VIEW dbo.RoundRobinLatencyView
AS
SELECT
  PollingService
, DATEDIFF(SS, MIN(ISNULL(LastPollDate,dbo.GetSiteDate(GETDATE())-1)), MAX(ISNULL(lastPollDate,dbo.GetSiteDate(GETDATE())))) AS LatencySeconds
, DATEDIFF(SS, MAX(ISNULL(lastPollDate,dbo.GetSiteDate(GETDATE())-1)), dbo.GetSiteDate(GETDATE())) AS QuietSeconds
FROM ServicePollingQueue
GROUP BY PollingService

GO

