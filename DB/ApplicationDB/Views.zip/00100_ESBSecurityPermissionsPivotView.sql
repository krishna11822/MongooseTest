SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO

IF EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[ESBSecurityPermissionsPivotView]'))
DROP VIEW [dbo].[ESBSecurityPermissionsPivotView]
GO

/* $Header: /Tools/SQLScripts/ApplicationDB/Views/ESBSecurityPermissionsPivotView.sql 1     1/10/17 10:28a Djackson1 $ */
/*
***************************************************************
*                                                             *
*                           NOTICE                            *
*                                                             *
*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
*   ALL OTHER RIGHTS RESERVED.                                *
*                                                             *
*   (c) COPYRIGHT 2015 INFOR.  ALL RIGHTS RESERVED.           *
*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
*                                                             *
***************************************************************
*/


/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/ESBSecurityPermissionsPivotView.sql $
 * MGD-3246 - djohnson Oct 28 2021
 * Add a DerParentID so that all form components can be brought in for a form.
 *
 * CoreDev 1 RS6090 Djackson1 Tue Jan 10 10:28:13 2017
 * 6090 - Approva integration
 *
 *
 * $NoKeywords: $
 */
 
CREATE VIEW [dbo].[ESBSecurityPermissionsPivotView]
AS

SELECT DISTINCT [DerBODID], [Id], [ObjectName1], [ObjectName2], CASE WHEN ObjectType = 1 THEN [ObjectName2] +'.'+ [Privilage] ELSE [Privilage] END AS [Privilage], [Status], [DerParentID]
  FROM (  
      SELECT 
       [DerBODID] = [DerBODID]
       ,[id]
       ,[ObjectName1]
       ,[ObjectName2]
       ,[Userid]
       ,[Username]
       ,[WorkstationLogin]
       ,[Groupid]
       ,[GroupName]
       ,[ObjectType]
       ,[ReadPrivilege] = CASE WHEN [ReadPrivilege] = 1 THEN 'Enabled' ELSE 'Disabled' END
       ,[UpdatePrivilege] = CASE WHEN [UpdatePrivilege] = 1 THEN 'Enabled' ELSE 'Disabled' END
       ,[BulkUpdatePrivilege] = CASE WHEN [BulkUpdatePrivilege] = 1 THEN 'Enabled' ELSE 'Disabled' END
       ,[InsertPrivilege] = CASE WHEN [InsertPrivilege] = 1 THEN 'Enabled' ELSE 'Disabled' END
       ,[DeletePrivilege] = CASE WHEN [DeletePrivilege] = 1 THEN 'Enabled' ELSE 'Disabled' END
       ,[EditPrivilege] = CASE WHEN [EditPrivilege] = 1 THEN 'Enabled' ELSE 'Disabled' END
       ,[ExecutePrivilege] = CASE WHEN [ExecutePrivilege] = 1 THEN 'Enabled' ELSE 'Disabled' END
       ,[DerParentID] = [DerParentID]
       ,[DerCompositeName] = CASE WHEN [ObjectType] = 1 THEN [ObjectName1] + '.' + [ObjectName2] ELSE '' END
       FROM ESBSecurityPermissionsMasterView
       ) P
       UNPIVOT 
       (Status FOR Privilage IN
         (
          [ReadPrivilege] 
         ,[UpdatePrivilege] 
         ,[BulkUpdatePrivilege] 
         ,[InsertPrivilege] 
         ,[DeletePrivilege] 
         ,[EditPrivilege] 
         ,[ExecutePrivilege] 
         )
       ) AS unpvt
   
GO
