IF OBJECT_ID(N'EventCurrentPromptUnvotedChoicesView') IS NOT NULL
   DROP VIEW EventCurrentPromptUnvotedChoicesView
GO
-- See also EventCurrentPromptVotersView (number of columns must match!)

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/EventCurrentPromptUnvotedChoicesView.sql $
 *
 * CoreDev 1 project Nthurn Tue Mar 20 19:04:02 2012
 * Shows information about choices for which no votes have been made on current Prompts.
 *
 * $NoKeywords: $
 */
CREATE VIEW EventCurrentPromptUnvotedChoicesView
AS
-- Unvoted Choices (one row per Choice):
SELECT
es.EventName,
er.EventRevision,
es.RowPointer AS EventStateRowPointer,
eh.Sequence AS HandlerSequence,
ehs.RowPointer AS EventHandlerStateRowPointer,
ea.Sequence AS ActionSequence,
-- A zero Iteration indicates a row created before MG8!
CASE eas.Iteration WHEN 0 THEN TimesExecuted + 1 ELSE eas.Iteration END AS Iteration,
eas.MessageRecipientList,
em.Subject,
em.Question,
em.Choices,
eas.VotingRule,
eas.PreferredChoice,
eas.VotingMinimum,
(SELECT COUNT(*) FROM EventMessage votes
   WHERE votes.EventActionStateRowPointer = em.EventActionStateRowPointer
   -- A zero ActionIteration indicates a row created before MG8!
   AND (em.ActionIteration = 0 AND votes.CreateDate = em.CreateDate
      OR em.ActionIteration > 0 AND votes.ActionIteration = em.ActionIteration)
   ) AS Voters,
eas.Quorum,
ehs.VotingOpen,
(SELECT COUNT(*) FROM EventMessage votes
   WHERE votes.EventActionStateRowPointer = em.EventActionStateRowPointer
   -- A zero ActionIteration indicates a row created before MG8!
   AND (em.ActionIteration = 0 AND votes.CreateDate = em.CreateDate
      OR em.ActionIteration > 0 AND votes.ActionIteration = em.ActionIteration)
   AND votes.SelectedChoice IS NOT NULL) AS VotesCounted,
-- CAST is required on these NULL's so that EventCurrentPromptResponsesView does not get e.g.:
-- Conversion failed when converting the nvarchar value '00:05:04' to data type int.
CAST(NULL AS nvarchar) AS Username,
0 AS HasBeenRead,
0 AS Voted,
choices.Choice AS UnselectedChoice,
CASE dbo.LookupTrimmed(choices.Choice, em.Choices, N',') WHEN 0 THEN NULL ELSE N'FORMAT(' + LTRIM(RTRIM(dbo.Entry(1 + dbo.LookupTrimmed(choices.Choice, em.Choices, N','), em.Choices, N','))) + N')' END AS FormattedChoice,
0 AS Expired,
em.SentDate,
CAST(NULL AS DateTime) AS ResponseDate,
CAST(NULL AS int) AS ResponseTimeDays,
CAST(NULL AS int) AS ResponseTimeSecondsUnder1Day,
CAST(NULL AS int) AS ResponseTimeUnder1Day,
CAST(NULL AS nvarchar) AS ResponseTimeUnder1DayString,
-- We don't worry too much about the execution time of dbo.GetSiteDate(), because:
-- a) We call it only for unvoted Messages (which shouldn't be a large number, given that this view is meant to be used long after the Prompt);
-- b) This view is meant to be restricted to a single EventHandlerStateRowPointer;
-- c) SQL Server evaluates only those columns that are requested in the SELECT from this View.
DATEDIFF(SECOND, em.SentDate, dbo.GetSiteDate(GETDATE())) / 86400 AS WaitTimeDays,
DATEDIFF(SECOND, em.SentDate, dbo.GetSiteDate(GETDATE())) % 86400 AS WaitTimeSecondsUnder1Day,
DATEADD(SECOND, DATEDIFF(SECOND, em.SentDate, dbo.GetSiteDate(GETDATE())) % 86400, '1900-01-01') AS WaitTimeUnder1Day,
CONVERT(NVARCHAR(8), DATEADD(SECOND, DATEDIFF(SECOND, em.SentDate, dbo.GetSiteDate(GETDATE())) % 86400, '1900-01-01'), 108) AS WaitTimeUnder1DayString,
em.ExpiresAfterDate,
em.RowPointer AS EventMessageRowPointer
FROM EventState es
INNER JOIN EventHandlerState ehs ON ehs.EventStateRowPointer = es.RowPointer
INNER JOIN EventHandlerRevision eh ON eh.RowPointer = ehs.EventHandlerRowPointer
INNER JOIN EventRevision er ON er.RowPointer = eh.EventRevisionRowPointer
INNER JOIN EventActionState eas ON eas.EventHandlerStateRowPointer = ehs.RowPointer
INNER JOIN EventAction ea ON ea.RowPointer = eas.EventActionRowPointer
-- Any 1 of the EventMessages, because we need only the common columns:
INNER JOIN EventMessage em ON em.RowPointer = (SELECT TOP 1 RowPointer
   FROM EventMessage em1
   WHERE em1.EventActionStateRowPointer = eas.RowPointer
   -- Prompts only (not Notifies nor SendMessages):
   AND em1.Choices IS NOT NULL
   -- Ignore (Unvotable) Originator's Saved Message copy:
   AND em1.IsSavedMessage = 0
   -- Just the "last" Votable EventMessage group for this EventAction (in case of Action looping):
   AND NOT EXISTS(SELECT 1 FROM EventMessage em2
   WHERE em2.EventActionStateRowPointer = eas.RowPointer
   AND em2.Choices IS NOT NULL
   AND em2.IsSavedMessage = 0
   AND em2.CreateDate > em1.CreateDate)
   -- Ignore special non-Votable signal from EventSendMessageSp:
   AND (em1.SelectedChoice IS NULL OR em1.SelectedChoice <> N',')
   )
CROSS APPLY dbo.EventMessageChoices(em.Choices) AS choices
-- Current Action:
WHERE eas.EventActionRowPointer = ehs.CurrentEventActionRowPointer
-- Ignore Choices that already received Vote(s):
AND NOT EXISTS(SELECT * FROM EventMessage votes
   WHERE votes.EventActionStateRowPointer = em.EventActionStateRowPointer
   -- A zero ActionIteration indicates a row created before MG8!
   AND (em.ActionIteration = 0 AND votes.CreateDate = em.CreateDate
      OR em.ActionIteration > 0 AND votes.ActionIteration = em.ActionIteration)
   AND votes.SelectedChoice = choices.Choice
   )
   
GO
