SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON 
GO

IF object_id('dbo.EventParameterView') IS NOT NULL
   DROP VIEW dbo.EventParameterView
GO
/* $Header: /Tools/SQLScripts/ApplicationDB/Views/EventParameterView.sql 5     3/08/10 9:03a Dahn $ */

/*

***************************************************************

*                                                             *

*                           NOTICE                            *

*                                                             *

*   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *

*   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *

*   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *

*   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *

*   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *

*   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *

*   ALL OTHER RIGHTS RESERVED.                                *

*                                                             *

*   (c) COPYRIGHT 2010 INFOR.  ALL RIGHTS RESERVED.           *

*   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *

*   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *

*   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *

*   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *

*   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *

*                                                             *

***************************************************************

*/

/* $Archive: /Tools/SQLScripts/ApplicationDB/Views/EventParameterView.sql $
 *
 * CoreDev 5 rs4588 Dahn Mon Mar 08 09:03:12 2010
 * rs4588 copyright header changes.
 *
 * CoreDev 4 rs3953 Dahn Tue Aug 26 15:51:54 2008
 * changing copyright header (rs3953)
 *
 * $NoKeywords: $
 */
CREATE VIEW EventParameterView
AS
SELECT
   ep.EventParmId,
   ep.Name,
   ep.Value,
   ep.IsOutput,
   ehs.RowPointer as EventHandlerStateRowPointer
FROM EventHandlerState ehs
INNER JOIN EventState es
   ON es.RowPointer = ehs.EventStateRowPointer
INNER JOIN EventParameter ep
   ON ep.EventParmId = es.EventParmId

GO
