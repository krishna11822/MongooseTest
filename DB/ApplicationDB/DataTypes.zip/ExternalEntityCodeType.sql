IF NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'ExternalEntityCodeType' AND ss.name = N'dbo')
CREATE TYPE [dbo].[ExternalEntityCodeType] FROM [nvarchar](64) NULL
GO
