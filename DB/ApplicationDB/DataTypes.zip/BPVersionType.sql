IF NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'BPVersionType' AND ss.name = N'dbo')
CREATE TYPE [dbo].[BPVersionType] FROM [nvarchar](15) NULL
GO
