IF NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'TypeOfNoteType' AND ss.name = N'dbo')
CREATE TYPE [dbo].[TypeOfNoteType] FROM [nchar](1) NULL
GO
