SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
if OBJECT_ID(N'[dbo].[ColumnSql]') IS NOT NULL
	DROP Function dbo.ColumnSql
GO
CREATE function dbo.ColumnSql (@ColName sysname, @first tinyint, @nullable tinyint)
returns varchar(max)
as
begin
	declare @sql varchar(max)

	if @nullable = 0
	if @first = 1
		set @sql = ''''''''' + ' + 'convert (varchar(max), ' + @ColName + ') + '''''''''
	else
		set @sql = ' + ' + ''','''''' + ' + 'convert (varchar(max), ' + @ColName + ') + '''''''''
	else
	if @first = 1
		set @sql = ' case when ' + @ColName + ' IS NOT NULL THEN ' + ''''''''' + ' + 'convert (varchar(max), ' + @ColName + ') + '''''''' else ''NULL'' END'
	else
		set @sql = ' + ' + ''',''' + '+ case when ' + @ColName + ' IS NOT NULL THEN ' + ''''''''' + ' + 'convert (varchar(max), ' + @ColName + ') + '''''''' else ''NULL'' END'
return @sql
end
GO
