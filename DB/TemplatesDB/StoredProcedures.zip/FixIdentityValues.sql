SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
if OBJECT_ID(N'[dbo].[FixIdentityValues]') IS NOT NULL
	DROP Procedure dbo.FixIdentityValues
GO
/****** Object:  Stored Procedure dbo.FixIdentityValues    Script Date: 1/29/99 12:39:20 PM ******/
CREATE PROCEDURE FixIdentityValues AS

DECLARE @NewId INT

-- Fix identity value for FormManTranLog
IF EXISTS( SELECT * FROM FrtFormManTranLog )
  BEGIN
  SET IDENTITY_INSERT FrtFormManTranLog ON

  SELECT @NewId = (SELECT MAX(ID) FROM FrtFormManTranLog) + 1

  SELECT 'Setting next identity value in Tran Log to ' + CONVERT(varchar, @NewId)

  INSERT INTO FrtFormManTranLog (ID, ObjectName, UserName, ObjectType, Action)
    VALUES (@NewId, 'Identity reset record', SUSER_NAME(), 999, 0)

  SET IDENTITY_INSERT FrtFormManTranLog OFF

  DELETE FrtFormManTranLog WHERE ID = @NewId
  END

-- Fix identity value for FormManActivityLog
IF EXISTS( SELECT * FROM FrtFormManActivityLog )
  BEGIN	
  SET IDENTITY_INSERT FrtFormManActivityLog ON

  SELECT @NewId = (SELECT MAX(ID) FROM FrtFormManActivityLog) + 1

  SELECT 'Setting next identity value in Activity Log to ' + CONVERT(varchar, @NewId)

  INSERT INTO FrtFormManActivityLog (ID, MessageType, MessageText)
    VALUES (@NewId, 999, 'Identity reset record')

  SET IDENTITY_INSERT FrtFormManActivityLog OFF

  DELETE FrtFormManActivityLog WHERE ID = @NewId
  END
	



GO
