IF NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'StringNameType' AND ss.name = N'dbo')
CREATE TYPE [dbo].[StringNameType] FROM [nvarchar](50) NULL
GO
