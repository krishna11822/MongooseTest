IF NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'ProductNameType' AND ss.name = N'dbo')
CREATE TYPE [dbo].[ProductNameType] FROM [nvarchar](80) NOT NULL
GO
