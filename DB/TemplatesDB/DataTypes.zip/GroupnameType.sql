IF NOT EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'GroupnameType' AND ss.name = N'dbo')
CREATE TYPE [dbo].[GroupnameType] FROM [nvarchar](200) NULL
GO
