SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON 
GO

IF OBJECTPROPERTY(OBJECT_ID(N'[dbo].[LocalLog]'), N'IsView') = 1
   DROP VIEW dbo.LocalLog
GO
-- Only create this view if this is not the application database.
IF OBJECTPROPERTY(OBJECT_ID(N'[dbo].[FrtLocalLog]'), N'IsTable') = 1 AND OBJECT_ID(N'[dbo].[UserNames]') IS NULL
EXECUTE (N'
/* $Header: /Tools/SQLScripts/TemplatesDB/Views/LocalLog.sql 1     5/10/16 11:06a Djohnson $Archive: $ */
CREATE VIEW dbo.LocalLog
AS
SELECT *
from dbo.FrtLocalLog'
)
GO
