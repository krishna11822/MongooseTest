SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON 
GO

IF OBJECTPROPERTY(OBJECT_ID(N'[dbo].[Properties]'), N'IsView') = 1
   DROP VIEW dbo.Properties
GO
-- Only create this view if this is not the application database.
IF OBJECTPROPERTY(OBJECT_ID(N'[dbo].[FrtProperties]'), N'IsTable') = 1 AND OBJECT_ID(N'[dbo].[UserNames]') IS NULL
EXECUTE (N'
/* $Header: /Tools/SQLScripts/TemplatesDB/Views/Properties.sql 1     5/10/16 11:07a Djohnson $Archive: $ */
CREATE VIEW dbo.Properties
AS
SELECT *
from dbo.FrtProperties'
)
GO
