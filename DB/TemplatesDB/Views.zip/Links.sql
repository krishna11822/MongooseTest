SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON 
GO

IF OBJECTPROPERTY(OBJECT_ID(N'[dbo].[Links]'), N'IsView') = 1
   DROP VIEW dbo.Links
GO
-- Only create this view if this is not the application database.
IF OBJECTPROPERTY(OBJECT_ID(N'[dbo].[FrtLinks]'), N'IsTable') = 1 AND OBJECT_ID(N'[dbo].[UserNames]') IS NULL
EXECUTE (N'
/* $Header: /Tools/SQLScripts/TemplatesDB/Views/Links.sql 1     5/10/16 11:06a Djohnson $Archive: $ */
CREATE VIEW dbo.Links
AS
SELECT *
from dbo.FrtLinks'
)
GO
